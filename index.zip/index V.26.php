<?php
// Simple Dreamweaver-like HTML/PHP editor with code + design view
// NOTE: Set your project root folder here:
$ROOT = 'e:/Carte/BB/17 - Site Leadership/'; // schimbă daca vrei alt folder de lucru
mb_internal_encoding('UTF-8');

function norm_path($p)
{
    $p = str_replace(["\\", ".."], ["/", ""], $p);
    return ltrim($p, "/");
}

function resolve_path($p, $ROOT)
{
    $p = str_replace("\\", "/", $p);
    if (preg_match('#^[a-zA-Z]:/#', $p) || strpos($p, '/') === 0) {
        return $p;
    }
    return rtrim($ROOT, '/') . '/' . ltrim($p, '/');
}

// Read a file and guarantee UTF-8 output (no BOM).
// Handles: UTF-8 BOM, UTF-16 LE BOM, UTF-16 BE BOM, ISO-8859-1, Windows-1252.
// Also updates the in-content charset declaration so the editor and saved file stay consistent.
function read_file_as_utf8($path)
{
    $content = file_get_contents($path);
    if ($content === false)
        return false;

    // ── Detect and strip BOM signatures ──
    if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
        // UTF-8 BOM: just strip the BOM, content is already UTF-8
        return substr($content, 3);
    }
    if (substr($content, 0, 4) === "\xFF\xFE\x00\x00") {
        // UTF-32 LE BOM
        $content = mb_convert_encoding(substr($content, 4), 'UTF-8', 'UTF-32LE');
        return preg_replace('/(\bcharset=)["\']?[a-zA-Z0-9_-]+["\']?/i', '${1}utf-8', $content, 1);
    }
    if (substr($content, 0, 4) === "\x00\x00\xFE\xFF") {
        // UTF-32 BE BOM
        $content = mb_convert_encoding(substr($content, 4), 'UTF-8', 'UTF-32BE');
        return preg_replace('/(\bcharset=)["\']?[a-zA-Z0-9_-]+["\']?/i', '${1}utf-8', $content, 1);
    }
    if (substr($content, 0, 2) === "\xFF\xFE") {
        // UTF-16 LE BOM
        $content = mb_convert_encoding(substr($content, 2), 'UTF-8', 'UTF-16LE');
        return preg_replace('/(\bcharset=)["\']?[a-zA-Z0-9_-]+["\']?/i', '${1}utf-8', $content, 1);
    }
    if (substr($content, 0, 2) === "\xFE\xFF") {
        // UTF-16 BE BOM
        $content = mb_convert_encoding(substr($content, 2), 'UTF-8', 'UTF-16BE');
        return preg_replace('/(\bcharset=)["\']?[a-zA-Z0-9_-]+["\']?/i', '${1}utf-8', $content, 1);
    }

    // ── No BOM: check if already valid UTF-8 ──
    if (mb_check_encoding($content, 'UTF-8'))
        return $content;

    // ── Not UTF-8: detect charset from HTML meta tag and convert ──
    $charset = 'ISO-8859-1'; // safe default
    if (preg_match('/<meta\b[^>]*\bhttp-equiv=["\']?Content-Type["\']?[^>]*\bcharset=([a-zA-Z0-9_-]+)/i', $content, $m)) {
        $charset = $m[1];
    } elseif (preg_match('/<meta\b[^>]*\bcharset=["\']?([a-zA-Z0-9_-]+)/i', $content, $m)) {
        $charset = $m[1];
    }
    $converted = @mb_convert_encoding($content, 'UTF-8', $charset);
    if (!$converted)
        $converted = mb_convert_encoding($content, 'UTF-8', 'ISO-8859-1');
    // Update charset declaration so saved file stays consistent
    return preg_replace('/(\bcharset=)["\']?[a-zA-Z0-9_-]+["\']?/i', '${1}utf-8', $converted, 1);
}

/**
 * Fișierul e salvat ca UTF-8 din editor — aliniază doar declarațiile reale de encoding.
 * NU înlocui primul „charset=” din tot documentul (poate apărea în URL-uri / JSON-LD și strică HTML-ul → CSS pierdut).
 */
function align_saved_html_charset_declaration_utf8($html)
{
    $out = preg_replace(
        '/(<meta\b[^>]*\bhttp-equiv\s*=\s*["\']Content-Type["\'][^>]*\bcontent\s*=\s*["\'])([^"\']*)\bcharset\s*=\s*[^"\';\s>]+/i',
        '$1$2charset=utf-8',
        $html,
        1,
        $cnt
    );
    if ($cnt > 0) {
        return $out;
    }
    $out2 = preg_replace(
        '/<meta\s+charset\s*=\s*["\']?[^"\'>\s]+["\']?\s*\/?>/i',
        '<meta charset="utf-8">',
        $html,
        1,
        $cnt2
    );
    return ($out2 !== null && $cnt2 > 0) ? $out2 : $html;
}

function html_save_is_catastrophically_truncated($existing, $candidate, &$reason)
{
    $oldLen = strlen((string) $existing);
    $newLen = strlen((string) $candidate);
    $reason = '';
    if ($oldLen < 12000 || $newLen >= (int) floor($oldLen * 0.55)) {
        return false;
    }

    $oldP = preg_match_all('/<p\b/i', $existing);
    $newP = preg_match_all('/<p\b/i', $candidate);
    $oldDiv = preg_match_all('/<div\b/i', $existing);
    $newDiv = preg_match_all('/<div\b/i', $candidate);
    $oldTable = preg_match_all('/<table\b/i', $existing);
    $newTable = preg_match_all('/<table\b/i', $candidate);

    $lostParagraphs = $oldP >= 5 && $newP < max(1, (int) floor($oldP * 0.25));
    $lostDivs = $oldDiv >= 8 && $newDiv < max(1, (int) floor($oldDiv * 0.25));
    $lostTables = $oldTable >= 3 && $newTable < max(1, (int) floor($oldTable * 0.25));
    if (!$lostParagraphs && !$lostDivs && !$lostTables) {
        return false;
    }

    $reason = 'Fisierul ar scadea de la ' . $oldLen . ' la ' . $newLen
        . ' bytes si ar pierde structura HTML principala.';
    return true;
}

function create_pre_save_backup($full)
{
    if (!is_file($full)) {
        return false;
    }
    $backupDir = dirname($full) . DIRECTORY_SEPARATOR . '.mini-dreamweaver-backups';
    if (!is_dir($backupDir) && !@mkdir($backupDir, 0777, true)) {
        return false;
    }
    $now = microtime(true);
    $micro = sprintf('%06d', (int) (($now - floor($now)) * 1000000));
    $backupName = basename($full) . '.before-save-' . date('Ymd-His') . '-' . $micro . '.bak';
    $backupPath = $backupDir . DIRECTORY_SEPARATOR . $backupName;
    if (!@copy($full, $backupPath)) {
        return false;
    }

    $pattern = $backupDir . DIRECTORY_SEPARATOR . basename($full) . '.before-save-*.bak';
    $copies = glob($pattern) ?: [];
    usort($copies, function ($a, $b) {
        return (@filemtime($b) ?: 0) <=> (@filemtime($a) ?: 0);
    });
    foreach (array_slice($copies, 25) as $oldCopy) {
        @unlink($oldCopy);
    }
    return $backupPath;
}

/**
 * Data „On Luna zi, an” de sub <h1 class="den_articol"> pentru fiecare articol din $dir
 * (ro/ sau en/). Paginile de categorii/index nu au <h1 den_articol>, deci sunt ignorate.
 * Cache in folderul temp: un fisier e recitit doar daca i s-a schimbat data modificarii.
 * Intoarce [file, ts, date, mtime, cat (link categorie), catName].
 */
function scan_article_dates_cached($dir)
{
    $months = ['ianuarie' => 1, 'februarie' => 2, 'martie' => 3, 'aprilie' => 4, 'mai' => 5, 'iunie' => 6,
        'iulie' => 7, 'august' => 8, 'septembrie' => 9, 'octombrie' => 10, 'noiembrie' => 11, 'decembrie' => 12,
        'january' => 1, 'february' => 2, 'march' => 3, 'april' => 4, 'may' => 5, 'june' => 6,
        'july' => 7, 'september' => 9, 'october' => 10, 'november' => 11, 'december' => 12];
    $cacheFile = sys_get_temp_dir() . '/htmleditor_article_dates_v2_' . md5(strtolower($dir)) . '.json';
    $cache = [];
    if (is_file($cacheFile)) {
        $tmp = json_decode((string) @file_get_contents($cacheFile), true);
        if (is_array($tmp)) $cache = $tmp;
    }
    $newCache = [];
    $list = [];
    foreach ((array) @scandir($dir) as $name) {
        if (!preg_match('/\.html?$/i', $name)) continue;
        $path = $dir . '/' . $name;
        $mtime = @filemtime($path);
        if ($mtime === false) continue;
        if (isset($cache[$name]) && $cache[$name]['m'] === $mtime) {
            $entry = $cache[$name];
        } else {
            $entry = ['m' => $mtime, 't' => null, 'd' => '', 'c' => '', 'cn' => ''];
            $head = @file_get_contents($path, false, null, 0, 120000);
            if ($head !== false &&
                preg_match('/<h1\b[^>]*class\s*=\s*["\'][^"\']*\bden_articol\b/i', $head, $hm, PREG_OFFSET_CAPTURE) &&
                preg_match('/class\s*=\s*["\'][^"\']*\btext_dreapta\b[^"\']*["\'][^>]*>(.*?)<\/td>/is', substr($head, $hm[0][1]), $td)) {
                $plain = trim(preg_replace('/\s+/u', ' ', str_ireplace(['&nbsp;', '&#160;'], ' ', strip_tags($td[1]))));
                if (preg_match('/\bOn\s+([^\s\d,]+)\s+(\d{1,2}),?\s+(\d{4})\b/iu', $plain, $dm)) {
                    $mon = strtolower($dm[1]);
                    if (isset($months[$mon]) && checkdate($months[$mon], (int) $dm[2], (int) $dm[3])) {
                        $entry['t'] = mktime(0, 0, 0, $months[$mon], (int) $dm[2], (int) $dm[3]);
                        $entry['d'] = $dm[0];
                    }
                }
                if (preg_match('/<a\b[^>]*\bhref\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $td[1], $am)) {
                    $entry['c'] = $am[1];
                    $entry['cn'] = trim(html_entity_decode(strip_tags($am[2]), ENT_QUOTES, 'UTF-8'));
                }
            }
        }
        $newCache[$name] = $entry;
        if ($entry['t'] !== null) {
            $list[] = ['file' => $path, 'ts' => $entry['t'], 'date' => $entry['d'], 'mtime' => $mtime,
                'cat' => isset($entry['c']) ? $entry['c'] : '', 'catName' => isset($entry['cn']) ? $entry['cn'] : ''];
        }
    }
    @file_put_contents($cacheFile, json_encode($newCache));
    return $list;
}

/**
 * Linkurile spre articole (a.linkMare) din fiecare pagină de categorie din $dir
 * (zona <!-- ARTICOL CATEGORIE START --> … FINAL). Articolele și index.html sunt ignorate.
 * Cache pe data modificării. Întoarce [file, title, links: [[name, text], …]].
 */
function scan_category_links_cached($dir)
{
    $cacheFile = sys_get_temp_dir() . '/htmleditor_category_links_v1_' . md5(strtolower($dir)) . '.json';
    $cache = [];
    if (is_file($cacheFile)) {
        $tmp = json_decode((string) @file_get_contents($cacheFile), true);
        if (is_array($tmp)) $cache = $tmp;
    }
    $newCache = [];
    $out = [];
    foreach ((array) @scandir($dir) as $name) {
        if (!preg_match('/\.html?$/i', $name) || preg_match('/^index\.html?$/i', $name)) continue;
        $path = $dir . '/' . $name;
        $mtime = @filemtime($path);
        if ($mtime === false) continue;
        if (isset($cache[$name]) && $cache[$name]['m'] === $mtime) {
            $entry = $cache[$name];
        } else {
            $entry = ['m' => $mtime, 'c' => false, 't' => '', 'l' => []];
            $html = @file_get_contents($path);
            $s = $html === false ? false : strpos($html, '<!-- ARTICOL CATEGORIE START -->');
            if ($s !== false && !preg_match('/<h1\b[^>]*class\s*=\s*["\'][^"\']*\bden_articol\b/i', $html)) {
                $e = strpos($html, '<!-- ARTICOL CATEGORIE FINAL -->', $s);
                $region = substr($html, $s, ($e === false ? strlen($html) : $e) - $s);
                $entry['c'] = true;
                if (preg_match('/<title>(.*?)<\/title>/is', $html, $tm)) {
                    $entry['t'] = trim(html_entity_decode(strip_tags($tm[1]), ENT_QUOTES, 'UTF-8'));
                }
                if (preg_match_all('/<a\b([^>]*\bclass\s*=\s*["\'][^"\']*\blinkMare\b[^>]*)>(.*?)<\/a>/is', $region, $am, PREG_SET_ORDER)) {
                    foreach ($am as $a) {
                        if (!preg_match('/\bhref\s*=\s*["\']([^"\']+)["\']/i', $a[1], $hm)) continue;
                        $href = preg_replace('/[#?].*$/', '', $hm[1]);
                        $entry['l'][] = [strtolower(basename($href)), trim(html_entity_decode(strip_tags($a[2]), ENT_QUOTES, 'UTF-8'))];
                    }
                }
            }
        }
        $newCache[$name] = $entry;
        if (!empty($entry['c'])) $out[] = ['file' => $path, 'title' => $entry['t'], 'links' => $entry['l']];
    }
    @file_put_contents($cacheFile, json_encode($newCache));
    return $out;
}

/**
 * Sortează lista de articole dintr-o pagină de categorie / index după dată (nou → vechi, stabil).
 * Blocul = 2× <table> + <p class="text_obisnuit2"> + <p class="text_obisnuit"></p> (ca în editor).
 * Fiecare bloc ia locul unui bloc din listă; spațiile dintre blocuri și restul fișierului rămân.
 * Întoarce textul nou sau null dacă lista e deja în ordine / nu există.
 */
function sort_list_blocks_by_date_php($html)
{
    $months = ['ianuarie' => 1, 'februarie' => 2, 'martie' => 3, 'aprilie' => 4, 'mai' => 5, 'iunie' => 6,
        'iulie' => 7, 'august' => 8, 'septembrie' => 9, 'octombrie' => 10, 'noiembrie' => 11, 'decembrie' => 12,
        'january' => 1, 'february' => 2, 'march' => 3, 'april' => 4, 'may' => 5, 'june' => 6,
        'july' => 7, 'september' => 9, 'october' => 10, 'november' => 11, 'december' => 12];
    $start = false;
    $endMarkers = [];
    foreach ([['<!-- ARTICOL CATEGORIE START -->', ['<!-- ARTICOL CATEGORIE FINAL -->']],
              ['<!-- ARTICOL START -->', ['<!-- SASA-1 -->', '<!-- ARTICOL FINAL -->']]] as $pair) {
        $i = strpos($html, $pair[0]);
        if ($i !== false) { $start = $i + strlen($pair[0]); $endMarkers = $pair[1]; break; }
    }
    if ($start === false || !preg_match('/\G\s*<div\s+align\s*=\s*["\']?justify["\']?\s*>/i', $html, $dm, 0, $start)) return null;
    $pos = $start + strlen($dm[0]);
    $end = strlen($html);
    foreach ($endMarkers as $em) {
        $e = strpos($html, $em, $pos);
        if ($e !== false && $e < $end) $end = $e;
    }
    $re = '/\G((?:\s|<p\s+class\s*=\s*["\']text_obisnuit["\'][^>]*>\s*<\/p>)*)(<table\s[^>]*\bwidth\s*=\s*["\'][^"\']+["\'][^>]*>.*?<\/table>\s*<p\s+class\s*=\s*["\']text_obisnuit2["\'][^>]*>.*?<\/p>\s*'
        . '<table\s[^>]*\bwidth\s*=\s*["\'][^"\']+["\'][^>]*>.*?<\/table>\s*<p\s+class\s*=\s*["\']text_obisnuit["\'][^>]*>\s*<\/p>)/is';
    $blocks = [];
    while ($pos < $end && preg_match($re, $html, $m, PREG_OFFSET_CAPTURE, $pos) && $m[0][1] + strlen($m[0][0]) <= $end) {
        $body = $m[2][0];
        $ts = 0;
        if (preg_match('/class\s*=\s*["\'][^"\']*\btext_dreapta\b[^"\']*["\'][^>]*>(.*?)<\/td>/is', $body, $td) &&
            preg_match('/\bOn\s+([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})/', $td[1], $d) && isset($months[strtolower($d[1])]) &&
            checkdate($months[strtolower($d[1])], (int) $d[2], (int) $d[3])) {
            $ts = (int) sprintf('%04d%02d%02d', (int) $d[3], $months[strtolower($d[1])], (int) $d[2]);
        }
        $blocks[] = ['start' => $m[2][1], 'end' => $m[2][1] + strlen($body), 'body' => $body, 'ts' => $ts];
        $pos = $m[0][1] + strlen($m[0][0]);
    }
    if (count($blocks) < 2) return null;
    $order = array_keys($blocks);
    usort($order, function ($a, $b) use ($blocks) {
        if ($blocks[$a]['ts'] !== $blocks[$b]['ts']) return $blocks[$b]['ts'] - $blocks[$a]['ts'];
        return $a - $b; // stabil
    });
    if ($order === array_keys($blocks)) return null;
    $out = '';
    $last = 0;
    foreach ($blocks as $k => $slot) {
        $out .= substr($html, $last, $slot['start'] - $last) . $blocks[$order[$k]]['body'];
        $last = $slot['end'];
    }
    return $out . substr($html, $last);
}

/** Remove stray </span> tags that have no matching opening <span> inside a text paragraph. */
function remove_orphan_closing_spans_from_paragraphs_php($html)
{
    return preg_replace_callback(
        '/(<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2?\b[^"\']*["\'][^>]*>)([\s\S]*?)(<\/p>)/i',
        function ($m) {
            $depth = 0;
            $inner = preg_replace_callback(
                '/<\/?span\b[^>]*>/i',
                function ($tag) use (&$depth) {
                    if (preg_match('/^<\s*span\b/i', $tag[0])) {
                        $depth++;
                        return $tag[0];
                    }
                    if ($depth > 0) {
                        $depth--;
                        return $tag[0];
                    }
                    return '';
                },
                $m[2]
            );
            return $m[1] . $inner . $m[3];
        },
        (string) $html
    );
}

function normalize_full_text_obisnuit2_span_paragraphs_php($html)
{
    $html = remove_orphan_closing_spans_from_paragraphs_php($html);
    return preg_replace_callback(
        '/(<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit\b[^"\']*["\'][^>]*>)\s*<span\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2\b[^"\']*["\'][^>]*>([\s\S]*?)<\/span>\s*(<\/p>)/i',
        function ($m) {
            return $m[1] . $m[2] . $m[3];
        },
        (string) $html
    );
}

/** Text simplu din interiorul unui tag (fără alte tag-uri). */
function normalize_text_paragraph_inline_formatting_php($html)
{
    $html = preg_replace_callback(
        '/(<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2?\b[^"\']*["\'][^>]*>)([\s\S]*?)(<\/p>)/i',
        function ($m) {
            $depths = [];
            $inner = preg_replace('/<i\s*>/i', '<em>', $m[2]);
            $inner = preg_replace('/<\/i>/i', '</em>', $inner);
            $inner = preg_replace_callback(
                '/<\/?(em|strong|u)\b[^>]*>/i',
                function ($tag) use (&$depths) {
                    $name = strtolower($tag[1]);
                    if (!isset($depths[$name])) $depths[$name] = 0;
                    if (preg_match('/^<\s*' . preg_quote($name, '/') . '\b/i', $tag[0])) {
                        $depths[$name]++;
                        return $tag[0];
                    }
                    if ($depths[$name] > 0) {
                        $depths[$name]--;
                        return $tag[0];
                    }
                    return '';
                },
                $inner
            );
            do {
                $before = $inner;
                $inner = preg_replace('/<(em|strong|u)\b[^>]*>\s*<\/\1>/i', '', $inner);
                $inner = preg_replace('/<em>\s*<em>/i', '<em>', $inner);
                $inner = preg_replace('/<\/em>\s*<\/em>/i', '</em>', $inner);
            } while ($inner !== $before);
            return $m[1] . $inner . $m[3];
        },
        (string) $html
    );
    return preg_replace(
        '/^[\t ]*<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2?\b[^"\']*["\'][^>]*>\s*(?:<(?:em|i|strong|b|u)\b[^>]*>\s*<\/(?:em|i|strong|b|u)>\s*)+<\/p>\s*\r?\n?/mi',
        '',
        $html
    );
}

/**
 * In zona articolului, muta inchiderile de paragraf ramase singure pe randul urmator
 * la sfarsitul textului: "text\n</p>" -> "text</p>" si
 * "text\n</em></p>" -> "text</em></p>".
 */
function join_sasa_paragraph_closing_tags_php($html)
{
    return preg_replace_callback(
        '/(<!--\s*SASA-1\s*-->)([\s\S]*?)(<!--\s*SASA-2\s*-->)/i',
        function ($zone) {
            $body = preg_replace_callback(
                '/(<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2?\b[^"\']*["\'][^>]*>)([\s\S]*?)(<\/p>)/i',
                function ($paragraph) {
                    $inner = preg_replace(
                        '/[\t ]*(?:\r?\n[\t ]*)+(?=(?:<\/(?:em|i|strong|b|u)>[\t ]*)*$)/i',
                        '',
                        $paragraph[2]
                    );
                    return $paragraph[1] . $inner . $paragraph[3];
                },
                $zone[2]
            );
            return $zone[1] . $body . $zone[3];
        },
        (string) $html
    );
}

function plain_text_from_html_inner($inner)
{
    $x = preg_replace('/<br\s*\/?>/i', ' ', (string) $inner);
    $x = strip_tags($x);
    $x = html_entity_decode($x, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return trim(preg_replace('/\s+/u', ' ', $x));
}

/**
 * Primul <p class="text_obisnuit2"> imediat după <!-- SASA-1 --> (cu sau fără <em>).
 */
function extract_article_sasa_teaser_plain($html)
{
    $norm = str_replace(["\r\n", "\r"], "\n", (string) $html);
    if (!preg_match('/<!--\s*SASA-1\s*-->/i', $norm, $m, PREG_OFFSET_CAPTURE)) {
        return null;
    }
    $slice = substr($norm, $m[0][1] + strlen($m[0][0]));
    if (!preg_match(
        '/^\s*(?:<!--[\s\S]*?-->\s*)*<p\b[^>]*\bclass\s*=\s*["\'][^"\']*\btext_obisnuit2\b[^"\']*["\'][^>]*>([\s\S]*?)<\/p>/i',
        $slice,
        $pm
    )) {
        return null;
    }
    $text = plain_text_from_html_inner($pm[1]);
    return $text !== '' ? $text : null;
}

function escape_meta_description_attr_value_php($s)
{
    $s = str_replace(['&', '"', '<', '>'], ['&amp;', '&quot;', '&lt;', '&gt;'], (string) $s);
    return trim(preg_replace('/\s+/u', ' ', str_replace(["\r\n", "\r", "\n"], ' ', $s)));
}

function escape_json_description_value_php($s)
{
    $s = trim(preg_replace('/\s+/u', ' ', str_replace(["\r\n", "\r", "\n"], ' ', (string) $s)));
    $enc = json_encode($s, JSON_UNESCAPED_UNICODE);
    if ($enc === false || strlen($enc) < 2) {
        return '';
    }
    return substr($enc, 1, -1);
}

/** La save: meta description, og:description, JSON-LD description din primul text_obisnuit2 după SASA-1. */
function apply_sasa_teaser_to_meta_description_php($html)
{
    $teaser = extract_article_sasa_teaser_plain($html);
    if ($teaser === null || $teaser === '') {
        return $html;
    }
    $metaEsc = escape_meta_description_attr_value_php($teaser);
    $jsonEsc = escape_json_description_value_php($teaser);
    $out = (string) $html;

    $metaPatterns = [
        '/(<meta\s+name\s*=\s*["\']description["\']\s+content\s*=\s*["\'])([^"\']*)(["\'])/i',
        '/(<meta\s+content\s*=\s*["\'])([^"\']*)(["\']\s+name\s*=\s*["\']description["\'])/i',
    ];
    foreach ($metaPatterns as $re) {
        if (preg_match($re, $out)) {
            $out = preg_replace($re, '${1}' . $metaEsc . '${3}', $out, 1);
            break;
        }
    }

    $ogPatterns = [
        '/(<meta\s+property\s*=\s*["\']og:description["\']\s+content\s*=\s*["\'])([^"\']*)(["\'])/i',
        '/(<meta\s+content\s*=\s*["\'])([^"\']*)(["\']\s+property\s*=\s*["\']og:description["\'])/i',
    ];
    foreach ($ogPatterns as $re) {
        if (preg_match($re, $out)) {
            $out = preg_replace($re, '${1}' . $metaEsc . '${3}', $out, 1);
            break;
        }
    }

    $out = preg_replace_callback(
        '/(<script[^>]*\btype\s*=\s*["\']application\/ld\+json["\'][^>]*>)([\s\S]*?)(<\/script>)/i',
        function ($m) use ($jsonEsc) {
            $newJson = preg_replace(
                '/("description"\s*:\s*")((?:\\\\.|[^"\\\\])*)(")/i',
                '${1}' . $jsonEsc . '${3}',
                $m[2]
            );
            if ($newJson === $m[2]) {
                return $m[0];
            }
            return $m[1] . $newJson . $m[3];
        },
        $out
    );

    return $out;
}

/** Păstrează la sync/save blocul <!-- JavaScript --> + <script> din body (preview-ul le elimină). */
function merge_body_with_protected_script_tail_php($origInner, $designInner)
{
    if (preg_match('/<script\b/i', $designInner)) {
        return $designInner;
    }
    if (!preg_match('/<script\b/i', $origInner)) {
        return $designInner;
    }
    if (preg_match('/<!--\s*JavaScript\s*-->/i', $origInner, $m, PREG_OFFSET_CAPTURE)) {
        $tail = substr($origInner, $m[0][1]);
        $core = $designInner;
        if (preg_match('/<!--\s*JavaScript\s*-->/i', $core, $dm, PREG_OFFSET_CAPTURE)) {
            $core = substr($core, 0, $dm[0][1]);
        }
        return rtrim($core) . "\n    " . rtrim($tail) . "\n";
    }
    if (preg_match_all('/<script\b[^>]*>[\s\S]*?<\/script>/i', $origInner, $scripts) && !empty($scripts[0])) {
        $core = preg_replace('/(?:\s*<!--(?:(?!-->)[\s\S])*-->[\s]*)+$/', '', $designInner);
        return rtrim($core) . "\n    " . implode("\n    ", $scripts[0]) . "\n";
    }
    return $designInner;
}

function restore_protected_body_scripts_php($originalHtml, $newHtml)
{
    if (!preg_match('/<body([^>]*)>[\s\S]*<\/body>/i', $originalHtml, $om)) {
        return $newHtml;
    }
    if (!preg_match('/<body([^>]*)>([\s\S]*)<\/body>/i', $newHtml, $nm)) {
        return $newHtml;
    }
    $origInner = preg_replace('/^<body[^>]*>/i', '', $om[0]);
    $origInner = preg_replace('/<\/body>$/i', '', $origInner);
    $mergedInner = merge_body_with_protected_script_tail_php($origInner, $nm[2]);
    if ($mergedInner === $nm[2]) {
        return $newHtml;
    }
    return preg_replace(
        '/<body[^>]*>[\s\S]*<\/body>/i',
        '<body' . $nm[1] . '>' . $mergedInner . '</body>',
        $newHtml,
        1
    );
}

define('ARTICLE_PAGE_TITLE_SUFFIX', ' | Neculai Fantanaru');

/**
 * Titlul articolului din <h1 class="custom-h1 article-title"> sau <h1 class="den_articol">.
 */
function extract_article_h1_title_plain_php($html)
{
    $norm = str_replace(["\r\n", "\r"], "\n", (string) $html);
    if (preg_match(
        '/<h1\b(?=[^>]*\bcustom-h1\b)(?=[^>]*\barticle-title\b)[^>]*>([\s\S]*?)<\/h1>/i',
        $norm,
        $m
    )) {
        $text = plain_text_from_html_inner($m[1]);
        if ($text !== '') {
            return $text;
        }
    }
    if (preg_match(
        '/<h1\b[^>]*\bclass\s*=\s*["\'][^"\']*\bden_articol\b[^"\']*["\'][^>]*>([\s\S]*?)<\/h1>/i',
        $norm,
        $m2
    )) {
        $text = plain_text_from_html_inner($m2[1]);
        if ($text !== '') {
            return $text;
        }
    }
    return null;
}

function build_article_page_title_from_h1_php($h1Plain)
{
    $core = trim(preg_replace('/\s+/u', ' ', (string) $h1Plain));
    if ($core === '') {
        return '';
    }
    return $core . ARTICLE_PAGE_TITLE_SUFFIX;
}

/** La save: title, og:title, abstract, Subject, JSON-LD headline/name din H1 articol. */
function apply_h1_to_page_titles_php($html)
{
    $h1Plain = extract_article_h1_title_plain_php($html);
    if ($h1Plain === null || $h1Plain === '') {
        return $html;
    }
    $titleFull = build_article_page_title_from_h1_php($h1Plain);
    if ($titleFull === '') {
        return $html;
    }
    $metaEsc = escape_meta_description_attr_value_php($titleFull);
    $jsonEsc = escape_json_description_value_php($titleFull);
    $out = (string) $html;

    $out = preg_replace('/(<title[^>]*>)([\s\S]*?)(<\/title>)/i', '${1}' . $metaEsc . '${3}', $out, 1);

    $ogTitlePatterns = [
        '/(<meta\s+property\s*=\s*["\']og:title["\']\s+content\s*=\s*["\'])([^"\']*)(["\'])/i',
        '/(<meta\s+content\s*=\s*["\'])([^"\']*)(["\']\s+property\s*=\s*["\']og:title["\'])/i',
    ];
    foreach ($ogTitlePatterns as $re) {
        if (preg_match($re, $out)) {
            $out = preg_replace($re, '${1}' . $metaEsc . '${3}', $out, 1);
            break;
        }
    }

    $namedMetaPatterns = [
        '/(<meta\s+name\s*=\s*["\']abstract["\']\s+content\s*=\s*["\'])([^"\']*)(["\'])/i',
        '/(<meta\s+content\s*=\s*["\'])([^"\']*)(["\']\s+name\s*=\s*["\']abstract["\'])/i',
        '/(<meta\s+name\s*=\s*["\']Subject["\']\s+content\s*=\s*["\'])([^"\']*)(["\'])/i',
        '/(<meta\s+content\s*=\s*["\'])([^"\']*)(["\']\s+name\s*=\s*["\']Subject["\'])/i',
    ];
    foreach ($namedMetaPatterns as $re) {
        if (preg_match($re, $out)) {
            $out = preg_replace($re, '${1}' . $metaEsc . '${3}', $out, 1);
        }
    }

    $suffixRe = preg_quote(ARTICLE_PAGE_TITLE_SUFFIX, '/');
    $out = preg_replace_callback(
        '/(<script[^>]*\btype\s*=\s*["\']application\/ld\+json["\'][^>]*>)([\s\S]*?)(<\/script>)/i',
        function ($m) use ($jsonEsc, $suffixRe) {
            $jsonBody = $m[2];
            $newJson = preg_replace(
                '/("headline"\s*:\s*")((?:\\\\.|[^"\\\\])*)(")/i',
                '${1}' . $jsonEsc . '${3}',
                $jsonBody
            );
            $newJson = preg_replace_callback(
                '/("name"\s*:\s*")((?:\\\\.|[^"\\\\])*)(")/i',
                function ($nm) use ($jsonEsc, $suffixRe) {
                    if (!preg_match('/' . $suffixRe . '\s*$/i', $nm[2])) {
                        return $nm[0];
                    }
                    return $nm[1] . $jsonEsc . $nm[3];
                },
                $newJson
            );
            if ($newJson === $jsonBody) {
                return $m[0];
            }
            return $m[1] . $newJson . $m[3];
        },
        $out
    );

    return $out;
}

// --- Asset proxy: serve any file from disk (CSS, JS, images, etc.) ---
$pathInfo = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
if (strpos($pathInfo, '/asset/') === 0) {
    $assetPath = substr($pathInfo, 7);
    $assetPath = str_replace("\\", "/", $assetPath);
    $assetPath = str_replace("../", "", $assetPath);
    if (file_exists($assetPath) && is_file($assetPath)) {
        $ext = strtolower(pathinfo($assetPath, PATHINFO_EXTENSION));
        $mimes = [
            'css' => 'text/css',
            'js' => 'application/javascript',
            'html' => 'text/html',
            'htm' => 'text/html',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'webp' => 'image/webp',
            'ico' => 'image/x-icon',
            'bmp' => 'image/bmp',
            'woff' => 'font/woff',
            'woff2' => 'font/woff2',
            'ttf' => 'font/ttf',
            'eot' => 'application/vnd.ms-fontobject',
            'json' => 'application/json',
            'xml' => 'text/xml',
            'mp4' => 'video/mp4',
            'webm' => 'video/webm',
            'pdf' => 'application/pdf',
        ];
        $ct = isset($mimes[$ext]) ? $mimes[$ext] : 'application/octet-stream';
        header('Content-Type: ' . $ct);
        header('Cache-Control: public, max-age=3600');
        readfile($assetPath);
    } else {
        http_response_code(404);
        echo "Not found";
    }
    exit;
}

// --- API: preview (HTML) ---
if (isset($_GET['action']) && $_GET['action'] === 'preview') {
    $file = isset($_GET['file']) ? $_GET['file'] : '';
    $full = resolve_path($file, $ROOT);
    if (!file_exists($full)) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo "Fisierul nu exista.";
        exit;
    }
    $ext = strtolower(pathinfo($full, PATHINFO_EXTENSION));
    if ($ext === 'php') {
        chdir(dirname($full));
        include $full;
    } else {
        $dir = str_replace("\\", "/", dirname($full));
        $baseUrl = '/htmleditor/index.php/asset/' . $dir . '/';
        $html = read_file_as_utf8($full);
        if ($html === false) {
            echo '<!DOCTYPE html><html><body>Eroare: nu se poate citi fisierul</body></html>';
            exit;
        }
        $baseTag = '<base href="' . htmlspecialchars($baseUrl, ENT_QUOTES, 'UTF-8') . '">';

        // ── STEP 1: Strip ALL JavaScript from the ENTIRE file first ──
        // This neutralises scripts in both <head> and <body>, preventing
        // JS-based redirects, hydration race-conditions, and runtime errors
        // that can blank the design preview.
        $html = preg_replace('/<script\b[^>]*>[\s\S]*?<\/script>/i', '', $html);
        $html = preg_replace('/<script\b[^>]*\/>/i', '', $html);
        // Strip <noscript> blocks (usually "enable JS" fallback messages)
        $html = preg_replace('/<noscript\b[^>]*>[\s\S]*?<\/noscript>/i', '', $html);

        // ── STEP 2: Collect stylesheets from the full (now script-free) HTML ──
        $allStyles = '';
        // <link rel="stylesheet"> – strip on* handlers, fix media="print" → "all",
        // strip title attr (titled stylesheets are "preferred" and may not activate in blob context)
        preg_match_all('/<link\b[^>]*\brel=["\']?stylesheet["\']?[^>]*\/?>/i', $html, $linkM);
        if (!empty($linkM[0])) {
            $cleanLinks = array_map(function ($tag) {
                $tag = preg_replace('/\s+on\w+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i', '', $tag);
                $tag = preg_replace('/\bmedia\s*=\s*["\']?\s*print\s*["\']?/i', 'media="all"', $tag);
                $tag = preg_replace('/\s+title\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i', '', $tag);
                return $tag;
            }, $linkM[0]);
            $allStyles .= implode("\n", $cleanLinks) . "\n";
        }

        // <style> blocks from the entire page, re-packaged cleanly in <head>
        preg_match_all('/<style\b[^>]*>([\s\S]*?)<\/style>/i', $html, $styleM);
        foreach ($styleM[1] as $css) {
            if (trim($css))
                $allStyles .= "<style type=\"text/css\">\n" . $css . "\n</style>\n";
        }

        // <meta charset> și <meta viewport>: UTF-8 forțat doar unde e declarație de encoding (nu orice „charset=” din content).
        $metaTags = '';
        preg_match_all('/<meta\b(?=[^>]*(?:charset|viewport))[^>]*>/i', $html, $metaM);
        if (!empty($metaM[0])) {
            $metaLines = array_map(function ($tag) {
                if (preg_match('/^\s*<meta\s+charset\b/i', $tag)) {
                    return '';
                }
                if (preg_match('/\bhttp-equiv\s*=\s*["\']?\s*Content-Type\s*["\']?/i', $tag)) {
                    return preg_replace('/(\bcharset\s*=\s*)[^"\';\s>]+/i', '${1}utf-8', $tag);
                }
                return $tag;
            }, $metaM[0]);
            $metaLines = array_values(array_filter($metaLines, function ($t) {
                return $t !== '';
            }));
            $metaTags = '<meta charset="utf-8">' . "\n" . implode("\n", $metaLines) . "\n";
        } else {
            $metaTags = '<meta charset="utf-8">' . "\n";
        }

        // <title>
        $titleTag = '';
        if (preg_match('/<title\b[^>]*>[\s\S]*?<\/title>/i', $html, $titleM)) {
            $titleTag = $titleM[0] . "\n";
        }

        // ── STEP 3: Extract and sanitise body content ──
        // Find the real <body> tag by splitting into comment/non-comment sections,
        // so that a commented-out body tag (<!-- <body ...> -->) is never matched.
        $bodyTagEnd = false;
        $bodyOpenTag = '<body>';
        $htmlParts = preg_split('/(<!--(?:(?!-->)[\s\S])*-->)/U', $html, -1, PREG_SPLIT_DELIM_CAPTURE);
        $cumOffset = 0;
        foreach ($htmlParts as $pi => $part) {
            if ($pi % 2 === 0 && $bodyTagEnd === false) { // non-comment section
                if (preg_match('/<body\b[^>]*>/i', $part, $bm, PREG_OFFSET_CAPTURE)) {
                    $bodyTagEnd = $cumOffset + $bm[0][1] + strlen($bm[0][0]);
                    // Strip on* from the real <body> opening tag
                    $bodyOpenTag = preg_replace('/\s+on\w+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i', '', $bm[0][0]);
                }
            }
            $cumOffset += strlen($part);
        }
        if ($bodyTagEnd !== false) {
            $bodyClosePos = strripos($html, '</body>');
            if ($bodyClosePos !== false && $bodyClosePos >= $bodyTagEnd) {
                $bodyInner = substr($html, $bodyTagEnd, $bodyClosePos - $bodyTagEnd);

                // Remove <style> from body (already collected into $allStyles above)
                $bodyInner = preg_replace('/<style\b[^>]*>[\s\S]*?<\/style>/i', '', $bodyInner);

                // Strip ALL on* event handler attributes from every element in body
                $bodyInner = preg_replace('/\s+on\w+\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i', '', $bodyInner);

                // Neutralise javascript: URLs in href attributes
                $bodyInner = preg_replace('/\bhref\s*=\s*["\']?\s*javascript\s*:[^"\'>\s]*/i', 'href="#"', $bodyInner);

                // Normalise italic tags: păstrează mereu <em> / </em> în loc de <i> / </i>.
                // Astfel, când înlocuiești doar textul în interior, numele tag-ului rămâne consecvent.
                $bodyInner = preg_replace('/<\s*i(\b[^>]*)>/i', '<em$1>', $bodyInner);
                $bodyInner = preg_replace('/<\s*\/\s*i\s*>/i', '</em>', $bodyInner);

                // DOMContentLoaded notification script (our only injected script)
                $domReadyScript = '<script>document.addEventListener("DOMContentLoaded",function(){'
                    . 'try{if(window.parent&&window.parent.__previewDOMReady)window.parent.__previewDOMReady(window.location.href);}catch(e){}'
                    . '});</script>';

                // Override CSS — force ALL elements to be visible.
                // Many modern pages hide content with CSS expecting JS hydration;
                // since we strip all scripts we must override every level, not just body>*.
                $editorOverrideCSS = "<style type=\"text/css\" id=\"editor-override\">\n"
                    . "html, body { visibility: visible !important; opacity: 1 !important; }\n"
                    . "body { display: block !important; }\n"
                    . "body * { visibility: visible !important; opacity: 1 !important;\n"
                    . "  animation: none !important; transition: none !important; }\n"
                    . "a img { cursor: pointer !important; }\n"
                    . "img { cursor: default !important; }\n"
                    . "a img { cursor: pointer !important; }\n"
                    . "#preloader, .preloader, #loader, .loader, #loader-fade,\n"
                    . ".loading-overlay, .page-loader, .loading-screen,\n"
                    . "#loading-overlay, #page-loading, .site-loader,\n"
                    . ".loader-container, .spinner, #spinner,\n"
                    . "[class*=\"preload\"], [id*=\"preload\"],\n"
                    . "[class*=\"page-load\"], [id*=\"page-load\"] {\n"
                    . "  display: none !important; }\n"
                    . "</style>\n";

                $html = "<!DOCTYPE html>\n<html>\n<head>\n"
                    . $metaTags . $titleTag . $baseTag . "\n" . $domReadyScript . "\n" . $allStyles . $editorOverrideCSS
                    . "</head>\n" . $bodyOpenTag . $bodyInner . "</body>\n</html>";
            } else {
                $html = "<!DOCTYPE html>\n<html>\n<head>\n" . $metaTags . $baseTag . "\n" . $allStyles . "</head>\n<body></body>\n</html>";
            }
        } else {
            $html = "<!DOCTYPE html>\n<html>\n<head>\n" . $metaTags . $baseTag . "\n" . $allStyles . "</head>\n<body></body>\n</html>";
        }

        $ct = ($ext === 'css') ? 'text/css' : 'text/html';
        header("Content-Type: {$ct}; charset=utf-8");
        echo $html;
    }
    exit;
}

// --- API JSON (list/load/save) ---
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    header('Content-Type: application/json; charset=utf-8');

    // Versiunea editorului (data modificarii acestui fisier) — pagina o compara ca sa ceara reincarcare.
    if ($action === 'version') {
        clearstatcache(true, __FILE__);
        echo json_encode(['ok' => true, 'v' => (string) filemtime(__FILE__)]);
        exit;
    }

    // Butonul „Trimite E-mail”: ruleaza in fundal monitor_index.py (care trimite pe email ultimul articol din ro/index.html)
    // si intoarce tot ce a afisat scriptul. Cu check=1 doar verifica (Python, script, articolul care s-ar trimite) — NU trimite.
    if ($action === 'sendArticleEmail' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $scriptDir = 'e:/Carte/BB/17 - Site Leadership/alte/Ionel Balauta/Aryeht/Task 1 - Traduce tot site-ul/Doar Google Web/Andreea/Meditatii/2023/MAIL TEXT';
        $script = $scriptDir . '/monitor_index.py';
        $indexRo = 'e:/Carte/BB/17 - Site Leadership/Principal/ro/index.html';
        $python = 'C:/Users/necul/AppData/Local/Programs/Python/Python312/python.exe';
        if (!is_file($python)) $python = 'python';
        if (!is_file($script)) {
            echo json_encode(['ok' => false, 'error' => 'Nu gasesc scriptul: ' . $script], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // Articolul pe care il va trimite scriptul (acelasi regex ca in monitor_index.py)
        $articleLink = '';
        $idx = @file_get_contents($indexRo);
        if ($idx !== false && preg_match('/<td><span class="den_articol"><a href="([^"]+)" class="linkMare">([^<]*)/', $idx, $am)) {
            $articleLink = $am[1];
            $articleTitle = html_entity_decode($am[2], ENT_QUOTES, 'UTF-8');
        }
        if (!empty($_POST['check'])) {
            echo json_encode(['ok' => true, 'python' => $python, 'link' => $articleLink,
                'title' => isset($articleTitle) ? $articleTitle : ''], JSON_UNESCAPED_UNICODE);
            exit;
        }
        @set_time_limit(300);
        $env = getenv();
        if (!is_array($env)) $env = [];
        $pyDir = ($python !== 'python') ? str_replace('/', '\\', dirname($python)) : '';
        $pathKey = 'PATH';
        foreach ($env as $k => $v) { if (strtoupper($k) === 'PATH') { $pathKey = $k; break; } }
        if ($pyDir !== '') $env[$pathKey] = $pyDir . ';' . (isset($env[$pathKey]) ? $env[$pathKey] : '');
        $env['PYTHONIOENCODING'] = 'utf-8';
        $env['PYTHONUTF8'] = '1';
        $proc = proc_open([$python, '-u', 'monitor_index.py'],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']],
            $pipes, $scriptDir, $env, ['bypass_shell' => true, 'create_process_group' => false]);
        if (!is_resource($proc)) {
            echo json_encode(['ok' => false, 'error' => 'Nu am putut porni Python (' . $python . ').'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $out = '';
        $err = '';
        $start = time();
        $timedOut = false;
        while (true) {
            $status = proc_get_status($proc);
            $out .= (string) stream_get_contents($pipes[1]);
            $err .= (string) stream_get_contents($pipes[2]);
            if (!$status['running']) break;
            if (time() - $start > 240) { $timedOut = true; proc_terminate($proc); break; }
            usleep(150000);
        }
        $out .= (string) stream_get_contents($pipes[1]);
        $err .= (string) stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);
        $exit = proc_close($proc);
        if (isset($status['exitcode']) && $status['exitcode'] !== -1) $exit = $status['exitcode'];
        $sent = (strpos($out, 'Email trimis cu succes!') !== false);
        echo json_encode(['ok' => true, 'sent' => $sent, 'output' => $out, 'errors' => $err,
            'exitCode' => $exit, 'timedOut' => $timedOut, 'link' => $articleLink], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'generateRSS') {
        @set_time_limit(600); ini_set('display_errors', '0');
        $dir = 'E:/Carte/BB/17 - Site Leadership/alte/Ionel Balauta/Aryeht/Task 1 - Traduce tot site-ul/Doar Google Web/Andreea/Meditatii/Sedinta 13';
        // EN și RO pornesc în paralel (fiecare ~2 s singur); apoi verific că fișierele din Principal 2022 chiar au fost rescrise.
        $python = 'C:/Users/necul/AppData/Local/Programs/Python/Python312/python.exe';
        $targets = ['EN' => 'E:/Carte/BB/17 - Site Leadership/Principal 2022/en/rss.xml', 'RO' => 'E:/Carte/BB/17 - Site Leadership/Principal 2022/ro/rss.xml'];
        $started = microtime(true);
        $before = [];
        $jobs = [];
        foreach ($targets as $lang => $target) {
            clearstatcache(true, $target);
            $before[$lang] = is_file($target) ? ['mtime' => filemtime($target), 'size' => filesize($target)] : null;
            $err = tempnam(sys_get_temp_dir(), 'rss');
            $process = proc_open([$python, '-X', 'utf8', $dir . '/rss XML 2024 ' . $lang . '.py'], [0=>['pipe','r'],1=>['pipe','w'],2=>['file',$err,'a']], $pipes, $dir, null, ['bypass_shell'=>true]);
            if (!is_resource($process)) { echo json_encode(['ok'=>false,'error'=>'Nu pot porni RSS ' . $lang], JSON_UNESCAPED_UNICODE); exit; }
            fclose($pipes[0]);
            stream_set_blocking($pipes[1], false);
            $jobs[$lang] = ['proc' => $process, 'out' => $pipes[1], 'err' => $err, 'log' => '', 'code' => null];
        }
        while (true) {
            $running = 0;
            foreach ($jobs as $lang => &$job) {
                if ($job['code'] !== null) continue;
                $job['log'] .= (string) stream_get_contents($job['out']);
                $status = proc_get_status($job['proc']);
                if ($status['running']) { $running++; continue; }
                $job['log'] .= (string) stream_get_contents($job['out']);
                $job['code'] = $status['exitcode'];
                fclose($job['out']);
                proc_close($job['proc']);
            }
            unset($job);
            if (!$running) break;
            if (microtime(true) - $started > 300) {
                foreach ($jobs as $job) if ($job['code'] === null) proc_terminate($job['proc']);
                echo json_encode(['ok'=>false,'error'=>'Generarea RSS a depășit 5 minute și a fost oprită.'], JSON_UNESCAPED_UNICODE); exit;
            }
            usleep(100000);
        }
        $lines = [];
        date_default_timezone_set('Europe/Bucharest');
        foreach ($jobs as $lang => $job) {
            $errors = (string) @file_get_contents($job['err']); @unlink($job['err']);
            if ($job['code'] !== 0) { echo json_encode(['ok'=>false,'error'=>"RSS $lang a eșuat (cod " . $job['code'] . "):\n" . $job['log'] . $errors], JSON_UNESCAPED_UNICODE); exit; }
            $target = $targets[$lang];
            clearstatcache(true, $target);
            $fresh = is_file($target) && filemtime($target) >= (int) $started - 1;
            if (!$fresh) { echo json_encode(['ok'=>false,'error'=>"RSS $lang: scriptul s-a terminat, dar fișierul NU a fost rescris: $target"], JSON_UNESCAPED_UNICODE); exit; }
            $xml = (string) file_get_contents($target);
            $lines[] = "$lang: " . str_replace('/', '\\', $target) . ' — rescris la ' . date('H:i:s', filemtime($target)) . ', ' . number_format(filesize($target) / 1024, 0) . ' KB, ' . substr_count($xml, '<item>') . ' articole'
                . ($before[$lang] ? ' (înainte: ' . date('H:i:s', $before[$lang]['mtime']) . ', ' . number_format($before[$lang]['size'] / 1024, 0) . ' KB)' : '');
        }
        // Apoi urcă ambele fluxuri pe FTP: ro -> /public_html/rss.xml, en -> /public_html/en/rss.xml (verificat)
        $ftpStart = microtime(true);
        $ftpErr = tempnam(sys_get_temp_dir(), 'rssftp');
        $ftpProc = proc_open([$python, '-X', 'utf8', __DIR__ . '/publica_rss_ftp.py'], [0=>['pipe','r'],1=>['pipe','w'],2=>['file',$ftpErr,'a']], $ftpPipes, __DIR__, null, ['bypass_shell'=>true]);
        $ftp = null;
        if (is_resource($ftpProc)) {
            fclose($ftpPipes[0]);
            $ftpOut = stream_get_contents($ftpPipes[1]); fclose($ftpPipes[1]);
            proc_close($ftpProc);
            $ftp = json_decode(trim($ftpOut), true);
            if (!is_array($ftp)) $ftp = ['ok' => false, 'error' => trim($ftpOut . ' ' . @file_get_contents($ftpErr))];
        } else {
            $ftp = ['ok' => false, 'error' => 'Nu pot porni urcarea pe FTP.'];
        }
        @unlink($ftpErr);
        if (!empty($ftp['ok'])) {
            $lines[] = 'FTP: urcat și verificat în ' . round(microtime(true) - $ftpStart, 1) . ' s:';
            foreach ($ftp['uploads'] as $u) {
                $lines[] = '   ' . strtoupper($u['lang']) . ' → ' . $u['remote'] . ' (' . number_format($u['size'] / 1024, 0) . ' KB)';
            }
            echo json_encode(['ok'=>true,'log'=>"RSS a fost generat în RO și în EN în " . round(microtime(true) - $started, 1) . " s.\n" . implode("\n", $lines)], JSON_UNESCAPED_UNICODE); exit;
        }
        echo json_encode(['ok'=>false,'error'=>"RSS a fost generat local, dar urcarea pe FTP a eșuat: " . ($ftp['error'] ?? 'eroare necunoscută') . "\n" . implode("\n", $lines)], JSON_UNESCAPED_UNICODE); exit;
    }
    // Amprenta ieftina a site-ului (Principal/ro si /en): numarul de HTML-uri + cea mai noua data de
    // modificare. Se schimba cand copiezi/inlocuiesti un fisier -> editorul porneste imediat verificarile.
    if ($action === 'siteStamp') {
        $count = 0; $newest = 0; $sum = 0;
        foreach (['ro', 'en'] as $lang) {
            foreach ((array) glob('E:/Carte/BB/17 - Site Leadership/Principal/' . $lang . '/*.html') as $f) {
                $m = (int) @filemtime($f);
                $count++; $sum += $m; if ($m > $newest) $newest = $m;
            }
        }
        echo json_encode(['ok' => true, 'stamp' => $count . '-' . $newest . '-' . $sum]);
        exit;
    }
    // Jurnalul verificarilor (verificari-log.txt): randurile trimise de editor (ex. date duplicate)
    if ($action === 'appendCheckLog' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $lines = json_decode($_POST['lines'] ?? '[]', true);
        if (is_array($lines) && $lines) {
            date_default_timezone_set('Europe/Bucharest');
            $stamp = date('Y-m-d H:i:s');
            $out = '';
            foreach (array_slice($lines, 0, 200) as $line) {
                $out .= $stamp . '  ' . str_replace(["\r", "\n"], ' ', (string) $line) . "\n";
            }
            @file_put_contents(__DIR__ . '/verificari-log.txt', $out, FILE_APPEND | LOCK_EX);
        }
        echo json_encode(['ok' => true]);
        exit;
    }
    // Repara canonicalul si steagul unei limbi intr-un articol din Principal/ro sau /en.
    if ($action === 'repairArticleIdentity' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $relative = trim((string) ($_POST['file'] ?? ''));
        $flagLang = strtolower(trim((string) ($_POST['flagLang'] ?? '')));
        $flagTarget = trim((string) ($_POST['flagTarget'] ?? ''));
        if (!preg_match('#^(ro|en)/([A-Za-z0-9._-]+\.html?)$#i', $relative, $pathMatch)
            || !in_array($flagLang, ['ro', 'en'], true)
            || !preg_match('/^[A-Za-z0-9._-]+\.html?$/i', $flagTarget)) {
            echo json_encode(['ok' => false, 'error' => 'Fisierul sau destinatia steagului nu sunt valide.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $lang = strtolower($pathMatch[1]);
        $fileName = basename($pathMatch[2]);
        $full = resolve_path('Principal/' . $relative, $ROOT);
        $flagDir = resolve_path('Principal/' . $flagLang, $ROOT);
        if (!is_file($full) || !is_file($flagDir . '/' . $flagTarget)) {
            echo json_encode(['ok' => false, 'error' => 'Fisierul articolului sau pagina-tinta a steagului nu exista.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $raw = @file_get_contents($full);
        if ($raw === false) {
            echo json_encode(['ok' => false, 'error' => 'Nu pot citi fisierul ' . $relative], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $canonicalUrl = 'https://neculaifantanaru.com/' . ($lang === 'en' ? 'en/' : '') . $fileName;
        $canonicalCount = 0;
        $canonicalHrefCount = 0;
        $updated = preg_replace_callback('/<link\b(?=[^>]*\brel\s*=\s*["\'][^"\']*\bcanonical\b[^"\']*["\'])[^>]*>/i',
            function ($m) use ($canonicalUrl, &$canonicalCount, &$canonicalHrefCount) {
                $canonicalCount++;
                return preg_replace_callback('/(\bhref\s*=\s*)(["\'])(.*?)\2/i',
                    function ($h) use ($canonicalUrl, &$canonicalHrefCount) {
                        $canonicalHrefCount++;
                        return $h[1] . $h[2] . $canonicalUrl . $h[2];
                    }, $m[0], 1);
            }, $raw);
        if ($updated === null || $canonicalCount < 1 || $canonicalHrefCount < 1) {
            echo json_encode(['ok' => false, 'error' => 'Nu am gasit un canonical cu href care sa poata fi reparat.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $flagSections = 0;
        $flagLinks = 0;
        $updated = preg_replace_callback('/(<!--\s*FLAGS_1\s*-->)([\s\S]*?)(<!--\s*FLAGS\s*-->)/i',
            function ($section) use ($flagLang, $flagTarget, &$flagSections, &$flagLinks) {
                $flagSections++;
                $body = preg_replace_callback('/<a\b[^>]*>[\s\S]*?<\/a\s*>/i',
                    function ($a) use ($flagLang, $flagTarget, &$flagLinks) {
                        if (!preg_match('/<img\b[^>]*\bsrc\s*=\s*["\'][^"\']*flag_lang_' . preg_quote($flagLang, '/') . '\.[^"\']*["\'][^>]*>/i', $a[0])) return $a[0];
                        $targetUrl = 'https://neculaifantanaru.com/' . ($flagLang === 'en' ? 'en/' : '') . $flagTarget;
                        return preg_replace_callback('/(\bhref\s*=\s*)(["\'])(.*?)\2/i',
                            function ($h) use ($targetUrl, &$flagLinks) {
                                $flagLinks++;
                                return $h[1] . $h[2] . $targetUrl . $h[2];
                            }, $a[0], 1);
                    }, $section[2]);
                return $section[1] . $body . $section[3];
            }, $updated);
        if ($updated === null || $flagSections < 1 || $flagLinks < 1) {
            echo json_encode(['ok' => false, 'error' => 'Nu am gasit steagul ' . strtoupper($flagLang) . ' in sectiunea FLAGS.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $changed = $updated !== $raw;
        if ($changed) {
            $backupPath = create_pre_save_backup($full);
            if (!$backupPath) {
                echo json_encode(['ok' => false, 'error' => 'Nu am putut crea backupul inainte de reparare.'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            if (@file_put_contents($full, $updated, LOCK_EX) !== strlen($updated)) {
                @copy($backupPath, $full);
                echo json_encode(['ok' => false, 'error' => 'Scriere incompleta; fisierul anterior a fost restaurat.'], JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
        echo json_encode(['ok' => true, 'changed' => $changed, 'file' => $relative, 'canonical' => $canonicalUrl,
            'flagLang' => $flagLang, 'flagTarget' => $flagTarget], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'categoryPairSync') {
        ini_set('display_errors', '0');
        @set_time_limit(600);
        $reportPath = __DIR__ . '/category-sync-report.json';
        if (isset($_GET['report'])) {
            echo is_file($reportPath) ? file_get_contents($reportPath) : json_encode(['ok' => true, 'changes' => [], 'issues' => []]);
            exit;
        }
        $python = 'C:/Users/necul/AppData/Local/Programs/Python/Python312/python.exe';
        $exclude = $_POST['exclude'] ?? '[]';
        $apply = $_POST['apply'] ?? '[]';
        $errorFile = tempnam(sys_get_temp_dir(), 'catsync');
        $proc = proc_open([$python, __DIR__ . '/sync_ro_en_categories.py', '--exclude', $exclude, '--apply', $apply],
            [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['file', $errorFile, 'a']], $pipes, __DIR__, null, ['bypass_shell' => true]);
        if (!is_resource($proc)) { echo json_encode(['ok' => false, 'error' => 'Nu pot porni verificarea RO–EN']); exit; }
        fclose($pipes[0]); $output = stream_get_contents($pipes[1]); fclose($pipes[1]);
        $code = proc_close($proc); $errors = file_get_contents($errorFile); @unlink($errorFile);
        $data = json_decode($output, true);
        echo json_encode(is_array($data) ? $data : ['ok' => false, 'error' => 'Verificarea RO–EN a eșuat: ' . $errors], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Butonul „Translate”: ruleaza „TRADUCE TOT - automat.py”, care gaseste articolele din ro/ netraduse in en/,
    // le traduce si le duce prin Pasul 0-5 pana in c:\Folder1\fisiere_html.
    //   translateSiteCheck  (GET)  -> lista articolelor netraduse (nu modifica nimic)
    //   translateSiteStart  (POST) -> porneste scriptul in fundal; scrie in jurnalul de mai jos
    //   translateSiteStatus (GET)  -> continutul jurnalului + daca s-a terminat
    if (in_array($action, ['translateSiteCheck', 'translateSiteStart', 'translateSiteStatus'], true)) {
        // Keep PHP diagnostics out of the JSON response; preserve them in the server log.
        ini_set('display_errors', '0');
        $translateBufferLevel = ob_get_level();
        ob_start();
        register_shutdown_function(function () use ($translateBufferLevel) {
            $error = error_get_last();
            if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                while (ob_get_level() > $translateBufferLevel) ob_end_clean();
                http_response_code(500);
                echo json_encode(['ok' => false, 'error' => 'Verificarea a fost întreruptă de server: ' . $error['message']], JSON_UNESCAPED_UNICODE);
            }
        });
        $ttDir = 'e:/Carte/BB/17 - Site Leadership/alte/Ionel Balauta/Aryeht/Task 1 - Traduce tot site-ul/Doar Google Web/Andreea/Meditatii/2023/Iulia Python';
        $ttScript = $ttDir . '/TRADUCE TOT - automat.py';
        $ttBat = $ttDir . '/TRADUCE TOT - din editor.bat';
        $ttLog = str_replace('\\', '/', sys_get_temp_dir()) . '/traduce_tot_editor.log';
        $python = 'C:/Users/necul/AppData/Local/Programs/Python/Python312/python.exe';
        if (!is_file($python)) $python = 'python';
        $readLog = function () use ($ttLog) {
            clearstatcache(true, $ttLog);
            $t = @file_get_contents($ttLog);
            return $t === false ? '' : $t;
        };
        // ruleaza daca jurnalul nu are marcajul de final si s-a scris in ultimele 20 de minute
        $isRunning = function () use ($ttLog, $readLog) {
            if (!is_file($ttLog)) return false;
            if (strpos($readLog(), '[[SFARSIT') !== false) return false;
            return (time() - (int) @filemtime($ttLog)) < 1200;
        };
        if (!is_file($ttScript) || !is_file($ttBat)) {
            echo json_encode(['ok' => false, 'error' => 'Nu gasesc scriptul: ' . (is_file($ttScript) ? $ttBat : $ttScript)], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'translateSiteCheck') {
            @set_time_limit(120);
            try {
                require_once __DIR__ . '/translation-cache.php';
                $pending = json_decode(@file_get_contents(__DIR__ . '/translation-publication.json'), true);
                if (is_array($pending) && empty($pending['complete'])) {
                    $result = ['ok'=>true, 'done'=>true, 'resume'=>true, 'files'=>$pending['articles'] ?? [], 'next'=>0, 'total'=>0, 'translated'=>0];
                } else {
                    $result = translation_cache_step(max(0, (int) ($_GET['cursor'] ?? 0)));
                }
                $result['running'] = $isRunning();
                echo json_encode($result, JSON_UNESCAPED_UNICODE);
            } catch (Throwable $e) {
                echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            }
            exit;
        }

        if ($action === 'translateSiteStart' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($isRunning()) {
                echo json_encode(['ok' => false, 'error' => 'Traducerea ruleaza deja.', 'running' => true], JSON_UNESCAPED_UNICODE);
                exit;
            }
            @file_put_contents($ttLog, "Pornesc scriptul...\n");
            $win = function ($p) { return str_replace('/', '\\', $p); };
            // „start” desprinde procesul de Apache: scriptul merge mai departe si daca se inchide pagina
            $cmd = 'start "Traduce tot - automat" /MIN cmd /c ""' . $win($ttBat) . '" "' . $win($ttLog) . '""';
            $h = @popen($cmd, 'r');
            if ($h === false) {
                echo json_encode(['ok' => false, 'error' => 'Nu am putut porni scriptul.'], JSON_UNESCAPED_UNICODE);
                exit;
            }
            pclose($h);
            echo json_encode(['ok' => true, 'log' => $ttLog], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'translateSiteStatus') {
            $t = $readLog();
            $done = preg_match('/\[\[SFARSIT cod=(-?\d+)\]\]/', $t, $m) === 1;
            echo json_encode(['ok' => true, 'log' => $t, 'done' => $done,
                'success' => $done && $m[1] === '0',
                'running' => $isRunning()], JSON_UNESCAPED_UNICODE);
            exit;
        }
        echo json_encode(['ok' => false, 'error' => 'Cerere invalida.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Cele mai noi N articole dintr-un folder (ro/ sau en/), dupa data „On Luna zi, an” de sub <h1 class="den_articol">.
    // Paginile de categorii/index nu au <h1 den_articol>, deci sunt ignorate.
    // Cache in folderul temp: un fisier e recitit doar daca i s-a schimbat data modificarii.
    // Datele tuturor articolelor dintr-un folder (pentru verificarea datelor duplicate).
    // Intoarce: file, ts (miezul noptii, ora locala), date („On Martie 17, 2009”), cat/catName (categoria).
    if ($action === 'articleDates') {
        $dir = rtrim(resolve_path(isset($_GET['dir']) ? $_GET['dir'] : '', $ROOT), '/');
        @set_time_limit(300);
        if ($dir === '' || !is_dir($dir)) {
            echo json_encode(['ok' => false, 'error' => 'Folderul nu exista: ' . $dir], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // listed = articolul apare într-o pagină de categorie (paginile site-ului — contact,
        // newsletter, termeni… — nu apar și nu contează la datele duplicate)
        $listed = [];
        foreach (scan_category_links_cached($dir) as $c) {
            foreach ($c['links'] as $l) $listed[$l[0]] = true;
        }
        $out = [];
        foreach (scan_article_dates_cached($dir) as $a) {
            // created = data creării fișierului (pe Windows filectime e data creării): în fiecare grup
            // de date duble, cel mai nou fișier e cel la care se propune schimbarea datei
            $out[] = ['file' => $a['file'], 'ts' => $a['ts'], 'date' => $a['date'], 'cat' => $a['cat'], 'catName' => $a['catName'],
                'listed' => isset($listed[strtolower(basename($a['file']))]),
                'created' => (int) @filectime($a['file']), 'mtime' => (int) $a['mtime']];
        }
        echo json_encode(['ok' => true, 'dir' => $dir, 'today' => mktime(0, 0, 0), 'articles' => $out], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Linkurile din paginile de categorie (pentru fereastra Link-Duble)
    if ($action === 'categoryLinks') {
        $dir = rtrim(resolve_path(isset($_GET['dir']) ? $_GET['dir'] : '', $ROOT), '/');
        @set_time_limit(300);
        if ($dir === '' || !is_dir($dir)) {
            echo json_encode(['ok' => false, 'error' => 'Folderul nu exista: ' . $dir], JSON_UNESCAPED_UNICODE);
            exit;
        }
        echo json_encode(['ok' => true, 'dir' => $dir, 'categories' => scan_category_links_cached($dir)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'recentArticles') {
        $dir = rtrim(resolve_path(isset($_GET['dir']) ? $_GET['dir'] : '', $ROOT), '/');
        $limit = max(1, min(10, (int) (isset($_GET['n']) ? $_GET['n'] : 2)));
        @set_time_limit(300); // prima citire (fara cache) poate dura pe un disc lent
        if ($dir === '' || !is_dir($dir)) {
            echo json_encode(['ok' => false, 'error' => 'Folderul nu exista: ' . $dir], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $list = scan_article_dates_cached($dir);
        usort($list, function ($a, $b) {
            if ($a['ts'] !== $b['ts']) return $b['ts'] - $a['ts'];
            return $b['mtime'] - $a['mtime'];
        });
        echo json_encode(['ok' => true, 'articles' => array_slice($list, 0, $limit)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'list') {
        $root = rtrim($ROOT, "/");
        $subdir = isset($_GET['dir']) ? $_GET['dir'] : '';
        $subdir = str_replace(["\\", ".."], ["/", ""], $subdir);
        $subdir = trim($subdir, '/');
        $scanPath = $subdir ? ($root . '/' . $subdir) : $root;
        $out = [];
        if (is_dir($scanPath)) {
            $items = scandir($scanPath);
            foreach ($items as $f) {
                if ($f === '.' || $f === '..')
                    continue;
                $full = $scanPath . '/' . $f;
                $relPath = $subdir ? ($subdir . '/' . $f) : $f;
                if (is_dir($full)) {
                    $out[] = ['type' => 'dir', 'path' => $relPath, 'name' => $f];
                } else {
                    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                    if (in_array($ext, ['html', 'htm', 'css', 'js', 'php'])) {
                        $out[] = ['type' => 'file', 'path' => $relPath, 'name' => $f, 'ext' => $ext];
                    }
                }
            }
        }
        echo json_encode($out, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Search file by name recursively in ROOT
    if ($action === 'search') {
        $name = isset($_GET['name']) ? $_GET['name'] : '';
        $name = basename(str_replace("\\", "/", $name));
        if (!$name) {
            echo json_encode(['ok' => false, 'error' => 'Nume fisier lipsa']);
            exit;
        }
        $results = [];
        // Întâi site-ul: Principal/ro și Principal/en (fișierele „bune”). Copiile identice din
        // backup-uri sau alte foldere vin după ele, ca să nu fie alese în locul originalului.
        foreach (['e:/Carte/BB/17 - Site Leadership/Principal/ro', 'e:/Carte/BB/17 - Site Leadership/Principal/en'] as $siteDir) {
            if (is_file($siteDir . '/' . $name)) $results[] = $siteDir . '/' . $name;
        }
        // Fast method: Windows dir /s /b
        $searchRoot = str_replace('/', '\\', rtrim($ROOT, '/'));
        $cmd = 'dir /s /b "' . $searchRoot . '\\' . $name . '" 2>nul';
        $output = [];
        @exec($cmd, $output);
        $seen = [];
        foreach ($results as $r) $seen[strtolower($r)] = true;
        foreach ($output as $line) {
            $line = trim($line);
            if (!$line) continue;
            $norm = str_replace("\\", "/", $line);
            if (isset($seen[strtolower($norm)])) continue;
            $seen[strtolower($norm)] = true;
            $results[] = $norm;
            if (count($results) >= 20)
                break;
        }
        // Fallback: PHP scandir recursiv (daca exec nu a mers)
        if (empty($results)) {
            $root = rtrim($ROOT, '/');
            $stack = [$root];
            $depth = 0;
            while (!empty($stack) && count($results) < 5) {
                $nextStack = [];
                foreach ($stack as $dir) {
                    $items = @scandir($dir);
                    if (!$items)
                        continue;
                    foreach ($items as $item) {
                        if ($item === '.' || $item === '..')
                            continue;
                        $path = $dir . '/' . $item;
                        if (is_file($path) && strcasecmp($item, $name) === 0) {
                            $results[] = str_replace("\\", "/", $path);
                            if (count($results) >= 5)
                                break 3;
                        } elseif (is_dir($path)) {
                            $nextStack[] = $path;
                        }
                    }
                }
                $stack = $nextStack;
                $depth++;
                if ($depth > 8)
                    break;
            }
        }
        // Also check in extra directories (from recent files, outside $ROOT).
        // MUST run independently of $ROOT results — for common filenames like
        // "index.html", $ROOT may fill all slots and the real file is outside it.
        $extraDirs = isset($_GET['dirs']) ? json_decode($_GET['dirs'], true) : [];
        if (is_array($extraDirs)) {
            $existing = array_flip($results);
            // Step A: exact match in each recent directory
            foreach ($extraDirs as $dir) {
                $dir = str_replace("\\", "/", $dir);
                $dir = str_replace("..", "", $dir);
                $dir = rtrim($dir, '/');
                $candidate = $dir . '/' . $name;
                if (file_exists($candidate) && is_file($candidate)) {
                    $norm = str_replace("\\", "/", $candidate);
                    if (!isset($existing[$norm])) {
                        $results[] = $norm;
                        $existing[$norm] = true;
                    }
                }
            }
            // Step B: broaden search — go up 2 levels from each extra dir
            // and use dir /s /b to recursively search those ancestors.
            $searchRoots = [];
            $rootNorm = rtrim(str_replace("\\", "/", $ROOT), '/');
            foreach ($extraDirs as $dir) {
                $dir = str_replace("\\", "/", $dir);
                $dir = str_replace("..", "", $dir);
                $dir = rtrim($dir, '/');
                // Go up 2 levels
                $ancestor = $dir;
                for ($i = 0; $i < 2; $i++) {
                    $parent = dirname($ancestor);
                    if ($parent === $ancestor || $parent === '.' || strlen($parent) <= 3)
                        break;
                    $ancestor = $parent;
                }
                $ancestor = str_replace("\\", "/", $ancestor);
                // Skip if it's under $ROOT (already searched) or is a drive root
                if (stripos($ancestor, $rootNorm) === 0)
                    continue;
                if (strlen($ancestor) <= 3)
                    continue; // e.g. "D:/"
                $searchRoots[$ancestor] = true;
            }
            foreach (array_keys($searchRoots) as $sr) {
                $srWin = str_replace('/', '\\', $sr);
                $cmd = 'dir /s /b "' . $srWin . '\\' . $name . '" 2>nul';
                $lines = [];
                @exec($cmd, $lines);
                foreach ($lines as $line) {
                    $line = trim($line);
                    if (!$line)
                        continue;
                    $norm = str_replace("\\", "/", $line);
                    if (!isset($existing[$norm])) {
                        $results[] = $norm;
                        $existing[$norm] = true;
                    }
                    if (count($results) >= 20)
                        break;
                }
                if (count($results) >= 20)
                    break;
            }
        }
        echo json_encode(['ok' => true, 'results' => $results]);
        exit;
    }

    // Load file - supports both relative (to ROOT) and absolute paths
    if ($action === 'load') {
        $file = isset($_GET['file']) ? $_GET['file'] : '';
        $full = resolve_path($file, $ROOT);
        if (!file_exists($full)) {
            echo json_encode(['ok' => false, 'error' => 'Fisierul nu exista: ' . $full]);
            exit;
        }
        $txt = read_file_as_utf8($full);
        if ($txt === false) {
            echo json_encode(['ok' => false, 'error' => 'Nu se poate citi fisierul']);
            exit;
        }
        echo json_encode(['ok' => true, 'file' => $full, 'content' => $txt], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Schimbă DOAR data „On Luna zi, an” dintr-un fișier, fără nicio altă modificare
    // (folosit la sincronizarea datei articol ↔ categorie ↔ en). Face backup ca la save.
    //  mode=article: data de sub <h1 class="den_articol">
    //  mode=list&name=x.html: data din blocul articolului x.html într-o pagină de categorie / index
    if ($action === 'replaceArticleDate' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $full = resolve_path(isset($_POST['file']) ? $_POST['file'] : '', $ROOT);
        $mode = isset($_POST['mode']) ? $_POST['mode'] : 'article';
        $name = isset($_POST['name']) ? basename(str_replace('\\', '/', $_POST['name'])) : '';
        $to = isset($_POST['to']) ? trim($_POST['to']) : '';
        if (!is_file($full) || !preg_match('/^On [A-Za-z]+ \d{1,2}, \d{4}$/', $to)) {
            echo json_encode(['ok' => false, 'error' => 'Parametri invalizi sau fisier lipsa: ' . $full], JSON_UNESCAPED_UNICODE);
            exit;
        }
        // expect = data veche (opțional): în listă, alege blocul care o are, nu primul link găsit
        $expect = isset($_POST['expect']) ? preg_replace('/\s+/', ' ', trim($_POST['expect'])) : '';
        $raw = file_get_contents($full);
        $starts = [];
        if ($mode === 'list') {
            if ($name !== '' && preg_match_all('/href\s*=\s*["\'](?:[^"\']*\/)?' . preg_quote($name, '/') . '["\']/i', $raw, $lm, PREG_OFFSET_CAPTURE)) {
                foreach ($lm[0] as $hit) $starts[] = $hit[1];
            }
        } elseif (preg_match('/<h1\b[^>]*class\s*=\s*["\'][^"\']*\bden_articol\b/i', $raw, $hm, PREG_OFFSET_CAPTURE)) {
            $starts[] = $hm[0][1];
        }
        $tm = null;
        $dm = null;
        foreach ($starts as $start) {
            if (!preg_match('/(class\s*=\s*["\'][^"\']*\btext_dreapta\b[^"\']*["\'][^>]*>)(.*?)(<\/td>)/is', $raw, $t, PREG_OFFSET_CAPTURE, $start)) continue;
            if ($t[0][1] - $start > 6000) continue;
            if (!preg_match('/\bOn\s+[^\s\d,<]+\s+\d{1,2},?\s+\d{4}/i', $t[2][0], $d, PREG_OFFSET_CAPTURE)) continue;
            if ($expect !== '' && preg_replace('/\s+/', ' ', $d[0][0]) !== $expect && $d[0][0] !== $to) continue;
            $tm = $t;
            $dm = $d;
            break;
        }
        if ($tm === null) {
            echo json_encode(['ok' => true, 'changed' => false, 'reason' => 'Nu am gasit data']);
            exit;
        }
        if ($dm[0][0] === $to) {
            echo json_encode(['ok' => true, 'changed' => false]);
            exit;
        }
        $at = $tm[2][1] + $dm[0][1];
        $new = substr($raw, 0, $at) . $to . substr($raw, $at + strlen($dm[0][0]));
        // În categorie / index: blocul cu data nouă trebuie să ajungă la locul lui în listă
        $sortedFlag = false;
        if ($mode === 'list') {
            $sorted = sort_list_blocks_by_date_php($new);
            if ($sorted !== null && strlen($sorted) === strlen($new)) { $new = $sorted; $sortedFlag = true; }
        }
        $backupPath = create_pre_save_backup($full);
        if (@file_put_contents($full, $new, LOCK_EX) !== strlen($new)) {
            if ($backupPath && is_file($backupPath)) @copy($backupPath, $full);
            echo json_encode(['ok' => false, 'error' => 'Scriere incompleta; fisierul anterior a fost restaurat.']);
            exit;
        }
        echo json_encode(['ok' => true, 'changed' => true, 'from' => $dm[0][0], 'sorted' => $sortedFlag], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Sortează după dată lista de articole a unei pagini de categorie / index (fără alte schimbări)
    if ($action === 'sortListByDate' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $full = resolve_path(isset($_POST['file']) ? $_POST['file'] : '', $ROOT);
        if (!is_file($full)) {
            echo json_encode(['ok' => false, 'error' => 'Fisier lipsa: ' . $full], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $raw = file_get_contents($full);
        $sorted = sort_list_blocks_by_date_php($raw);
        if ($sorted === null || strlen($sorted) !== strlen($raw)) {
            echo json_encode(['ok' => true, 'changed' => false]);
            exit;
        }
        $backupPath = create_pre_save_backup($full);
        if (@file_put_contents($full, $sorted, LOCK_EX) !== strlen($sorted)) {
            if ($backupPath && is_file($backupPath)) @copy($backupPath, $full);
            echo json_encode(['ok' => false, 'error' => 'Scriere incompleta; fisierul anterior a fost restaurat.']);
            exit;
        }
        echo json_encode(['ok' => true, 'changed' => true]);
        exit;
    }

    // Save file - supports both relative and absolute paths
    if ($action === 'save' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $file = isset($_POST['file']) ? $_POST['file'] : '';
        $full = resolve_path($file, $ROOT);
        // Template-ul pentru butonul NEW nu se suprascrie niciodata din editor.
        if (in_array(strtolower(basename(str_replace('\\', '/', $full))), ['model-new', 'model-new.html'], true)) {
            echo json_encode(['ok' => false, 'error' => 'model-new este template si nu poate fi suprascris. Schimba CANONICAL LINK si salveaza ca pagina noua.'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $dir = dirname($full);
        if (!is_dir($dir)) {
            echo json_encode(['ok' => false, 'error' => 'Directorul nu exista: ' . $dir]);
            exit;
        }
        $content = isset($_POST['content']) ? $_POST['content'] : '';
        $extSave = strtolower(pathinfo($full, PATHINFO_EXTENSION));
        $metaSynced = false;
        $existingOnDisk = file_exists($full) ? read_file_as_utf8($full) : false;
        if (($extSave === 'html' || $extSave === 'htm') && $content !== '') {
            $beforeMeta = $content;
            $content = remove_orphan_closing_spans_from_paragraphs_php($content);
            $content = normalize_text_paragraph_inline_formatting_php($content);
            $content = join_sasa_paragraph_closing_tags_php($content);
            $content = align_saved_html_charset_declaration_utf8($content);
            $content = apply_sasa_teaser_to_meta_description_php($content);
            $content = apply_h1_to_page_titles_php($content);
            if ($existingOnDisk !== false) {
                $content = restore_protected_body_scripts_php($existingOnDisk, $content);
            }
            $metaSynced = ($content !== $beforeMeta);
        }
        if ($existingOnDisk !== false && ($extSave === 'html' || $extSave === 'htm')) {
            $truncateReason = '';
            if (html_save_is_catastrophically_truncated($existingOnDisk, $content, $truncateReason)) {
                echo json_encode([
                    'ok' => false,
                    'error' => 'Salvare blocata pentru protectia datelor. ' . $truncateReason
                ], JSON_UNESCAPED_UNICODE);
                exit;
            }
        }

        $backupPath = ($existingOnDisk !== false) ? create_pre_save_backup($full) : false;
        $written = @file_put_contents($full, $content, LOCK_EX);
        if ($written === false || $written !== strlen($content)) {
            if ($backupPath && is_file($backupPath)) {
                @copy($backupPath, $full);
            }
            echo json_encode(['ok' => false, 'error' => 'Scriere incompleta; fisierul anterior a fost restaurat.']);
            exit;
        }
        echo json_encode([
            'ok' => true,
            'file' => $full,
            'metaSynced' => $metaSynced,
            'backup' => $backupPath ? str_replace('\\', '/', $backupPath) : null
        ]);
        exit;
    }

    // ── Web proxy: fetch external URLs server-side to bypass X-Frame-Options ──
    if ($action === 'webproxy') {
        $url = isset($_GET['url']) ? $_GET['url'] : '';
        if (!$url || !preg_match('#^https?://#i', $url)) {
            header('Content-Type: text/html; charset=utf-8');
            echo '<h3>URL invalid</h3>';
            exit;
        }
        // Build the base URL for rewriting relative links
        $parsed = parse_url($url);
        $baseOrigin = $parsed['scheme'] . '://' . $parsed['host'] . (isset($parsed['port']) ? ':' . $parsed['port'] : '');
        $basePath = isset($parsed['path']) ? dirname($parsed['path']) : '/';
        if ($basePath === '\\' || $basePath === '.') $basePath = '/';
        $baseHref = $baseOrigin . $basePath . '/';

        $ctx = stream_context_create([
            'http' => [
                'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36\r\n" .
                            "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n" .
                            "Accept-Language: ro,en;q=0.9\r\n",
                'follow_location' => true,
                'timeout' => 15
            ],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
        ]);
        $html = @file_get_contents($url, false, $ctx);
        if ($html === false) {
            header('Content-Type: text/html; charset=utf-8');
            echo '<html><body style="font-family:sans-serif;padding:40px;text-align:center"><h3>Nu s-a putut incarca pagina</h3><p>' . htmlspecialchars($url) . '</p></body></html>';
            exit;
        }
        // Inject <base href> so relative URLs resolve correctly
        $baseTag = '<base href="' . htmlspecialchars($baseHref) . '" target="_self">';
        if (preg_match('/<head(\s|>)/i', $html)) {
            $html = preg_replace('/<head(\s|>)/i', '<head$1' . $baseTag, $html, 1);
        } else {
            $html = $baseTag . $html;
        }
        // Rewrite links to go through proxy so navigation stays inside the iframe
        $selfUrl = strtok($_SERVER['REQUEST_URI'], '?');
        // Inject a tiny script that intercepts link clicks and form submits
        $proxyScript = '<script>
        document.addEventListener("click", function(e) {
            var a = e.target.closest("a[href]");
            if (!a) return;
            var href = a.href;
            if (!href || href.startsWith("javascript:") || href.startsWith("#")) return;
            e.preventDefault();
            window.location.href = "' . $selfUrl . '?action=webproxy&url=" + encodeURIComponent(href);
        }, true);
        document.addEventListener("submit", function(e) {
            var form = e.target;
            if (form.method && form.method.toLowerCase() === "post") return;
            e.preventDefault();
            var fd = new FormData(form);
            var params = new URLSearchParams(fd).toString();
            var action = form.action || window.location.href;
            var sep = action.includes("?") ? "&" : "?";
            window.location.href = "' . $selfUrl . '?action=webproxy&url=" + encodeURIComponent(action + sep + params);
        }, true);
        // Notify parent of URL changes
        try { window.parent.postMessage({type:"proxyUrlChange", url: "' . addslashes($url) . '"}, "*"); } catch(e){}
        </script>';
        // Insert before </body> or at end
        if (stripos($html, '</body>') !== false) {
            $html = str_ireplace('</body>', $proxyScript . '</body>', $html);
        } else {
            $html .= $proxyScript;
        }
        header('Content-Type: text/html; charset=utf-8');
        echo $html;
        exit;
    }

    // ── API: text translation via Google Translate public endpoint (no API key) ──
    if (isset($_GET['action']) && $_GET['action'] === 'translate') {
        header('Content-Type: application/json; charset=utf-8');
        $sl = isset($_GET['sl']) ? $_GET['sl'] : 'auto';
        $tl = isset($_GET['tl']) ? $_GET['tl'] : 'en';
        $q = isset($_GET['q']) ? $_GET['q'] : '';
        $q = trim($q);
        if ($q === '') {
            echo json_encode(['ok' => false, 'error' => 'Text gol.']);
            exit;
        }

        $translated = false;

        // ── Method 1: cURL with Google Translate (client=gtx) ──
        if (function_exists('curl_init')) {
            $apiUrl = 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t'
                . '&sl=' . urlencode($sl)
                . '&tl=' . urlencode($tl)
                . '&q=' . urlencode($q);
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $apiUrl,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 10,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept: */*',
                ],
            ]);
            $resp = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($resp !== false && $httpCode === 200) {
                $data = json_decode($resp, true);
                if (is_array($data) && isset($data[0]) && is_array($data[0])) {
                    $translated = '';
                    foreach ($data[0] as $chunk) {
                        if (isset($chunk[0])) $translated .= $chunk[0];
                    }
                }
            }
        }

        // ── Method 2: fallback file_get_contents ──
        if ($translated === false) {
            $apiUrl = 'https://translate.googleapis.com/translate_a/single?client=gtx&dt=t'
                . '&sl=' . urlencode($sl)
                . '&tl=' . urlencode($tl)
                . '&q=' . urlencode($q);
            $ctx = stream_context_create([
                'http' => [
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36\r\nAccept: */*\r\n",
                    'timeout' => 10
                ],
                'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
            ]);
            $resp = @file_get_contents($apiUrl, false, $ctx);
            if ($resp !== false) {
                $data = json_decode($resp, true);
                if (is_array($data) && isset($data[0]) && is_array($data[0])) {
                    $translated = '';
                    foreach ($data[0] as $chunk) {
                        if (isset($chunk[0])) $translated .= $chunk[0];
                    }
                }
            }
        }

        if ($translated !== false && $translated !== '') {
            echo json_encode(['ok' => true, 'text' => $translated]);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Nu s-a putut traduce. Verifică conexiunea la internet.']);
        }
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Actiune necunoscuta']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="ro">

<head>
    <meta charset="UTF-8">
    <title>Mini Dreamweaver - Editor HTML/PHP</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">
    <link rel="icon" type="image/png" sizes="256x256" href="favicon-256.png">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#252633">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="HTML Editor">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/theme/material-darker.min.css">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0
        }

        body {
            font-family: Segoe UI, system-ui, sans-serif;
            background: #1e1f26;
            color: #eaeaea;
            height: 100vh;
            display: flex;
            flex-direction: column;
            font-size: 17px
        }

        .topbar {
            background: #252633;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid #333;
            font-size: 16px
        }

        .brand {
            font-weight: 700;
            color: #fff;
            font-size: 18px
        }

        /* ---- Tab Bar ---- */
        #tabBar {
            display: flex;
            align-items: center;
            gap: 2px;
            flex: 1;
            min-width: 0;
            overflow-x: auto;
            overflow-y: hidden;
            scrollbar-width: thin;
            padding: 2px 0;
        }

        #tabBar::-webkit-scrollbar {
            height: 4px
        }

        #tabBar::-webkit-scrollbar-thumb {
            background: #4b5563;
            border-radius: 2px
        }

        .editor-tab {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 10px;
            background: #1e1f26;
            color: #9ca3af;
            border-radius: 6px 6px 0 0;
            border: 1px solid #333;
            border-bottom: none;
            font-size: 13px;
            cursor: pointer;
            white-space: nowrap;
            max-width: 180px;
            min-width: 60px;
            user-select: none;
            flex-shrink: 0;
            transition: background .15s, color .15s;
        }

        .editor-tab:hover {
            background: #2b2c3a;
            color: #e5e7eb
        }

        .editor-tab.active {
            background: #252633;
            color: #fff;
            border-color: #3b82f6;
            border-bottom: 1px solid #252633;
            font-weight: 600;
        }

        .editor-tab.dirty .tab-label::after {
            content: ' \2731';
            color: #facc15;
            font-size: 13px;
            vertical-align: middle;
            margin-left: 1px
        }

        .editor-tab.drag-over {
            border-left: 3px solid #3b82f6
        }

        .editor-tab.dragging {
            opacity: 0.4
        }

        .tab-label {
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 140px
        }

        .tab-close {
            font-size: 16px;
            line-height: 1;
            color: #6b7280;
            border-radius: 3px;
            padding: 0 3px;
            margin-left: 2px;
        }

        .tab-close:hover {
            background: #ef4444;
            color: #fff
        }

        .tab-new {
            font-size: 18px;
            font-weight: 700;
            color: #6b7280;
            padding: 5px 12px;
            border: 1px dashed #4b5563;
            background: transparent;
            min-width: auto;
        }

        .tab-new:hover {
            color: #3b82f6;
            border-color: #3b82f6
        }

        #tabBar.file-drag-over,
        #tabBarSpacer.file-drag-over {
            background: rgba(59, 130, 246, 0.15);
            border-radius: 6px;
        }

        #tabBar.file-drag-over .tab-new {
            color: #3b82f6;
            border-color: #3b82f6;
            border-style: solid;
            background: rgba(59, 130, 246, 0.2);
        }

        #tabBarSpacer.file-drag-over {
            position: relative;
        }

        #tabBarSpacer.file-drag-over::after {
            content: 'Drop fisier aici';
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            color: #3b82f6;
            font-size: 12px;
            white-space: nowrap;
            pointer-events: none;
        }

        .btn {
            padding: 7px 14px;
            border: none;
            border-radius: 4px;
            font-size: 15px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 5px
        }

        .btn-primary {
            background: #3b82f6;
            color: #fff
        }

        .btn-ghost {
            background: #2b2c3a;
            color: #ccc
        }

        .btn-primary:hover {
            background: #2563eb
        }

        .btn-ghost:hover {
            background: #3b3d4d
        }

        .main {
            flex: 1;
            display: flex;
            min-height: 0
        }

        .sidebar {
            width: 280px;
            min-width: 280px;
            background: #181924;
            border-right: 1px solid #333;
            overflow: auto;
            padding: 10px;
            transition: min-width 0.2s, width 0.2s, padding 0.2s, border 0.2s;
        }

        .sidebar.collapsed {
            width: 0 !important;
            min-width: 0 !important;
            padding: 0 !important;
            overflow: hidden !important;
            border-right: none !important;
        }

        #btnToggleSidebar {
            font-size: 18px;
            padding: 5px 10px;
            line-height: 1;
        }

        .sidebar h3 {
            font-size: 17px;
            margin-bottom: 8px;
            color: #9ca3af;
            text-transform: uppercase;
            letter-spacing: .6px
        }

        .file {
            padding: 6px 10px;
            font-size: 17px;
            cursor: pointer;
            border-radius: 3px;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        .file:hover {
            background: #2a2b3a
        }

        .file.active {
            background: #3b82f6;
            color: #fff
        }

        .file .path {
            opacity: .6;
            font-size: 14px
        }

        .dir {
            padding: 4px 6px;
            font-size: 16px;
            color: #9ca3af;
            margin-top: 4px
        }

        .dir span {
            opacity: .7
        }

        .center {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0
        }

        .tabs {
            background: #181924;
            border-bottom: 1px solid #333;
            padding: 8px 12px;
            font-size: 16px;
            color: #9ca3af;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        .split {
            flex: 1;
            display: flex;
            min-height: 0;
            position: relative
        }

        .editor-pane {
            flex: 1;
            border-right: 1px solid #333;
            display: flex;
            flex-direction: column;
            min-width: 0;
            overflow: hidden
        }

        .editor-header {
            padding: 8px 12px;
            font-size: 16px;
            background: #20212c;
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        .preview-pane {
            flex: 1;
            display: flex;
            flex-direction: column;
            min-width: 0;
            overflow: hidden
        }

        .preview-header {
            padding: 8px 12px;
            font-size: 16px;
            background: #20212c;
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center
        }

        iframe {
            flex: 1;
            border: none;
            background: #fff
        }

        .viewmode-tabs {
            display: inline-flex;
            border: 1px solid #4b5563;
            border-radius: 6px;
            overflow: hidden;
            margin-bottom: 6px;
            font-size: 14px
        }

        .viewmode-tabs button {
            background: #111827;
            border: none;
            color: #e5e7eb;
            padding: 4px 10px;
            cursor: pointer
        }

        .viewmode-tabs button.active {
            background: #e5e7eb;
            color: #111827;
            font-weight: 600
        }

        .viewmode-tabs button+button {
            border-left: 1px solid #4b5563
        }

        .split.mode-code .preview-pane {
            display: none
        }

        .split.mode-code .editor-pane {
            flex: 1;
            border-right: none
        }

        .split.mode-design .editor-pane {
            display: none
        }

        .split.mode-design .preview-pane {
            flex: 1
        }

        .split.mode-split .editor-pane {
            display: flex
        }

        .split.mode-split .preview-pane {
            display: flex
        }

        .split .divider {
            width: 6px;
            cursor: col-resize;
            background: #111827;
            border-left: 1px solid #333;
            border-right: 1px solid #333;
            z-index: 10;
            position: relative
        }

        .split-overlay {
            position: absolute;
            inset: 0;
            cursor: col-resize;
            z-index: 20;
            display: none
        }

        .status {
            font-size: 15px;
            color: #9ca3af
        }

        .cm-editor {
            height: 100%
        }

        .cm-s-material-darker {
            background: #111827;
            color: #e5e7eb;
            font-size: 17px
        }

        .CodeMirror-selected {
            background: rgba(250, 204, 21, 0.25) !important
        }

        .CodeMirror-focused .CodeMirror-selected {
            background: rgba(250, 204, 21, 0.35) !important
        }

        .cm-sync-highlight {
            background: rgba(250, 204, 21, 0.25) !important;
            transition: background 0.9s ease-out
        }

        /* Yellow highlight for text selected in design panel, shown in code editor */
        .cm-selection-highlight {
            background: rgba(250, 204, 21, 0.45) !important;
        }

        /* Find & Replace match highlights in code editor */
        .cm-find-highlight {
            background: rgba(255, 165, 0, 0.35) !important;
            border-bottom: 1px solid #f59e0b;
        }

        .properties-panel {
            background: #20212c;
            border-top: 1px solid #333;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            font-size: 15px;
            min-height: 46px
        }

        .properties-panel label {
            color: #9ca3af;
            margin-right: 2px
        }

        .properties-panel select,
        .properties-panel input[type="number"] {
            background: #15161d;
            border: 1px solid #444;
            border-radius: 4px;
            padding: 5px 10px;
            color: #eee;
            font-size: 14px
        }

        .properties-panel input[type="color"] {
            width: 30px;
            height: 26px;
            padding: 2px;
            cursor: pointer;
            border-radius: 4px;
            border: 1px solid #444
        }

        .properties-panel .prop-btn {
            padding: 5px 12px;
            min-width: 34px;
            font-weight: 700;
            height: 30px
        }

        /* Diacritics popup */
        .diac-popup {
            position: fixed;
            background: #252633;
            border: 1px solid #4b5563;
            border-radius: 8px;
            padding: 14px 18px;
            z-index: 3100;
            box-shadow: 0 8px 32px rgba(0,0,0,.5);
            display: none;
            min-width: 260px;
            color: #e5e7eb;
            font-size: 13px;
            max-height: calc(100vh - 80px);
            overflow: hidden;
        }

        /* Dimensiune minimă/implicită pentru panoul de traducere */
        #translatePopup {
            width: 520px;
            min-width: 520px;
            min-height: 260px;
        }
        .diac-popup.visible { display: block; }
        .diac-popup h4 {
            margin: 0 0 10px;
            font-size: 14px;
            color: #93c5fd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .diac-popup .diac-close {
            background: none;
            border: none;
            color: #9ca3af;
            font-size: 18px;
            cursor: pointer;
            padding: 0 2px;
            line-height: 1;
        }
        .diac-popup .diac-close:hover { color: #fff; }
        .diac-popup.resizable {
            resize: both;
            overflow: auto;
        }
        .diac-popup .drag-handle {
            cursor: move;
        }
        .diac-popup table { width: 100%; border-collapse: collapse; }
        .diac-popup th {
            text-align: left;
            padding: 3px 6px;
            color: #9ca3af;
            font-weight: 500;
            font-size: 11px;
            border-bottom: 1px solid #374151;
        }
        .diac-popup td { padding: 4px 6px; }
        .diac-popup td:first-child {
            font-size: 18px;
            text-align: center;
            width: 36px;
        }
        .diac-popup td:last-child {
            color: #9ca3af;
            font-size: 12px;
            font-family: monospace;
        }
        .diac-popup tr { cursor: pointer; border-radius: 4px; }
        .diac-popup tr:hover td { background: #374151; }

        /* Find & Replace dialog */
        .find-replace-dialog {
            position: fixed;
            top: 60px;
            right: 30px;
            background: #252633;
            border: 1px solid #4b5563;
            border-radius: 8px;
            padding: 16px 20px;
            z-index: 3000;
            box-shadow: 0 8px 32px rgba(0, 0, 0, .5);
            min-width: 420px;
            display: none;
            font-size: 14px;
        }

        .find-replace-dialog.visible {
            display: block;
        }

        .find-replace-dialog h4 {
            margin: 0 0 12px 0;
            color: #e5e7eb;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .find-replace-dialog .fr-close {
            background: none;
            border: none;
            color: #9ca3af;
            font-size: 20px;
            cursor: pointer;
            padding: 0 4px;
            line-height: 1;
        }

        .find-replace-dialog .fr-close:hover {
            color: #fff;
        }

        .find-replace-dialog .fr-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
        }

        .find-replace-dialog .fr-row label {
            color: #9ca3af;
            min-width: 70px;
            text-align: right;
        }

        .find-replace-dialog .fr-row input[type="text"] {
            flex: 1;
            background: #15161d;
            border: 1px solid #444;
            border-radius: 4px;
            padding: 6px 10px;
            color: #eee;
            font-size: 14px;
        }

        .find-replace-dialog .fr-row input[type="text"]:focus {
            outline: none;
            border-color: #3b82f6;
        }

        .find-replace-dialog .fr-btns {
            display: flex;
            gap: 8px;
            margin-top: 12px;
            justify-content: flex-end;
        }

        .find-replace-dialog .fr-btns button {
            padding: 6px 14px;
            border: none;
            border-radius: 4px;
            font-size: 13px;
            cursor: pointer;
        }

        /* Generic error popup with selectable text */
        .error-popup {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.75);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 4000;
        }

        .error-popup.visible {
            display: flex;
        }

        .error-popup-inner {
            background: #111827;
            border: 1px solid #4b5563;
            border-radius: 8px;
            padding: 16px 18px;
            width: 520px;
            max-width: 95vw;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.7);
        }

        .error-popup-title {
            color: #f87171;
            font-weight: 600;
            margin-bottom: 8px;
        }

        .error-popup-inner textarea {
            width: 100%;
            min-height: 90px;
            resize: vertical;
            background: #020617;
            border: 1px solid #4b5563;
            color: #e5e7eb;
            font-family: Consolas, monospace;
            font-size: 13px;
            padding: 8px;
            border-radius: 4px;
        }

        .error-popup-buttons {
            margin-top: 10px;
            text-align: right;
        }

        .error-popup-buttons button {
            background: #374151;
            color: #e5e7eb;
            border: none;
            border-radius: 4px;
            padding: 6px 12px;
            cursor: pointer;
            font-size: 13px;
        }

        .error-popup-buttons button:hover {
            background: #4b5563;
        }

        /* Reusable button styles (Find & Replace + Translate panel) */
        .fr-btn-primary {
            background: #3b82f6;
            color: #fff;
            border: none;
            border-radius: 4px;
            padding: 6px 14px;
            font-size: 13px;
            cursor: pointer;
        }

        .fr-btn-primary:hover {
            background: #2563eb;
        }

        .fr-btn-ghost {
            background: #2b2c3a;
            color: #ccc;
            border: none;
            border-radius: 4px;
            padding: 6px 14px;
            font-size: 13px;
            cursor: pointer;
        }

        .fr-btn-ghost:hover {
            background: #3b3d4d;
        }

        .find-replace-dialog .fr-options {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 10px;
        }

        .find-replace-dialog .fr-options label {
            color: #9ca3af;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .find-replace-dialog .fr-info {
            color: #9ca3af;
            font-size: 13px;
            margin-top: 8px;
        }

        /* Overlay start dialog */
        .overlay {
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, .92);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 2000
        }

        .overlay-card {
            width: 960px;
            max-width: 95%;
            max-height: 90vh;
            overflow-y: auto;
            background: #020617;
            border-radius: 16px;
            box-shadow: 0 24px 80px rgba(0, 0, 0, .6);
            border: 1px solid #1f2937;
            padding: 34px 34px 26px;
            color: #e5e7eb
        }

        .overlay-row {
            display: flex;
            gap: 20px;
            align-items: flex-start
        }

        .overlay-row .drop-zone {
            flex: 1;
            min-width: 0
        }

        .overlay-row .recent-panel {
            flex: 1;
            min-width: 0;
            max-height: 280px;
            overflow-y: auto
        }

        .overlay-title {
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 12px
        }

        .overlay-sub {
            font-size: 18px;
            color: #9ca3af;
            margin-bottom: 22px
        }

        .drop-zone {
            border: 2px dashed #4b5563;
            border-radius: 14px;
            padding: 48px 28px;
            text-align: center;
            background: rgba(15, 23, 42, .8);
            cursor: pointer;
            transition: .15s all;
            font-size: 18px
        }

        .drop-zone.over {
            border-color: #3b82f6;
            background: rgba(37, 99, 235, .12)
        }

        .drop-zone i {
            font-size: 50px;
            color: #3b82f6;
            margin-bottom: 14px
        }

        .drop-zone .drop-label {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 8px
        }

        .drop-zone .drop-hint {
            font-size: 16px;
            color: #9ca3af
        }

        .drop-main {
            margin-top: 22px;
            font-size: 17px;
            color: #9ca3af
        }

        .overlay-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 24px;
            font-size: 17px
        }

        .recent-item {
            padding: 7px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 15px;
            color: #d1d5db;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: background .15s;
            text-align: left;
        }

        .recent-item:hover {
            background: #2a2b3a;
            color: #fff
        }

        .recent-item .recent-icon {
            color: #60a5fa;
            font-size: 13px;
            flex-shrink: 0
        }

        .recent-item .recent-name-wrap {
            flex: 1;
            overflow: hidden;
            min-width: 0
        }

        .recent-item .recent-name {
            font-weight: 500;
            color: #eee;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: block
        }

        .recent-item .recent-folder {
            font-size: 11px;
            color: #6b7280;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: block;
            margin-top: 1px
        }

        /* × din dreapta: apare doar la hover, scoate fișierul din lista de recente */
        .recent-item .recent-remove {
            flex-shrink: 0;
            width: 24px;
            height: 24px;
            border: 0;
            border-radius: 50%;
            background: transparent;
            color: #9ca3af;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            cursor: pointer;
            opacity: 0;
            transition: opacity .15s, background .15s, color .15s
        }

        .recent-item:hover .recent-remove,
        .recent-item .recent-remove:focus-visible {
            opacity: 1
        }

        .recent-item .recent-remove:hover {
            background: #ef4444;
            color: #fff
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>

<body>
    <!-- Save Confirm Dialog -->
    <div id="saveConfirmOverlay"
        style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:10000;align-items:center;justify-content:center"
        onkeydown="if(event.key==='Escape' && _saveConfirmResolve) _saveConfirmResolve('cancel');">
        <div
            style="background:#252633;border:1px solid #3b82f6;border-radius:10px;padding:24px 30px;max-width:420px;color:#eaeaea;font-size:15px;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,.5)">
            <div id="saveConfirmMsg" style="margin-bottom:20px;line-height:1.5"></div>
            <div style="display:flex;gap:10px;justify-content:center">
                <button onclick="_saveConfirmResolve('save')"
                    style="padding:8px 20px;background:#3b82f6;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:14px">Salveaza</button>
                <button onclick="_saveConfirmResolve('no')"
                    style="padding:8px 20px;background:#ef4444;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:14px">Nu</button>
                <button onclick="_saveConfirmResolve('cancel')"
                    style="padding:8px 20px;background:#4b5563;color:#fff;border:none;border-radius:5px;cursor:pointer;font-size:14px">Cancel</button>
            </div>
        </div>
    </div>
    <!-- Diacritics Popup -->
    <div class="diac-popup" id="diacPopup" onkeydown="if(event.key==='Escape') closeDiacPopup();" tabindex="-1">
        <h4 class="drag-handle">Diacritice <button class="diac-close" onclick="closeDiacPopup()" title="Inchide">&times;</button></h4>
        <table>
            <tr><th>Char</th><th>Descriere</th><th>Shortcut</th></tr>
            <tr onclick="insertDiac('ă')"><td>ă</td><td>a cu breve</td><td>Ctrl + A</td></tr>
            <tr onclick="insertDiac('â')"><td>â</td><td>a cu circumflex</td><td>Alt + A</td></tr>
            <tr onclick="insertDiac('î')"><td>î</td><td>i cu circumflex</td><td>Ctrl + I</td></tr>
            <tr onclick="insertDiac('Î')"><td>Î</td><td>I cu circumflex (mare)</td><td>Alt + I</td></tr>
            <tr onclick="insertDiac('ș')"><td>ș</td><td>s cu virgulă</td><td>Ctrl + Shift + S</td></tr>
            <tr onclick="insertDiac('Ș')"><td>Ș</td><td>S cu virgulă (mare)</td><td>Alt + S</td></tr>
            <tr onclick="insertDiac('ț')"><td>ț</td><td>t cu virgulă</td><td>Alt + T</td></tr>
            <tr onclick="insertDiac('Ț')"><td>Ț</td><td>T cu virgulă (mare)</td><td>Alt + Shift + T</td></tr>
        </table>
    </div>
    <!-- Find & Replace Dialog -->
    <div class="find-replace-dialog" id="findReplaceDialog" onkeydown="if(event.key==='Escape') closeFindReplace();">
        <h4>Find & Replace <button class="fr-close" onclick="closeFindReplace()" title="Close">&times;</button></h4>
        <div class="fr-row">
            <label>Find:</label>
            <input type="text" id="frFindInput" placeholder="Search text..."
                oninput="_frLastQuery='__invalidated__';"
                onkeydown="if(event.key==='Escape'){closeFindReplace();} else if(event.key==='Enter'){event.preventDefault();findNext();} else if(event.key==='F3'){event.preventDefault();event.shiftKey?findPrev():findNext();}">
        </div>
        <div class="fr-row">
            <label>Replace:</label>
            <input type="text" id="frReplaceInput" placeholder="Replace with..."
                onkeydown="if(event.key==='Escape'){closeFindReplace();} else if(event.key==='Enter'){event.preventDefault();replaceCurrent();}">
        </div>
        <div class="fr-options">
            <label><input type="checkbox" id="frCaseSensitive" onchange="_frLastQuery='__invalidated__';findNext();"> Case sensitive</label>
            <label><input type="checkbox" id="frWholeWord" onchange="_frLastQuery='__invalidated__';findNext();"> Whole word</label>
        </div>
        <div class="fr-btns">
            <button class="fr-btn-ghost" onclick="findNext()">Find Next</button>
            <button class="fr-btn-ghost" onclick="findPrev()">Find Prev</button>
            <button class="fr-btn-primary" onclick="replaceCurrent()">Replace</button>
            <button class="fr-btn-primary" onclick="replaceAll()">Replace All</button>
        </div>
        <div class="fr-info" id="frInfo"></div>
    </div>

    <div class="overlay" id="startOverlay">
        <div class="overlay-card">
            <div class="overlay-title">Deschide un fisier</div>
            <div class="overlay-sub">Scrie calea completa, trage un fisier, sau click pe zona de mai jos.</div>
            <div style="display:flex;gap:8px;margin-bottom:18px">
                <input type="text" id="pathInput" placeholder="Ex: e:/Carte/BB/fisier.html"
                    style="flex:1;background:#15161d;border:1px solid #444;border-radius:6px;padding:10px 12px;color:#eee;font-size:16px">
                <button class="btn btn-primary" onclick="openFromPath()" style="white-space:nowrap">Deschide</button>
            </div>
            <div class="overlay-row">
                <div class="drop-zone" id="dropZone">
                    <i class="fas fa-file-code"></i>
                    <div class="drop-label">Drag &amp; Drop fisier aici</div>
                    <div class="drop-hint">sau click pentru a alege un fisier</div>
                    <div id="dropStatus" style="margin-top:12px;font-size:15px;color:#facc15;display:none"></div>
                </div>
                <div class="recent-panel" id="recentFilesSection" style="display:none">
                    <div style="color:#9ca3af;font-size:14px;margin-bottom:8px;font-weight:600">Fisiere recente:</div>
                    <div id="recentFilesList"></div>
                </div>
            </div>
            <input type="file" id="filePicker" accept=".html,.htm,.css,.js,.php" style="display:none">
            <div class="overlay-actions">
                <button class="btn" id="btnSendArticleEmail" onclick="sendLatestArticleEmail()"
                    title="Trimite pe email ultimul articol din ro/index.html (ruleaza monitor_index.py in fundal)"
                    style="background:#16a34a;color:#fff;border-color:#15803d"><i class="fas fa-envelope"></i> Trimite E-mail</button>
                <button class="btn" style="background:#ea580c;color:white" onclick="generateRssFeeds(this)"><i class="fas fa-rss"></i> RSS</button>
                <button class="btn" id="btnTranslateSite" onclick="translateUntranslatedArticles()"
                    title="Gaseste articolele din ro/ netraduse in en/, le traduce si le duce in c:\Folder1\fisiere_html (TRADUCE TOT - automat.py)"
                    style="background:#0891b2;color:#fff;border-color:#0e7490"><i class="fas fa-language"></i> Translate</button>
                <button class="btn" id="btnDateDuble" onclick="openDateDuplicatesFromStart()"
                    title="Arată articolele din ro/ și en/ care au aceeași dată"
                    style="background:#dc2626;color:#fff;border-color:#b91c1c"><i class="fas fa-calendar-times"></i> Date-Duble</button>
                <button class="btn" id="btnLinkDuble" onclick="runLinkDuplicateCheck()"
                    title="Arată articolele care apar de 2+ ori în paginile de categorie din ro/ sau en/"
                    style="background:#7c3aed;color:#fff;border-color:#6d28d9"><i class="fas fa-link"></i> Link-Duble</button>
                <button class="btn btn-primary" onclick="openNewFromModel()" title="Deschide model.html">NEW</button>
                <button class="btn btn-ghost" onclick="continueToEditor()">Continua la editor</button>
            </div>
        </div>
    </div>
    <!-- Translation Panel -->
    <div class="diac-popup" id="translatePopup" onkeydown="if(event.key==='Escape') closeTranslatePopup();" tabindex="-1" style="max-width:520px">
        <h4 class="drag-handle">Traducere <button class="diac-close" onclick="closeTranslatePopup()" title="Inchide">&times;</button></h4>
        <div style="display:flex;gap:10px;margin-bottom:8px">
            <div style="flex:1">
                <label style="font-size:11px;color:#9ca3af">Din limba</label>
                <select id="trSourceLang" style="width:100%;padding:4px 6px;border-radius:4px;border:1px solid #4b5563;background:#1f2937;color:#e5e7eb;font-size:12px">
                    <option value="auto">Detectează automat</option>
                    <option value="ro" selected>Română</option>
                    <option value="en">Engleză</option>
                </select>
            </div>
            <div style="flex:1">
                <label style="font-size:11px;color:#9ca3af">În limba</label>
                <select id="trTargetLang" style="width:100%;padding:4px 6px;border-radius:4px;border:1px solid #4b5563;background:#1f2937;color:#e5e7eb;font-size:12px">
                    <option value="en" selected>Engleză</option>
                    <option value="ro">Română</option>
                    <option value="fr">Franceză</option>
                    <option value="de">Germană</option>
                    <option value="es">Spaniolă</option>
                    <option value="it">Italiană</option>
                </select>
            </div>
        </div>
        <div style="display:flex;gap:10px">
            <div style="flex:1;display:flex;flex-direction:column">
                <label style="font-size:11px;color:#9ca3af">Text sursă</label>
                <textarea id="trSourceText" rows="6" style="width:100%;padding:6px 8px;border-radius:4px;border:1px solid #4b5563;background:#111827;color:#e5e7eb;font-size:13px;resize:vertical"></textarea>
            </div>
            <div style="flex:1;display:flex;flex-direction:column">
                <label style="font-size:11px;color:#9ca3af">Text tradus</label>
                <textarea id="trResultText" rows="6" readonly style="width:100%;padding:6px 8px;border-radius:4px;border:1px solid #4b5563;background:#020617;color:#e5e7eb;font-size:13px;resize:vertical"></textarea>
            </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
            <div style="font-size:11px;color:#9ca3af" id="trStatus"></div>
            <div style="display:flex;gap:8px">
                <button class="fr-btn-ghost" onclick="loadSelectionIntoTranslate()" title="Preia selecția curentă">Preia selecția</button>
                <button class="fr-btn-primary" onclick="applyTranslatedToSelection()" title="Înlocuiește selecția cu traducerea">Înlocuiește în document</button>
                <button class="fr-btn-primary" onclick="runTranslate()">Tradu</button>
            </div>
        </div>
    </div>
    <div class="topbar">
        <button class="btn btn-ghost" id="btnToggleSidebar" onclick="toggleSidebar()"
            title="Arata/Ascunde lista de fisiere (fisiere HTML)">☰</button>
        <div class="brand">Mini Dreamweaver</div>
        <div id="tabBar">
            <div class="editor-tab tab-new" id="tabNew" onclick="onNewTabClick()" title="Deschide fisier nou">+</div>
        </div>
        <div id="tabBarSpacer" style="flex:1"></div>
        <button class="btn btn-ghost" onclick="closeActiveTab()">Inchide tab</button>
        <button type="button" class="btn btn-primary" onmousedown="event.preventDefault()" onclick="saveFile()">Salveaza (Ctrl+S)</button>
    </div>
    <div class="main">
        <div class="sidebar">
            <h3>Fisiere (HTML / CSS / JS / PHP)</h3>
            <div id="fileList"></div>
            <div id="sidebarRecent" style="margin-top:16px;display:none">
                <h3>Fisiere recente</h3>
                <div id="sidebarRecentList"></div>
            </div>
        </div>
        <div class="center">
            <div style="display:flex;align-items:center;justify-content:space-between">
                <div class="viewmode-tabs">
                    <button type="button" id="btnViewCode" onclick="setViewMode('code')">Code</button>
                    <button type="button" id="btnViewSplit" onclick="setViewMode('split')">Split</button>
                    <button type="button" id="btnViewDesign" onclick="setViewMode('design')">Design</button>
                </div>
                <div class="viewmode-tabs" style="margin-left:8px">
                    <button type="button" id="btnUndo" onclick="doUndoFromDesign()" title="Undo (Ctrl+Z)">&#8630;
                        Undo</button>
                    <button type="button" id="btnRedo" onclick="doRedoFromDesign()" title="Redo (Ctrl+Y)">&#8631;
                        Redo</button>
                    <button type="button" id="btnClassNormal" class="btn btn-ghost"
                        title="Normal: paragraful cu cursorul devine &lt;p class=&quot;text_obisnuit&quot;&gt; (scoate toate stilurile)">N</button>
                    <button type="button" id="btnClassObisnuit2" class="btn btn-ghost"
                        title="Bold: paragraful cu cursorul devine &lt;p class=&quot;text_obisnuit2&quot;&gt;; încă un click îl readuce la Normal">B</button>
                    <button type="button" id="btnQuickItalic" class="btn btn-ghost"
                        title="Italic (&lt;em&gt;) pe selecția din Design (ca butonul I de jos)">I</button>
                    <button type="button" id="btnQuickUnderline" class="btn btn-ghost"
                        title="Underline (&lt;u&gt;) pe selectia din Design">U</button>
                </div>
                <div class="viewmode-tabs" style="margin-left:12px">
                    <button type="button" id="btnBrowserTab" onclick="toggleBrowserPanel()"
                        title="Deschide Google Translate" style="font-weight:600">Google</button>
                    <button type="button" id="btnTranslatePanel" onclick="toggleTranslatePopup()"
                        title="Traducere text selectat" style="margin-left:6px">Tradu</button>
                    <button type="button" id="btnAddCat" onclick="addCatMergeToCategory()"
                        title="Articol deschis → fișier categorie (leadership-…html); sau duplicare dacă e deschisă pagina categorie"
                        style="margin-left:6px">ADD-CAT</button>
                    <button type="button" id="btnToIndex" onclick="pushFirstCategoryBlockToIndex()"
                        title="Articol deschis sau listă categorie → ro/index.html (fără dubluri, primul = cel mai nou)"
                        style="margin-left:6px">To-INDEX</button>
                </div>
                <div class="viewmode-tabs" style="margin-left:20px">
                    <button type="button" id="btnSelectSasa" onclick="selectSasaRegion()"
                        title="Select between SASA-1 and SASA-2">Select</button>
                    <button type="button" id="btnCropSasa" onclick="cropSasaRegion()"
                        title="Highlight paragraphs between SASA-1 and SASA-2 (visual only)">Crop</button>
                    <button type="button" id="btnFind" onclick="toggleFindReplace()"
                        title="Find & Replace (Ctrl+H)">Find</button>
                    <button type="button" id="btnDiac" onclick="toggleDiacPopup()"
                        title="Diacritice romanesti" style="font-size:15px;padding:4px 7px;line-height:1">&#258;</button>
                </div>
                <div class="tabs" style="min-width:0">
                    <div class="status" id="status" style="position:absolute;right:12px;pointer-events:none;white-space:nowrap;opacity:0.7"></div>
                </div>
            </div>
            <div class="split mode-design" id="splitContainer">
                <div class="editor-pane">
                    <div class="editor-header">
                        <div>Cod (UTF-8)</div>
                        <div style="font-size:11px;color:#9ca3af">Editare HTML / CSS / JS / PHP</div>
                    </div>
                    <textarea id="code" name="code"></textarea>
                </div>
                <div class="divider" id="splitDivider"></div>
                <div class="preview-pane">
                    <div class="preview-header">
                        <div>Design / Preview</div>
                        <button class="btn btn-ghost" onclick="updatePreview()">Reincarca preview</button>
                    </div>
                    <iframe id="preview"
                        sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-pointer-lock allow-modals"></iframe>
                </div>
            </div>
            <!-- Browser Panel (Google Translate / web browsing) -->
            <div id="browserPanel" style="display:none;flex:1;flex-direction:column;background:#1a1b26;overflow:hidden">
                <div style="display:flex;align-items:center;gap:6px;padding:6px 10px;background:#20212c;border-bottom:1px solid #333">
                    <button onclick="browserGoBack()" title="Inapoi" style="background:none;border:1px solid #4b5563;border-radius:4px;color:#e5e7eb;cursor:pointer;padding:3px 8px;font-size:14px">&#9664;</button>
                    <button onclick="browserGoForward()" title="Inainte" style="background:none;border:1px solid #4b5563;border-radius:4px;color:#e5e7eb;cursor:pointer;padding:3px 8px;font-size:14px">&#9654;</button>
                    <button onclick="browserRefresh()" title="Reincarca" style="background:none;border:1px solid #4b5563;border-radius:4px;color:#e5e7eb;cursor:pointer;padding:3px 8px;font-size:14px">&#8635;</button>
                    <input type="text" id="browserUrlBar" placeholder="URL..."
                        style="flex:1;padding:5px 10px;border:1px solid #4b5563;border-radius:4px;background:#1e1f26;color:#e5e7eb;font-size:13px;outline:none"
                        onkeydown="if(event.key==='Enter'){event.preventDefault();browserNavigate();}">
                    <button onclick="browserNavigate()" title="Navigheaza" style="background:#3b82f6;border:none;border-radius:4px;color:#fff;cursor:pointer;padding:5px 12px;font-size:13px;font-weight:600">Go</button>
                    <button onclick="if(activeTabId) closeTab(activeTabId);" title="Inchide tab browser" style="background:none;border:1px solid #ef4444;border-radius:4px;color:#ef4444;cursor:pointer;padding:3px 8px;font-size:14px;font-weight:bold">&times;</button>
                </div>
                <div style="flex:1;display:flex;flex-direction:column;background:#1a1b26">
                    <iframe id="browserFrame"
                        style="flex:1;width:100%;border:none;background:#050816;color:#e5e7eb"></iframe>
                </div>
            </div>
            <div id="propertiesPanel" class="properties-panel">
                <label>Link:</label><input type="text" id="propLink" placeholder="URL" title="Link href" style="width:140px;padding:2px 5px;border:1px solid #4b5563;border-radius:3px;background:#1e1f26;color:#e5e7eb;font-size:12px">
                <select id="propLinkTarget" title="Link target" style="padding:2px 3px;border:1px solid #4b5563;border-radius:3px;background:#1e1f26;color:#e5e7eb;font-size:12px">
                    <option value="">Target</option>
                    <option value="_blank">_blank</option>
                    <option value="_new">_new</option>
                    <option value="_parent">_parent</option>
                    <option value="_self">_self</option>
                    <option value="_top">_top</option>
                </select>
                <span style="color:#4b5563;margin:0 4px">|</span>
                <label>Font:</label><select id="propFont">
                    <option value="">(mostenit)</option>
                    <option value="Arial">Arial</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Times New Roman">Times New Roman</option>
                    <option value="Verdana">Verdana</option>
                    <option value="Source Sans Pro, sans-serif">Source Sans Pro</option>
                </select>
                <label>Clasa:</label><select id="propClass">
                    <option value="">(fara)</option>
                </select>
                <label>Marime:</label><select id="propSize">
                    <option value="">(mostenit)</option>
                    <option value="12">12px</option>
                    <option value="14">14px</option>
                    <option value="16">16px</option>
                    <option value="18">18px</option>
                    <option value="20">20px</option>
                    <option value="24">24px</option>
                </select>
                <label>Text:</label><input type="color" id="propColor" value="#000000" title="Culoare text">
                <label>Fundal:</label><input type="color" id="propBg" value="#ffffff" title="Culoare fundal">
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/php/php.min.js"></script>
    <script>
        let editor;
        let currentFile = null;
        let currentDir = '';
        let isSyncFromCode = false;
        let isSyncFromDesign = false;
        let isApplyingUndoRedo = false;
        let previewDebounceTimer = null;
        let designInputDebounceTimer = null;
        let cssClasses = [];
        let isSelectionFromDesign = false;
        let isSelectionFromCode = false;
        let syncSelectionMark = null;   // markText handle for yellow selection highlight in code
        let _imgClickMark = null;       // persistent markText for image/icon click highlight
        let isDirty = false;
        let viewMode = 'design';
        let skipPreviewUpdateUntil = 0;
        let sidebarVisible = true;
        let lastPreviewHadBody = false;
        let lastDesignSelectionRange = null;

        // --- Custom undo/redo stack for the design panel ---
        // The browser's native contentEditable undo (execCommand('undo')) does NOT
        // track JavaScript-based DOM changes (applyFontProperty, toggleInlineFormat).
        // So we maintain our own stack of body.innerHTML snapshots.
        let designUndoStack = [];
        let designRedoStack = [];
        let lastDesignSnapshot = null;
        let designSnapshotTimer = null;
        let designCleanCode = null; // exact editor code when design undo stack was initialized
        let designCleanBodyHtml = null; // initial browser-serialized body innerHTML for dirty comparison

        // ===== MULTI-TAB SYSTEM =====
        let tabs = [];
        let activeTabId = null;
        let tabIdCounter = 0;
        let _isRestoringTab = false;

        function extractMetaDescriptionFromHtml(html) {
            const dM = String(html || '').match(/<meta\s+name\s*=\s*["']description["']\s+content\s*=\s*["']([^"']*)["']/i)
                || String(html || '').match(/<meta\s+content\s*=\s*["']([^"']*)["']\s+name\s*=\s*["']description["']/i);
            return dM ? dM[1].trim() : '';
        }

        function normalizeDescCompare(s) {
            return String(s || '').replace(/\s+/g, ' ').trim();
        }

        /** Conținut text din interiorul <em> (fără alte tag-uri), cu entități decode simplu. */
        function plainTextFromEmInnerHtml(inner) {
            if (inner == null) return '';
            var x = String(inner);
            x = x.replace(/<br\s*\/?>/gi, '\n').replace(/<\/?(p|div)\b[^>]*>/gi, '\n');
            x = x.replace(/<[^>]+>/g, '');
            try {
                var ta = document.createElement('textarea');
                ta.innerHTML = x.trim();
                x = ta.value;
            } catch (e1) {
                x = x.replace(/&nbsp;/gi, ' ')
                    .replace(/&amp;/g, '&')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&quot;/g, '"')
                    .replace(/&#(\d+);/g, function (_, n) { return String.fromCharCode(parseInt(n, 10)); })
                    .replace(/&#x([0-9a-f]+);/gi, function (_, h) { return String.fromCharCode(parseInt(h, 16)); });
            }
            return x.trim();
        }

        /**
         * Textul pentru meta/og/JSON-LD: primul <p class="text_obisnuit2"> imediat după <!-- SASA-1 -->
         * (cu sau fără <em> în interior).
         */
        function extractArticleSasaTeaserPlain(html) {
            const norm = String(html || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            const sasaRe = /<!--\s*SASA-1\s*-->/i;
            const mSasa = sasaRe.exec(norm);
            if (!mSasa) return null;
            const slice = norm.slice(mSasa.index + mSasa[0].length);
            const m = slice.match(/^\s*(?:<!--[\s\S]*?-->\s*)*<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>([\s\S]*?)<\/p>/i);
            if (!m) return null;
            return plainTextFromEmInnerHtml(m[1]);
        }

        function getCategorySyncDescriptionFromArticleHtml(html) {
            var teaser = extractArticleSasaTeaserPlain(html);
            if (teaser != null && teaser !== '') return teaser;
            return extractMetaDescriptionFromHtml(html);
        }

        /** Pagină listă categorie/index (are cel puțin un bloc articol în zona listei), nu articol izolat. */
        function isHtmlCategoryListingPage(html) {
            var reg = findCategoryListRegion(html);
            if (!reg.ok) return false;
            return countCategoryListBlocks(html) >= 1;
        }

        /** Articol: are teaser SASA + em și nu e pagină de listă categorie. */
        function isArticlePageForSasaMetaSync(html) {
            var t = extractArticleSasaTeaserPlain(html);
            if (t == null || t === '') return false;
            return !isHtmlCategoryListingPage(html);
        }

        function escapeMetaDescriptionAttrValue(s) {
            return String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/\r?\n/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }

        function escapeJsonDescriptionValue(s) {
            return String(s || '')
                .replace(/\\/g, '\\\\')
                .replace(/"/g, '\\"')
                .replace(/\r?\n/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }

        /** Actualizează meta description, og:description și "description" din JSON-LD din primul text_obisnuit2 după SASA-1. */
        function applySasaTeaserToMetaDescription(html) {
            var teaser = extractArticleSasaTeaserPlain(html);
            if (teaser == null || teaser === '') return html;
            var metaEsc = escapeMetaDescriptionAttrValue(teaser);
            var jsonEsc = escapeJsonDescriptionValue(teaser);
            var out = String(html);
            var re1 = /(<meta\s+name\s*=\s*["']description["']\s+content\s*=\s*["'])([^"']*)(["'])/i;
            var re2 = /(<meta\s+content\s*=\s*["'])([^"']*)(["']\s+name\s*=\s*["']description["'])/i;
            if (re1.test(out)) {
                out = out.replace(re1, function (_, a, _old, c) { return a + metaEsc + c; });
            } else if (re2.test(out)) {
                out = out.replace(re2, function (_, a, _old, c) { return a + metaEsc + c; });
            }
            var reOg1 = /(<meta\s+property\s*=\s*["']og:description["']\s+content\s*=\s*["'])([^"']*)(["'])/i;
            var reOg2 = /(<meta\s+content\s*=\s*["'])([^"']*)(["']\s+property\s*=\s*["']og:description["'])/i;
            if (reOg1.test(out)) {
                out = out.replace(reOg1, function (_, a, _old, c) { return a + metaEsc + c; });
            } else if (reOg2.test(out)) {
                out = out.replace(reOg2, function (_, a, _old, c) { return a + metaEsc + c; });
            }
            out = out.replace(
                /(<script[^>]*\btype\s*=\s*["']application\/ld\+json["'][^>]*>)([\s\S]*?)(<\/script>)/gi,
                function (match, open, jsonBody, close) {
                    var newJson = jsonBody.replace(
                        /("description"\s*:\s*")((?:\\.|[^"\\])*)(")/gi,
                        function (_, prefix, _old, suffix) { return prefix + jsonEsc + suffix; }
                    );
                    return newJson === jsonBody ? match : open + newJson + close;
                }
            );
            return out;
        }

        const ARTICLE_PAGE_TITLE_SUFFIX = ' | Neculai Fantanaru';

        /** Titlul articolului din <h1 class="custom-h1 article-title"> sau <h1 class="den_articol">. */
        function extractArticleH1TitlePlain(html) {
            const norm = String(html || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            let m = norm.match(/<h1\b(?=[^>]*\bcustom-h1\b)(?=[^>]*\barticle-title\b)[^>]*>([\s\S]*?)<\/h1>/i);
            if (m) {
                const text = plainTextFromEmInnerHtml(m[1]);
                if (text) return text;
            }
            m = norm.match(/<h1\b[^>]*\bclass\s*=\s*["'][^"']*\bden_articol\b[^"']*["'][^>]*>([\s\S]*?)<\/h1>/i);
            if (m) {
                const text = plainTextFromEmInnerHtml(m[1]);
                if (text) return text;
            }
            return null;
        }

        function buildArticlePageTitleFromH1(h1Plain) {
            const core = String(h1Plain || '').replace(/\s+/g, ' ').trim();
            if (!core) return '';
            return core + ARTICLE_PAGE_TITLE_SUFFIX;
        }

        /** La save: title, og:title, abstract, Subject, JSON-LD headline/name din H1 articol. */
        function applyH1ToPageTitles(html) {
            const h1Plain = extractArticleH1TitlePlain(html);
            if (h1Plain == null || h1Plain === '') return html;
            const titleFull = buildArticlePageTitleFromH1(h1Plain);
            if (!titleFull) return html;
            const metaEsc = escapeMetaDescriptionAttrValue(titleFull);
            const jsonEsc = escapeJsonDescriptionValue(titleFull);
            let out = String(html);

            out = out.replace(/(<title[^>]*>)([\s\S]*?)(<\/title>)/i, function (_, a, _old, c) { return a + metaEsc + c; });

            const ogTitlePatterns = [
                /(<meta\s+property\s*=\s*["']og:title["']\s+content\s*=\s*["'])([^"']*)(["'])/i,
                /(<meta\s+content\s*=\s*["'])([^"']*)(["']\s+property\s*=\s*["']og:title["'])/i
            ];
            for (let i = 0; i < ogTitlePatterns.length; i++) {
                if (ogTitlePatterns[i].test(out)) {
                    out = out.replace(ogTitlePatterns[i], function (_, a, _old, c) { return a + metaEsc + c; });
                    break;
                }
            }

            const namedMetaPatterns = [
                /(<meta\s+name\s*=\s*["']abstract["']\s+content\s*=\s*["'])([^"']*)(["'])/i,
                /(<meta\s+content\s*=\s*["'])([^"']*)(["']\s+name\s*=\s*["']abstract["'])/i,
                /(<meta\s+name\s*=\s*["']Subject["']\s+content\s*=\s*["'])([^"']*)(["'])/i,
                /(<meta\s+content\s*=\s*["'])([^"']*)(["']\s+name\s*=\s*["']Subject["'])/i
            ];
            for (let j = 0; j < namedMetaPatterns.length; j++) {
                if (namedMetaPatterns[j].test(out)) {
                    out = out.replace(namedMetaPatterns[j], function (_, a, _old, c) { return a + metaEsc + c; });
                }
            }

            const suffixRe = /\|\s*Neculai Fantanaru\s*$/i;
            out = out.replace(
                /(<script[^>]*\btype\s*=\s*["']application\/ld\+json["'][^>]*>)([\s\S]*?)(<\/script>)/gi,
                function (match, open, jsonBody, close) {
                    let newJson = jsonBody.replace(
                        /("headline"\s*:\s*")((?:\\.|[^"\\])*)(")/gi,
                        function (_, prefix, _old, suffix) { return prefix + jsonEsc + suffix; }
                    );
                    newJson = newJson.replace(
                        /("name"\s*:\s*")((?:\\.|[^"\\])*)(")/gi,
                        function (full, prefix, oldVal, suffix) {
                            if (!suffixRe.test(oldVal)) return full;
                            return prefix + jsonEsc + suffix;
                        }
                    );
                    return newJson === jsonBody ? match : open + newJson + close;
                }
            );
            return out;
        }

        // Live: la orice schimbare a H1 (Code sau Design) actualizează imediat în cod title, abstract,
        // Subject, og:title și JSON-LD headline/name. Categoria și index-ul se aliniază la Save.
        let liveH1TitleSyncTimer = null;
        function scheduleLiveH1TitleSync() {
            clearTimeout(liveH1TitleSyncTimer);
            liveH1TitleSyncTimer = setTimeout(runLiveH1TitleSync, 300);
        }

        function runLiveH1TitleSync() {
            liveH1TitleSyncTimer = null;
            if (!editor || _isRestoringTab || !isCurrentFileHtml()) return;
            let tab = null;
            for (let i = 0; i < tabs.length; i++) { if (tabs[i].id === activeTabId) { tab = tabs[i]; break; } }
            if (!tab || tab.type === 'browser') return;
            const src = editor.getValue();
            const h1 = extractArticleH1TitlePlain(src);
            if (!h1) return;
            if (tab.liveH1Seen === undefined) tab.liveH1Seen = extractArticleH1TitlePlain(tab.originalContent || '');
            if (h1 === tab.liveH1Seen) return;
            tab.liveH1Seen = h1;
            const out = applyH1ToPageTitles(src);
            if (out === src) return;
            // Înlocuiește doar porțiunea care diferă (din <head>) — cursorul/scroll-ul din body rămân pe loc.
            let pre = 0;
            const maxPre = Math.min(src.length, out.length);
            while (pre < maxPre && src.charCodeAt(pre) === out.charCodeAt(pre)) pre++;
            let suf = 0;
            const maxSuf = Math.min(src.length, out.length) - pre;
            while (suf < maxSuf && src.charCodeAt(src.length - 1 - suf) === out.charCodeAt(out.length - 1 - suf)) suf++;
            const doc = editor.getDoc();
            const wasSync = isSyncFromDesign;
            isSyncFromDesign = true;
            try {
                doc.replaceRange(out.slice(pre, out.length - suf), doc.posFromIndex(pre), doc.posFromIndex(src.length - suf), '+h1titles');
            } finally {
                isSyncFromDesign = wasSync;
            }
        }

        const postponedChecks = new Map();
        function validationGraceRemaining() {
            const opened = tabs.filter(t => t.type !== 'browser' && (t.filePath || t.fileName));
            return opened.length ? Math.max(0, ...opened.map(t => (t.validationOpenedAt || 0) + 120000 - Date.now())) : 0;
        }
        function postponeValidation(key, callback) {
            if (!validationGraceRemaining()) return false;
            postponedChecks.set(key, callback);
            return true;
        }
        setInterval(() => {
            if (validationGraceRemaining()) return;
            const pending = [...postponedChecks.values()]; postponedChecks.clear();
            pending.forEach(callback => Promise.resolve().then(callback).catch(console.error));
        }, 1000);
        function createTabState(opts) {
            opts = opts || {};
            if (opts.type !== 'browser') {
                // Existing automatic notices should also leave room for the new article.
                setTimeout(() => {
                    if (!validationGraceRemaining()) return;
                    for (const id of ['dateDupFileDialog', 'dateDuplicatesDialog', 'linkDuplicatesDialog', 'categoryPairReport', 'indexOrderReport']) {
                        const notice = document.getElementById(id);
                        if (notice) {
                            if (id === 'categoryPairReport') {
                                localStorage.removeItem('categoryPairLastReport');
                                postponeValidation('category-pairs', () => syncCategoryPairs());
                            }
                            if (id === 'dateDuplicatesDialog' || id === 'dateDupFileDialog') {
                                dateDupLastAutomaticSignature = '';
                                postponeValidation('all-dates', () => runFullDateDuplicateCheck(false));
                            }
                            if (id === 'linkDuplicatesDialog') postponeValidation('links', () => runLinkDuplicateCheck());
                            if (id === 'indexOrderReport') { if (notice.open) notice.close(); }
                            else notice.remove();
                        }
                    }
                }, 0);
            }
            tabIdCounter++;
            var _oc = (opts.originalContent || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            return {
                id: tabIdCounter,
                validationOpenedAt: Date.now(),
                type: opts.type || 'file',       // 'file' or 'browser'
                browserUrl: opts.browserUrl || null,
                browserWindowRef: null,           // window.open() reference
                filePath: opts.filePath || null,
                fileName: opts.fileName || '',
                tabLabel: opts.tabLabel || 'Nou',
                fullTitle: opts.fullTitle || '',
                editorContent: opts.editorContent || '',
                originalContent: _oc,
                originalContentNorm: normalizeHtmlForCompare(_oc),
                cursorPos: opts.cursorPos || { line: 0, ch: 0 },
                scrollInfo: opts.scrollInfo || { left: 0, top: 0 },
                undoHistory: opts.undoHistory || null,
                isDirty: false,
                viewMode: opts.viewMode || 'design',
                lastPreviewHadBody: opts.lastPreviewHadBody || false,
                designUndoStack: [],
                designRedoStack: [],
                lastDesignSnapshot: null,
                designCleanBodyHtml: null,
                designCleanCode: null, // baseline editor text when design snapshot was taken (cross-tab undo / dirty)
                categorySyncDescriptionBaseline: getCategorySyncDescriptionFromArticleHtml(_oc),
                linkedCategoryPath: null,
                linkedArticleKey: null,
                protectedBodyScriptTail: opts.protectedBodyScriptTail || extractProtectedBodyScriptTail(_oc) || null
            };
        }

        function escapeHtml(str) {
            var d = document.createElement('div');
            d.textContent = str;
            return d.innerHTML;
        }

        // Normalize HTML for dirty comparison. Browsers serialize innerHTML
        // slightly differently from the original source (e.g. <br/> → <br>,
        // <img .../> → <img ...>). This function normalizes those differences
        // so that undo-back-to-original correctly detects "not dirty".
        function normalizeHtmlForCompare(html) {
            return html
                // Self-closing void elements: <br/> → <br>, <img .../> → <img ...>
                .replace(/<(br|hr|img|input|meta|link|col|area|source|track|wbr|embed|param)((?:\s[^>]*?)?)(?:\s*\/)>/gi, '<$1$2>')
                // Trim trailing whitespace before > in void elements
                .replace(/<(br|hr|img|input|meta|link|col|area|source|track|wbr|embed|param)((?:\s[^>]*?)?)\s+>/gi, '<$1$2>');
        }

        /** Pentru dirty-check și sync Design→cod: ignoră diferențe minore (spații/newlines între taguri). */
        function normalizeHtmlForSyncCompare(html) {
            var h = String(html || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            return normalizeHtmlForCompare(h).replace(/>\s+</g, '><');
        }

        function getTabFullTitle(content, fileName) {
            var m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(content);
            if (m && m[1].trim()) return m[1].trim().replace(/\s+/g, ' ');
            if (fileName) return fileName.replace(/^.*[\\\/]/, '');
            return 'Nou';
        }

        function getTabLabel(content, fileName) {
            var full = getTabFullTitle(content, fileName);
            var words = full.split(' ');
            var label = words.slice(0, 2).join(' ');
            if (label.length > 18) label = label.substring(0, 17) + '\u2026';
            return label || 'Nou';
        }

        function findTabByPath(path) {
            if (!path) return null;
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].filePath === path) return tabs[i];
            }
            return null;
        }

        var _dragTabId = null;

        function renderTabs() {
            var bar = document.getElementById('tabBar');
            if (!bar) return;
            var existing = bar.querySelectorAll('.editor-tab:not(.tab-new)');
            for (var i = 0; i < existing.length; i++) existing[i].remove();
            var newBtn = document.getElementById('tabNew');
            tabs.forEach(function (tab) {
                var div = document.createElement('div');
                div.className = 'editor-tab' + (tab.id === activeTabId ? ' active' : '') + (tab.isDirty ? ' dirty' : '');
                div.dataset.tabId = tab.id;
                div.title = tab.fullTitle || tab.tabLabel;
                div.draggable = true;
                var labelPrefix = tab.type === 'browser' ? '🌐 ' : '';
                div.innerHTML = '<span class="tab-label">' + labelPrefix + escapeHtml(tab.tabLabel) + '</span>'
                    + '<span class="tab-close" title="Inchide tab">&times;</span>';
                (function (tid) {
                    div.addEventListener('click', function (e) {
                        if (e.target.classList.contains('tab-close')) return;
                        switchToTab(tid);
                    });
                    div.querySelector('.tab-close').addEventListener('click', function (e) {
                        e.stopPropagation();
                        closeTab(tid);
                    });
                    // Drag & drop reordering
                    div.addEventListener('dragstart', function (e) {
                        _dragTabId = tid;
                        div.classList.add('dragging');
                        e.dataTransfer.effectAllowed = 'move';
                    });
                    div.addEventListener('dragend', function () {
                        _dragTabId = null;
                        div.classList.remove('dragging');
                        bar.querySelectorAll('.editor-tab').forEach(function (el) { el.classList.remove('drag-over'); });
                    });
                    div.addEventListener('dragover', function (e) {
                        if (_dragTabId === null || _dragTabId === tid) return;
                        e.preventDefault();
                        e.dataTransfer.dropEffect = 'move';
                        bar.querySelectorAll('.editor-tab').forEach(function (el) { el.classList.remove('drag-over'); });
                        div.classList.add('drag-over');
                    });
                    div.addEventListener('dragleave', function () {
                        div.classList.remove('drag-over');
                    });
                    div.addEventListener('drop', function (e) {
                        e.preventDefault();
                        div.classList.remove('drag-over');
                        if (_dragTabId === null || _dragTabId === tid) return;
                        var fromIdx = -1, toIdx = -1;
                        for (var j = 0; j < tabs.length; j++) {
                            if (tabs[j].id === _dragTabId) fromIdx = j;
                            if (tabs[j].id === tid) toIdx = j;
                        }
                        if (fromIdx < 0 || toIdx < 0) return;
                        var moved = tabs.splice(fromIdx, 1)[0];
                        tabs.splice(toIdx, 0, moved);
                        _dragTabId = null;
                        renderTabs();
                        backupDirtyTabs();
                    });
                })(tab.id);
                bar.insertBefore(div, newBtn);
            });
            // Scroll active tab into view
            var activeEl = bar.querySelector('.editor-tab.active');
            if (activeEl) activeEl.scrollIntoView({ behavior: 'smooth', inline: 'nearest', block: 'nearest' });
        }

        // Saving changes a tab's label/dirty state, not the tab list or its scroll position.
        function updateTabPresentation(tab) {
            const bar = document.getElementById('tabBar');
            if (!bar || !tab) return;
            const el = Array.from(bar.querySelectorAll('.editor-tab')).find(node =>
                node.dataset.tabId === String(tab.id));
            if (!el) return;
            el.classList.toggle('dirty', !!tab.isDirty);
            el.title = tab.fullTitle || tab.tabLabel;
            const label = el.querySelector('.tab-label');
            const text = (tab.type === 'browser' ? '🌐 ' : '') + tab.tabLabel;
            if (label && label.textContent !== text) label.textContent = text;
        }

        function saveCurrentTabState() {
            if (!activeTabId) return;
            var tab = null;
            for (var i = 0; i < tabs.length; i++) { if (tabs[i].id === activeTabId) { tab = tabs[i]; break; } }
            if (!tab || !editor) return;
            // Browser tabs don't have CodeMirror state to save
            if (tab.type === 'browser') return;
            tab.editorContent = editor.getValue();
            tab.cursorPos = editor.getCursor();
            tab.scrollInfo = editor.getScrollInfo();
            tab.undoHistory = editor.getDoc().getHistory();
            tab.isDirty = isDirty;
            tab.viewMode = viewMode;
            tab.lastPreviewHadBody = lastPreviewHadBody;
            tab.designUndoStack = designUndoStack.slice();
            tab.designRedoStack = designRedoStack.slice();
            tab.lastDesignSnapshot = lastDesignSnapshot;
            tab.designCleanBodyHtml = designCleanBodyHtml;
            tab.designCleanCode = designCleanCode;
            // Recalculate dirty only when there is evidence of real editing.
            // On some tab-open/switch flows, the editor can run internal syncs
            // that should not mark the tab as user-modified.
            var hsz = (editor.getDoc() && typeof editor.getDoc().historySize === 'function')
                ? editor.getDoc().historySize()
                : { undo: 0, redo: 0 };
            var hasHistoryEdits = !!(hsz && (hsz.undo > 0 || hsz.redo > 0));
            var nowDirty = false;
            if (isDirty || hasHistoryEdits) {
                nowDirty = (normalizeHtmlForSyncCompare(tab.editorContent) !== normalizeHtmlForSyncCompare(tab.originalContent));
            }
            tab.isDirty = nowDirty;
            isDirty = nowDirty;
            var _elDirty = document.querySelector('.editor-tab[data-tab-id="' + activeTabId + '"]');
            if (_elDirty) {
                if (nowDirty) _elDirty.classList.add('dirty');
                else _elDirty.classList.remove('dirty');
            }
            if (nowDirty && typeof backupDirtyTabs === 'function') backupDirtyTabs();
            // Save preview iframe scroll position (for Design/Split mode)
            try {
                var iframe = document.getElementById('preview');
                if (iframe && iframe.contentWindow) {
                    tab.previewScroll = {
                        x: iframe.contentWindow.scrollX || 0,
                        y: iframe.contentWindow.scrollY || 0
                    };
                }
            } catch(e) { /* cross-origin iframe, ignore */ }
        }

        function restoreTabState(tab) {
            if (typeof deactivateSasa === 'function') deactivateSasa();
            if (typeof deactivateCrop === 'function' && cropHighlightActive) deactivateCrop();
            _isRestoringTab = true;
            currentFile = tab.filePath;
            isDirty = tab.isDirty;
            lastPreviewHadBody = tab.lastPreviewHadBody;
            designUndoStack = tab.designUndoStack.slice();
            designRedoStack = tab.designRedoStack.slice();
            lastDesignSnapshot = tab.lastDesignSnapshot;
            designCleanBodyHtml = tab.designCleanBodyHtml;
            designCleanCode = (tab.designCleanCode != null) ? tab.designCleanCode : (editor ? editor.getValue() : null);

            // Suppress change-triggered preview updates during restore
            isSyncFromDesign = true;
            editor.setValue(tab.editorContent);
            if (tab.undoHistory) {
                editor.getDoc().setHistory(tab.undoHistory);
            } else {
                editor.getDoc().clearHistory();
            }
            editor.setCursor(tab.cursorPos);
            isSyncFromDesign = false;
            _isRestoringTab = false;
            // Tab-uri deschise înainte (sau restaurate din backup) cu stil AI → rescrise acum
            if (typeof cleanAiStyleInOpenedTab === 'function') {
                const aiFixedTab = cleanAiStyleInOpenedTab(tab, tab.filePath || tab.fileName);
                if (aiFixedTab) markTabDirtyAfterAiCleanup(tab, aiFixedTab);
            }

            // Restore view mode
            setViewMode(tab.viewMode);

            // Reload preview (restore iframe scroll via _pendingPreviewScroll)
            clearTimeout(previewDebounceTimer);
            previewDebounceTimer = null;
            if (tab.previewScroll) {
                _pendingPreviewScroll = { x: tab.previewScroll.x, y: tab.previewScroll.y };
            }
            updatePreview();

            // Restore scroll AFTER everything has settled
            // (setValue + setViewMode + updatePreview all cause re-layout that resets scroll)
            var savedScroll = tab.scrollInfo;
            if (savedScroll) {
                setTimeout(function() {
                    editor.refresh();
                    editor.scrollTo(savedScroll.left, savedScroll.top);
                    // Double-check: sometimes first scrollTo is eaten by pending layout
                    requestAnimationFrame(function() {
                        editor.scrollTo(savedScroll.left, savedScroll.top);
                    });
                }, 50);
            }
        }

        function switchToTab(tabId) {
            if (tabId === activeTabId) return;
            if (typeof flushPendingDesignSync === 'function') flushPendingDesignSync(true);
            // Deactivate CROP and SELECT modes when switching tabs
            if (typeof deactivateSasa === 'function') deactivateSasa();
            if (typeof deactivateCrop === 'function' && typeof cropHighlightActive !== 'undefined' && cropHighlightActive) deactivateCrop();
            saveCurrentTabState();
            activeTabId = tabId;
            var tab = null;
            for (var i = 0; i < tabs.length; i++) { if (tabs[i].id === tabId) { tab = tabs[i]; break; } }
            if (!tab) return;

            // Show/hide browser panel vs editor based on tab type
            var splitContainer = document.getElementById('splitContainer');
            var browserPanel = document.getElementById('browserPanel');
            var propsPanel = document.getElementById('propertiesPanel');
            var btnGoogle = document.getElementById('btnBrowserTab');

            if (tab.type === 'browser') {
                splitContainer.style.display = 'none';
                if (propsPanel) propsPanel.style.display = 'none';
                browserPanel.style.display = 'flex';
                browserPanelOpen = true;
                if (btnGoogle) btnGoogle.classList.add('active');
                // Focus/reopen the browser window if needed
                if (tab.browserWindowRef && !tab.browserWindowRef.closed) {
                    tab.browserWindowRef.focus();
                }
                // Update URL bar
                var urlBar = document.getElementById('browserUrlBar');
                if (urlBar && tab.browserUrl) urlBar.value = tab.browserUrl;
            } else {
                browserPanel.style.display = 'none';
                splitContainer.style.display = '';
                browserPanelOpen = false;
                if (btnGoogle) btnGoogle.classList.remove('active');
                restoreTabState(tab);
                if (typeof refreshTabLinkedCategory === 'function') refreshTabLinkedCategory(tab);
                if (typeof reconcileLinkedCategoryTeaserWithArticle === 'function') {
                    reconcileLinkedCategoryTeaserWithArticle(tab, tab.editorContent, { context: 'focus', silent: true }).catch(function () { });
                }
            }
            renderTabs();
        }

        var _saveConfirmResolve = null;
        function showSaveConfirm(msg) {
            return new Promise(function (resolve) {
                document.getElementById('saveConfirmMsg').textContent = msg;
                var ov = document.getElementById('saveConfirmOverlay');
                ov.style.display = 'flex';
                _saveConfirmResolve = function (choice) {
                    ov.style.display = 'none';
                    _saveConfirmResolve = null;
                    resolve(choice);
                };
            });
        }

        async function closeTab(tabId) {
            var tab = null, idx = -1;
            for (var i = 0; i < tabs.length; i++) { if (tabs[i].id === tabId) { tab = tabs[i]; idx = i; break; } }
            if (!tab) return;
            if (tab.type !== 'browser' && !await checkArticleIdentity(tab, true)) return;
            idx = tabs.findIndex(t => t.id === tabId);
            if (idx < 0) return;
            scheduleRecentArticlesCheck();

            // Browser tabs: close popup window, no save prompt needed
            if (tab.type === 'browser') {
                if (tab.browserWindowRef && !tab.browserWindowRef.closed) {
                    try { tab.browserWindowRef.close(); } catch (e) { }
                }
                tabs.splice(idx, 1);
                var btnGoogle = document.getElementById('btnBrowserTab');
                if (btnGoogle) btnGoogle.classList.remove('active');
                // If this was the active tab, switch to another
                if (tabId === activeTabId) {
                    var browserPanel = document.getElementById('browserPanel');
                    var splitContainer = document.getElementById('splitContainer');
                    browserPanel.style.display = 'none';
                    splitContainer.style.display = '';
                    browserPanelOpen = false;
                    if (tabs.length > 0) {
                        var newIdx = Math.min(idx, tabs.length - 1);
                        activeTabId = tabs[newIdx].id;
                        restoreTabState(tabs[newIdx]);
                    } else {
                        activeTabId = null;
                        currentFile = null;
                        isDirty = false;
                        editor.setValue('');
                        editor.getDoc().clearHistory();
                        document.getElementById('preview').src = 'about:blank';
                        showOverlay();
                    }
                }
                renderTabs();
                return;
            }

            var tabDirty = (tabId === activeTabId) ? isDirty : tab.isDirty;
            var skipReconcileCategoryOnClose = false;
            var htmlForCategorySync = tab.editorContent;
            if (tabDirty) {
                var choice = await showSaveConfirm('Fisierul "' + tab.tabLabel + '" are modificari nesalvate. Salvezi inainte de inchidere?');
                if (choice === 'cancel') return;
                if (choice === 'save') {
                    if (tabId !== activeTabId) switchToTab(tabId);
                    await saveFile();
                    skipReconcileCategoryOnClose = true;
                } else {
                    htmlForCategorySync = tab.originalContent;
                }
            }
            if (tab.type !== 'browser' && tab.filePath && !skipReconcileCategoryOnClose) {
                var fpl = String(tab.filePath).toLowerCase();
                if ((fpl.endsWith('.html') || fpl.endsWith('.htm')) && typeof reconcileLinkedCategoryTeaserWithArticle === 'function') {
                    var _prevEc = tab.editorContent;
                    tab.editorContent = htmlForCategorySync;
                    if (typeof refreshTabLinkedCategory === 'function') refreshTabLinkedCategory(tab);
                    try {
                        await reconcileLinkedCategoryTeaserWithArticle(tab, htmlForCategorySync, { context: 'close', silent: true });
                    } catch (eCatClose) { console.error(eCatClose); }
                    tab.editorContent = _prevEc;
                }
            }

            removeTabBackup(tabId);
            // Re-find index (might have changed if switchToTab was called)
            idx = -1;
            for (var i = 0; i < tabs.length; i++) { if (tabs[i].id === tabId) { idx = i; break; } }
            if (idx < 0) return;
            tabs.splice(idx, 1);

            if (tabs.length === 0) {
                activeTabId = null;
                currentFile = null;
                isDirty = false;
                editor.setValue('');
                editor.getDoc().clearHistory();
                document.getElementById('preview').src = 'about:blank';
                designUndoStack = [];
                designRedoStack = [];
                lastDesignSnapshot = null;
                if (typeof deactivateSasa === 'function') deactivateSasa();
                if (typeof deactivateCrop === 'function' && cropHighlightActive) deactivateCrop();
                removeAllBackups();
                showOverlay();
                renderTabs();
                return;
            }

            if (tabId === activeTabId) {
                var newIdx = Math.min(idx, tabs.length - 1);
                activeTabId = tabs[newIdx].id;
                restoreTabState(tabs[newIdx]);
            }
            backupDirtyTabs();
            renderTabs();
        }

        function closeActiveTab() {
            if (activeTabId) {
                closeTab(activeTabId);
            } else {
                if (typeof deactivateSasa === 'function') deactivateSasa();
                if (typeof deactivateCrop === 'function' && cropHighlightActive) deactivateCrop();
                hideOverlay(); // just to be safe, though showOverlay is more likely
                showOverlay();
            }
        }

        function onNewTabClick() {
            scheduleIndexOrderCheck();
            saveCurrentTabState();
            if (typeof deactivateSasa === 'function') deactivateSasa();
            if (typeof deactivateCrop === 'function' && cropHighlightActive) deactivateCrop();
            showOverlay();
        }

        // ===== BACKUP SYSTEM =====
        var _backupTimer = null;
        var _backupOwnerId = (function () {
            try {
                if (window.crypto && typeof window.crypto.randomUUID === 'function') {
                    return window.crypto.randomUUID();
                }
            } catch (e) { }
            return 'window-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
        })();

        function readBackupRecords() {
            try {
                var raw = localStorage.getItem('htmlEditorBackupTabs');
                if (!raw) return [];
                var arr = JSON.parse(raw);
                return Array.isArray(arr) ? arr : [];
            } catch (e) {
                return [];
            }
        }

        function writeBackupRecords(records) {
            try {
                if (records.length > 0) {
                    localStorage.setItem('htmlEditorBackupTabs', JSON.stringify(records));
                } else {
                    localStorage.removeItem('htmlEditorBackupTabs');
                }
            } catch (e) { }
        }

        function makeTabBackup(tab) {
            return {
                ownerId: _backupOwnerId,
                updatedAt: Date.now(),
                id: tab.id,
                filePath: tab.filePath,
                fileName: tab.fileName,
                tabLabel: tab.tabLabel,
                fullTitle: tab.fullTitle,
                editorContent: tab.editorContent,
                originalContent: tab.originalContent,
                cursorPos: tab.cursorPos,
                scrollInfo: tab.scrollInfo,
                viewMode: tab.viewMode
            };
        }

        function replaceOwnedBackups(ownedBackups) {
            var records = readBackupRecords().filter(function (b) {
                return b.ownerId !== _backupOwnerId;
            });
            writeBackupRecords(records.concat(ownedBackups));
        }

        function backupDirtyTabs() {
            // Debounce — save at most every 2 seconds
            clearTimeout(_backupTimer);
            _backupTimer = setTimeout(function () {
                try {
                    saveCurrentTabState();
                    var dirtyTabs = [];
                    for (var i = 0; i < tabs.length; i++) {
                        if (tabs[i].isDirty && tabs[i].type !== 'browser') {
                            dirtyTabs.push(makeTabBackup(tabs[i]));
                        }
                    }
                    replaceOwnedBackups(dirtyTabs);
                } catch (e) { }
            }, 2000);
        }

        function removeTabBackup(tabId) {
            try {
                var arr = readBackupRecords().filter(function (b) {
                    return !(b.ownerId === _backupOwnerId && b.id === tabId);
                });
                writeBackupRecords(arr);
            } catch (e) { }
        }

        function removeAllBackups() {
            replaceOwnedBackups([]);
        }

        async function restoreBackupTabs() {
            try {
                var arr = readBackupRecords();
                if (!arr || !arr.length) return;
                // Keep only the newest draft for each physical file. Older window
                // copies can otherwise accumulate and make startup progressively slower.
                arr.sort(function (a, b) {
                    return (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0);
                });
                var seenBackupFiles = {};
                arr = arr.filter(function (b) {
                    var key = b.filePath ? String(b.filePath).replace(/\\/g, '/').toLowerCase()
                        : 'untitled:' + String(b.ownerId || '') + ':' + String(b.id || '');
                    if (seenBackupFiles[key]) return false;
                    seenBackupFiles[key] = true;
                    return true;
                });
                // Read disk baselines in parallel; sequential fetches made every stale
                // backup add another visible delay to application startup.
                var diskContents = await Promise.all(arr.map(async function (b) {
                    if (!b.filePath) return null;
                    try {
                        var res = await fetch('?action=load&file=' + encodeURIComponent(b.filePath));
                        var data = await res.json();
                        return (data && data.ok) ? (data.content || '') : null;
                    } catch (loadErr) {
                        return null;
                    }
                }));
                var restored = 0;
                var keptBackups = [];
                var consumedIndexes = [];
                for (var i = 0; i < arr.length; i++) {
                    var b = arr[i];
                    // Skip if already open
                    if (b.filePath && findTabByPath(b.filePath)) {
                        consumedIndexes.push(i);
                        continue;
                    }
                    var diskContent = diskContents[i];
                    var baselineContent = (diskContent !== null) ? diskContent : (b.originalContent || '');
                    var isActuallyDirty = (normalizeHtmlForSyncCompare(b.editorContent || '') !== normalizeHtmlForSyncCompare(baselineContent));
                    if (!isActuallyDirty) {
                        consumedIndexes.push(i);
                        continue;
                    }
                    var tab = createTabState({
                        filePath: b.filePath,
                        fileName: b.fileName,
                        tabLabel: b.tabLabel,
                        fullTitle: b.fullTitle,
                        editorContent: b.editorContent,
                        originalContent: baselineContent,
                        cursorPos: b.cursorPos,
                        scrollInfo: b.scrollInfo,
                        viewMode: b.viewMode
                    });
                    // Only restore backups that still differ from the real file on disk.
                    tab.isDirty = true;
                    tabs.push(tab);
                    setTimeout(() => checkArticleIdentity(tab), 0);
                    scheduleIndexOrderCheck();
                    keptBackups.push(makeTabBackup(tab));
                    consumedIndexes.push(i);
                    restored++;
                }
                var untouchedBackups = arr.filter(function (_b, idx) {
                    return consumedIndexes.indexOf(idx) === -1 && _b.ownerId !== _backupOwnerId;
                });
                if (restored > 0) {
                    activeTabId = tabs[0].id;
                    restoreTabState(tabs[0]);
                    renderTabs();
                    hideOverlay();
                    // (backup restored silently — dirty star on tab is enough indication)
                    // Clean up backup for tabs that are no longer dirty
                    writeBackupRecords(untouchedBackups.concat(keptBackups));
                } else {
                    writeBackupRecords(untouchedBackups);
                }
            } catch (e) { }
        }
        // ===== END BACKUP SYSTEM =====

        // ===== END MULTI-TAB SYSTEM =====

        function getDesignBodyHtml() {
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body) return null;
            // Strip CROP highlight styles before reading so snapshots are always clean
            if (cropHighlightActive) {
                clearSasaDesignHighlight(doc);
                const html = doc.body.innerHTML;
                highlightSasaInDesign('crop');
                return html;
            }
            return doc.body.innerHTML;
        }

        // Push current body state into the undo stack.
        // Call this BEFORE making a change, or periodically (every 500ms) to
        // capture incremental typing so undo reverts ~500ms of keystrokes at a time.
        // Helper: get current Design iframe scroll position
        function getDesignScrollY() {
            try {
                const iframe = document.getElementById('preview');
                return iframe && iframe.contentWindow ? (iframe.contentWindow.scrollY || 0) : 0;
            } catch (e) { return 0; }
        }

        // After undo/redo, sync the code editor scroll to match the
        // Design panel scroll position (proportional mapping).
        function syncCodeScrollToDesignScroll(restoreScrollY) {
            if (!editor) return;
            try {
                const iframe = document.getElementById('preview');
                const doc = iframe && iframe.contentDocument;
                if (!doc || !doc.documentElement) return;
                const totalHeight = doc.documentElement.scrollHeight || 1;
                const pct = restoreScrollY / totalHeight;
                const codeInfo = editor.getScrollInfo();
                const codeScrollY = Math.round(pct * codeInfo.height);
                editor.scrollTo(null, codeScrollY);
            } catch (e) { /* ignore */ }
        }

        function designSaveSnapshot(fromTimer) {
            const html = getDesignBodyHtml();
            if (html === null) return;
            if (lastDesignSnapshot === null) {
                lastDesignSnapshot = html;
                return;
            }
            if (html === lastDesignSnapshot) return; // nothing changed
            designUndoStack.push({ html: lastDesignSnapshot, scrollY: getDesignScrollY() });
            if (designUndoStack.length > 1000) designUndoStack.shift();
            lastDesignSnapshot = html;
            // Only clear the redo future for real user edits, NOT for
            // periodic timer snapshots (which just chunk continuous typing
            // into undo steps — they shouldn't destroy the redo history).
            if (!fromTimer) {
                designRedoStack = [];
            }
        }

        // Explicitly push the CURRENT body state to the undo stack.
        // Call this BEFORE making a property/format change so the "before" state is saved.
        // Uses time-based grouping: rapid calls within 500ms (e.g. dragging a color picker)
        // are collapsed into one undo entry — the state when the gesture STARTED.
        let _lastDesignPushTime = 0;
        function designPushCurrentState() {
            const now = Date.now();
            // Group rapid changes into one undo step (color picker drag etc.)
            if (now - _lastDesignPushTime < 500) return;
            _lastDesignPushTime = now;
            const html = getDesignBodyHtml();
            if (html === null) return;
            // Don't push if identical to the top of the stack
            if (designUndoStack.length > 0 && designUndoStack[designUndoStack.length - 1].html === html) return;
            designUndoStack.push({ html: html, scrollY: getDesignScrollY() });
            if (designUndoStack.length > 1000) designUndoStack.shift();
            designRedoStack = [];
        }

        // Reset stacks (called when the preview iframe reloads / new file is opened)
        function designResetUndoStack() {
            designUndoStack = [];
            designRedoStack = [];
            lastDesignSnapshot = getDesignBodyHtml();
            designCleanBodyHtml = lastDesignSnapshot; // save initial body for dirty comparison
            designCleanCode = editor ? editor.getValue() : null;
            if (activeTabId) {
                for (var _ti = 0; _ti < tabs.length; _ti++) {
                    if (tabs[_ti].id === activeTabId) {
                        tabs[_ti].designCleanBodyHtml = designCleanBodyHtml;
                        tabs[_ti].designCleanCode = designCleanCode;
                        break;
                    }
                }
            }
            if (designSnapshotTimer) clearInterval(designSnapshotTimer);
            // Periodically save snapshots while the user types in design.
            // Keep the interval loose enough that one typed word stays one undo step.
            designSnapshotTimer = setInterval(() => {
                if (!isApplyingUndoRedo && !isSyncFromCode && !sasaSelectionActive && !cropHighlightActive) {
                    designSaveSnapshot(true);
                }
            }, 1500);
        }

        function toggleSidebar() {
            sidebarVisible = !sidebarVisible;
            const sb = document.querySelector('.sidebar');
            if (sb) sb.classList.toggle('collapsed', !sidebarVisible);
            try { localStorage.setItem('htmlEditorSidebarVisible', sidebarVisible ? '1' : '0'); } catch (e) { }
        }

        function toast(msg) {
            const st = document.getElementById('status');
            st.textContent = msg;
            setTimeout(() => { st.textContent = 'Pregatit'; }, 4000);
        }

        function showErrorPopup(msg) {
            let dlg = document.getElementById('errorPopup');
            if (!dlg) {
                dlg = document.createElement('div');
                dlg.id = 'errorPopup';
                dlg.className = 'error-popup';
                dlg.innerHTML =
                    '<div class="error-popup-inner">' +
                    '<div class="error-popup-title">Eroare</div>' +
                    '<textarea id="errorPopupText" readonly></textarea>' +
                    '<div class="error-popup-buttons">' +
                    '<button type="button" id="errorPopupClose">Închide</button>' +
                    '</div>' +
                    '</div>';
                document.body.appendChild(dlg);
                const closeBtn = document.getElementById('errorPopupClose');
                if (closeBtn) {
                    closeBtn.addEventListener('click', function () {
                        dlg.classList.remove('visible');
                    });
                }
            }
            const ta = document.getElementById('errorPopupText');
            if (ta) {
                ta.value = msg || '';
                ta.focus();
                ta.select();
            }
            dlg.classList.add('visible');
        }

        function shortName(path) {
            if (!path) return '';
            return path.replace(/\\/g, '/').split('/').pop();
        }

        function getRecentDirs() {
            try {
                const recent = JSON.parse(localStorage.getItem('htmlEditorRecentFiles')) || [];
                const dirs = new Set();
                recent.forEach(p => {
                    const dir = p.replace(/\\/g, '/').replace(/\/[^/]*$/, '');
                    if (dir) dirs.add(dir);
                });
                return Array.from(dirs);
            } catch (e) { return []; }
        }

        function addToRecentFiles(path) {
            if (!path) return;
            try {
                let recent = JSON.parse(localStorage.getItem('htmlEditorRecentFiles')) || [];
                // Remove if already exists
                recent = recent.filter(p => p !== path);
                // Add to top
                recent.unshift(path);
                // Keep only last 10
                if (recent.length > 10) recent = recent.slice(0, 10);
                localStorage.setItem('htmlEditorRecentFiles', JSON.stringify(recent));
                renderRecentFiles();
                renderSidebarRecent();
            } catch (e) {
                console.error('Error saving recent files:', e);
            }
        }

        // Scoate un fișier din „Fișiere recente” (doar din listă, fișierul rămâne pe disc)
        function removeFromRecentFiles(path) {
            try {
                const recent = (JSON.parse(localStorage.getItem('htmlEditorRecentFiles')) || []).filter(p => p !== path);
                localStorage.setItem('htmlEditorRecentFiles', JSON.stringify(recent));
            } catch (e) { console.error('Error removing recent file:', e); }
            renderRecentFiles();
            renderSidebarRecent();
        }

        function renderRecentFiles() {
            const listEl = document.getElementById('recentFilesList');
            const sectionEl = document.getElementById('recentFilesSection');
            if (!listEl || !sectionEl) return;

            try {
                const recent = JSON.parse(localStorage.getItem('htmlEditorRecentFiles')) || [];
                if (recent.length === 0) {
                    sectionEl.style.display = 'none';
                    return;
                }

                sectionEl.style.display = 'block';
                listEl.innerHTML = '';

                recent.forEach(path => {
                    const el = document.createElement('div');
                    el.className = 'recent-item';

                    // Create visual parts
                    const name = shortName(path);
                    const isPhp = name.toLowerCase().endsWith('.php');
                    const iconClass = isPhp ? 'fab fa-php' : 'fas fa-code';

                    // Extract parent folder for context (e.g. "ABOUT" for about.html)
                    const parts = path.replace(/\\/g, '/').split('/').filter(Boolean);
                    const parentDir = parts.length >= 2 && !/^[a-zA-Z]:$/.test(parts[parts.length - 2])
                        ? parts[parts.length - 2] : '';

                    el.title = path;
                    el.innerHTML = `
                        <i class="recent-icon ${iconClass}"></i>
                        <span class="recent-name-wrap">
                            <span class="recent-name">${name}</span>
                            ${parentDir ? `<span class="recent-folder">${parentDir}</span>` : ''}
                        </span>
                    `;

                    el.onclick = () => {
                        const pathInp = document.getElementById('pathInput');
                        if (pathInp) pathInp.value = path;
                        openFromPath();
                    };

                    const remove = document.createElement('button');
                    remove.type = 'button';
                    remove.className = 'recent-remove';
                    remove.title = 'Scoate din lista de fișiere recente';
                    remove.setAttribute('aria-label', 'Scoate ' + name + ' din lista de fișiere recente');
                    remove.innerHTML = '<i class="fas fa-xmark"></i>';
                    remove.onclick = (e) => {
                        e.stopPropagation(); // nu deschide fișierul
                        removeFromRecentFiles(path);
                    };
                    el.appendChild(remove);

                    listEl.appendChild(el);
                });
            } catch (e) {
                console.error('Error rendering recent files:', e);
                sectionEl.style.display = 'none';
            }
        }

        function renderSidebarRecent() {
            const listEl = document.getElementById('sidebarRecentList');
            const sectionEl = document.getElementById('sidebarRecent');
            if (!listEl || !sectionEl) return;
            try {
                const recent = JSON.parse(localStorage.getItem('htmlEditorRecentFiles')) || [];
                if (recent.length === 0) { sectionEl.style.display = 'none'; return; }
                sectionEl.style.display = 'block';
                listEl.innerHTML = '';
                recent.forEach(path => {
                    const el = document.createElement('div');
                    el.className = 'file';
                    const name = shortName(path);
                    el.innerHTML = '<span title="' + path + '">&#128196; ' + name + '</span>';
                    el.onclick = () => openFile(path, el);
                    listEl.appendChild(el);
                });
            } catch (e) { sectionEl.style.display = 'none'; }
        }

        // ── SELECT / CROP between SASA-1 / SASA-2 markers ──
        let sasaSelectionActive = false;
        let cropHighlightActive = false;

        function getSasaRange() {
            if (!editor) return null;
            const src = editor.getValue();
            const marker1 = '<!-- SASA-1 -->';
            const marker2 = '<!-- SASA-2 -->';
            const idx1 = src.indexOf(marker1);
            const idx2 = src.indexOf(marker2);
            if (idx1 === -1 || idx2 === -1) return null;
            // Start from the NEXT LINE after <!-- SASA-1 -->
            let startIdx = idx1 + marker1.length;
            const nlPos = src.indexOf('\n', startIdx);
            if (nlPos !== -1 && nlPos < idx2) startIdx = nlPos + 1;
            // End just before <!-- SASA-2 --> (trim trailing newline)
            let endIdx = idx2;
            if (endIdx > startIdx && src[endIdx - 1] === '\n') endIdx--;
            if (endIdx > startIdx && src[endIdx - 1] === '\r') endIdx--;
            return {
                from: editor.posFromIndex(startIdx),
                to: editor.posFromIndex(endIdx),
                startIdx, endIdx
            };
        }

        function isCursorInsideSasa() {
            if (!editor) return false;
            const range = getSasaRange();
            if (!range) return false;
            const curIdx = editor.indexFromPos(editor.getCursor());
            return curIdx >= range.startIdx && curIdx <= range.endIdx;
        }

        function selectSasaRegion() {
            if (!editor) return;
            // Toggle: if already active, deactivate
            if (sasaSelectionActive) {
                deactivateSasa();
                return;
            }
            const range = getSasaRange();
            if (!range) {
                toast('Marcajele <!-- SASA-1 --> si <!-- SASA-2 --> nu au fost gasite!');
                return;
            }
            // Deactivate CROP if it's on
            if (cropHighlightActive) deactivateCrop();
            // Select in code editor (needed for code/split modes, and as
            // the source-of-truth range even in design mode).
            editor.setSelection(range.from, range.to);
            editor.scrollIntoView({ from: range.from, to: range.to }, 60);
            // Activate SASA for ALL view modes — including design.
            sasaSelectionActive = true;
            document.getElementById('btnSelectSasa').classList.add('active');
            // Visual highlight in design panel (SELECT mode — only between SASA markers)
            highlightSasaInDesign('select');
            // Focus the right panel; în modul DESIGN selectăm și textul vizibil
            if (viewMode === 'design') {
                const iframe = document.getElementById('preview');
                const iDoc = iframe && iframe.contentDocument;
                if (iDoc && iDoc.body) {
                    iDoc.body.focus();
                    selectSasaTextInDesign();
                }
            } else {
                editor.focus();
            }
        }

        // CROP — visual-only highlight of paragraphs between SASA markers.
        // Does NOT activate sasaSelectionActive, so typing doesn't replace all
        // content.  Clicking inside a paragraph allows normal editing.
        // Highlight is PERSISTENT — stays on regardless of clicks or typing.
        function cropSasaRegion() {
            if (!editor) return;
            // Toggle: if already active, deactivate
            if (cropHighlightActive) {
                deactivateCrop();
                return;
            }
            const range = getSasaRange();
            if (!range) {
                toast('Marcajele <!-- SASA-1 --> si <!-- SASA-2 --> nu au fost gasite!');
                return;
            }
            // Deactivate SELECT if it's on
            if (sasaSelectionActive) deactivateSasa();
            // Visual highlight only — no code selection, no SASA activation
            cropHighlightActive = true;
            document.getElementById('btnCropSasa').classList.add('active');
            highlightSasaInDesign('crop');
            // In code/split mode, scroll to show the SASA region (but don't select)
            if (viewMode !== 'design') {
                editor.scrollIntoView({ from: range.from, to: range.to }, 60);
            }
        }

        function deactivateCrop() {
            if (!cropHighlightActive) return;
            cropHighlightActive = false;
            document.getElementById('btnCropSasa').classList.remove('active');
            clearSasaDesignHighlight();
        }

        // Add background highlight to design content between SASA markers.
        // mode='select' — only highlights between SASA-1 and SASA-2
        // mode='crop'   — also highlights h1.den_articol and td.text_dreapta
        // Focus/selection for SELECT este făcut în selectSasaRegion().
        function highlightSasaInDesign(mode) {
            const iframe = document.getElementById('preview');
            if (!iframe) return;
            const doc = iframe.contentDocument;
            if (!doc || !doc.body) return;
            // Remove any previous highlight
            clearSasaDesignHighlight(doc);
            // Find comment nodes
            let sasa1 = null, sasa2 = null;
            const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_COMMENT, null);
            let node;
            while ((node = walker.nextNode())) {
                const val = (node.nodeValue || '').trim();
                if (val === 'SASA-1') sasa1 = node;
                else if (val === 'SASA-2') sasa2 = node;
            }
            if (!sasa1 || !sasa2) return;
            // Collect all sibling nodes between the two comments for visual highlight
            let current = sasa1.nextSibling;
            while (current && current !== sasa2) {
                if (current.nodeType === Node.ELEMENT_NODE) {
                    current.setAttribute('data-sasa-highlight', '1');
                    current.style.outline = '2px solid #3b82f6';
                    current.style.backgroundColor = 'rgba(59,130,246,0.12)';
                }
                current = current.nextSibling;
            }
            // CROP mode: also highlight h1.den_articol and td.text_dreapta
            if (mode === 'crop') {
                doc.querySelectorAll('h1.den_articol').forEach(h1 => {
                    h1.setAttribute('data-sasa-highlight', '1');
                    h1.style.outline = '2px solid #3b82f6';
                    h1.style.backgroundColor = 'rgba(59,130,246,0.12)';
                });
                doc.querySelectorAll('td.text_dreapta').forEach(td => {
                    td.setAttribute('data-sasa-highlight', '1');
                    td.style.outline = '2px solid #3b82f6';
                    td.style.backgroundColor = 'rgba(59,130,246,0.12)';
                });
            }
        }

        // Selectează în Design (iframe) DOAR textul dintre comentariile <!-- SASA-1 --> și <!-- SASA-2 -->,
        // astfel încât Ctrl+C să copieze direct textul vizibil (fără cod) după apăsarea butonului Select.
        function selectSasaTextInDesign() {
            const iframe = document.getElementById('preview');
            if (!iframe) return;
            const doc = iframe.contentDocument;
            if (!doc || !doc.body) return;

            // Găsim comentariile SASA-1 și SASA-2
            let sasa1 = null, sasa2 = null;
            const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_COMMENT, null);
            let node;
            while ((node = walker.nextNode())) {
                const val = (node.nodeValue || '').trim();
                if (val === 'SASA-1') sasa1 = node;
                else if (val === 'SASA-2') sasa2 = node;
            }
            if (!sasa1 || !sasa2) return;

            const selection = doc.getSelection();
            if (!selection) return;
            selection.removeAllRanges();

            const range = doc.createRange();
            // Range-ul începe imediat după comentariul SASA-1
            range.setStartAfter(sasa1);
            // și se termină chiar înainte de comentariul SASA-2
            range.setEndBefore(sasa2);
            selection.addRange(range);
        }

        function clearSasaDesignHighlight(doc) {
            if (!doc) {
                const iframe = document.getElementById('preview');
                if (iframe) doc = iframe.contentDocument;
            }
            if (!doc || !doc.body) return;
            doc.querySelectorAll('[data-sasa-highlight]').forEach(el => {
                el.removeAttribute('data-sasa-highlight');
                el.style.outline = '';
                el.style.backgroundColor = '';
                // Remove the style attribute entirely if it became empty
                if (el.getAttribute('style') === '' || el.getAttribute('style') === null) {
                    el.removeAttribute('style');
                }
            });
        }

        // Normalize Romanian diacritics so design-mode and code use the same characters.
        // Maps older sedilă / punct-dedesubt variante (ş, ţ, ṣ, ṭ, etc.) la forma corectă cu virgulă (ș, ț).
        function normalizeRomanianDiacritics(str) {
            if (!str) return str;
            return str
                // ș mic
                .replace(/[\u015F\u1E63]/g, 'ș')
                // Ș mare
                .replace(/[\u015E\u1E62]/g, 'Ș')
                // ț mic
                .replace(/[\u0163\u1E6D]/g, 'ț')
                // Ț mare
                .replace(/[\u0162\u1E6C]/g, 'Ț');
        }

        // Replace &nbsp; with regular space only in the SASA region and h1.den_articol,
        // and normalize diacritics to UTF-8 românești standard. Operates on the HTML string
        // — never at the DOM level, deci nu afectează poziția cursorului.
        function cleanNbspInHtml(html) {
            if (!html) return html;
            // Between <!-- SASA-1 --> and <!-- SASA-2 -->
            html = html.replace(
                /(<!-- SASA-1 -->)([\s\S]*?)(<!-- SASA-2 -->)/,
                (_, s1, content, s2) => s1 + content.replace(/&nbsp;/gi, ' ') + s2
            );
            // In <h1 class="den_articol ...">...</h1>
            html = html.replace(
                /(<h1\b[^>]*\bden_articol\b[^>]*>)([\s\S]*?)(<\/h1>)/gi,
                (_, open, content, close) => open + content.replace(/&nbsp;/gi, ' ') + close
            );
            // Normalize diacritics everywhere in body html
            html = normalizeRomanianDiacritics(html);
            return html;
        }

        // Clear SASA state when user clicks elsewhere or edits
        function deactivateSasa() {
            sasaSelectionActive = false;
            document.getElementById('btnSelectSasa').classList.remove('active');
            clearSasaDesignHighlight();
        }

        // ── Markdown (text copiat de la AI) → HTML-ul site-ului ──
        // **paragraf intreg**  → <p class="text_obisnuit2">…</p>
        // paragraf normal      → <p class="text_obisnuit">…</p>
        // **cuvinte** in text  → <span class="text_obisnuit2">…</span>
        // *cuvinte* / _cuvinte_ → <em>…</em>   (***x*** → bold + italic)
        // # Titlu → paragraf bold; > citat, `cod`, ~~taiat~~, [text](url), ---, "* item" sunt curatate/convertite.
        function looksLikeMarkdown(text) {
            return /\*\*\S[^\n]*?\*\*|__\S[^\n]*?__|(^|[^\w*\\])\*(?=\S)[^*\n]*?\S\*(?![\w*])|(^|[^\w\\])_(?=\S)[^_\n]*?\S_(?!\w)|^[ \t]{0,3}#{1,6}[ \t]+\S|^[ \t]{0,3}>[ \t]?\S|^[ \t]*[*+][ \t]+\S|~~\S[^\n]*?~~|`[^`\n]+`|\[[^\]\n]+\]\([^)\s]+\)/m.test(String(text || ''));
        }
        function markdownInlineToHtml(s) {
            const escaped = [];
            s = String(s).replace(/\\([\\`*_{}\[\]()#+\-.!~>])/g, function (m, c) {
                escaped.push(c);
                return '\u0001' + (escaped.length - 1) + '\u0001';
            });
            s = escapeHtml(s);
            s = s.replace(/`([^`]+)`/g, '$1');
            s = s.replace(/\[([^\]]+)\]\(([^)\s]+)(?:\s+[^)]*)?\)/g, function (m, label, url) {
                return '<a href="' + url.replace(/"/g, '&quot;') + '">' + label + '</a>';
            });
            const boldItalic = '<span class="text_obisnuit2"><em>$1</em></span>';
            s = s.replace(/\*\*\*(?=\S)(.*?\S)\*\*\*/g, boldItalic);
            s = s.replace(/___(?=\S)(.*?\S)___/g, boldItalic);
            s = s.replace(/\*\*(?=\S)(.*?\S)\*\*/g, '<span class="text_obisnuit2">$1</span>');
            s = s.replace(/__(?=\S)(.*?\S)__/g, '<span class="text_obisnuit2">$1</span>');
            s = s.replace(/(^|[^\w*])\*(?=\S)([^*]*?\S)\*(?![\w*])/g, '$1<em>$2</em>');
            s = s.replace(/(^|[^\w])_(?=\S)([^_]*?\S)_(?!\w)/g, '$1<em>$2</em>');
            s = s.replace(/~~(?=\S)(.*?\S)~~/g, '<s>$1</s>');
            s = s.replace(/\u0001(\d+)\u0001/g, function (m, i) { return escapeHtml(escaped[+i]); });
            return s;
        }
        // Fiecare rand ne-gol devine un paragraf: [{ cls, html }]
        function markdownToParagraphBlocks(text) {
            const blocks = [];
            String(text || '').replace(/\r\n?/g, '\n').split('\n').forEach(function (raw) {
                let line = raw.replace(/ /g, ' ').trim();
                if (!line) return;
                if (/^([-*_])(?:\s*\1){2,}$/.test(line)) return; // linie orizontala ---
                let cls = 'text_obisnuit';
                const heading = line.match(/^#{1,6}\s+(.*?)\s*#*$/);
                if (heading) {
                    line = heading[1].replace(/\*\*|__/g, '');
                    cls = 'text_obisnuit2';
                }
                line = line.replace(/^(?:>\s?)+/, '').replace(/^[*+]\s+/, '- ').replace(/ {2,}/g, ' ').trim();
                if (!line) return;
                const whole = line.match(/^(\*\*|__)(?=\S)(.*\S)\1$/);
                if (whole && whole[2].indexOf(whole[1]) === -1) {
                    cls = 'text_obisnuit2';
                    line = whole[2];
                }
                blocks.push({ cls: cls, html: markdownInlineToHtml(line) });
            });
            return blocks;
        }

        // Wrap raw text in <p class="text_obisnuit">…</p> for SASA insert.
        // Each non-empty line becomes its own paragraph.
        function wrapTextForSasa(rawText) {
            if (!rawText) return '';
            if (looksLikeMarkdown(rawText)) {
                return markdownToParagraphBlocks(rawText)
                    .map(b => '<p class="' + b.cls + '">' + b.html + '</p>').join('\n');
            }
            const prefix = '<p class="text_obisnuit">';
            const suffix = '</p>';
            const lines = rawText.split(/\r?\n/).filter(l => l.trim().length > 0);
            if (lines.length === 0) return '';
            return lines.map(l => prefix + l.trim() + suffix).join('\n');
        }

        // After any edit (type/delete/paste) with SASA selection active in code,
        // ensure cursor lands on the empty line between markers
        function positionCursorBetweenSasa() {
            if (!editor) return;
            const src = editor.getValue();
            const marker1 = '<!-- SASA-1 -->';
            const idx1 = src.indexOf(marker1);
            if (idx1 === -1) return;
            let pos = idx1 + marker1.length;
            const nl = src.indexOf('\n', pos);
            if (nl !== -1) pos = nl + 1;
            const cursorPos = editor.posFromIndex(pos);
            editor.setCursor(cursorPos);
            editor.scrollIntoView(cursorPos, 60);
        }

        // Position the design iframe caret between SASA markers so that
        // subsequent typing in design-only mode goes into the right place.
        function positionDesignCaretBetweenSasa() {
            const iframe = document.getElementById('preview');
            if (!iframe) return;
            const iDoc = iframe.contentDocument;
            const win = iframe.contentWindow;
            if (!iDoc || !iDoc.body || !win) return;
            // Find SASA comment nodes
            let sasa1 = null, sasa2 = null;
            const walker = iDoc.createTreeWalker(iDoc.body, NodeFilter.SHOW_COMMENT, null);
            let cNode;
            while ((cNode = walker.nextNode())) {
                const val = (cNode.nodeValue || '').trim();
                if (val === 'SASA-1') sasa1 = cNode;
                else if (val === 'SASA-2') sasa2 = cNode;
            }
            if (!sasa1 || !sasa2) return;
            // Walk backwards from SASA-2 to find the last text/element node
            // between the markers, and place the caret at the END of content
            // so the user can keep typing naturally.
            const range = iDoc.createRange();
            let prev = sasa2.previousSibling;
            // Skip pure-whitespace text nodes right before SASA-2
            while (prev && prev !== sasa1 && prev.nodeType === Node.TEXT_NODE &&
                !prev.nodeValue.replace(/[\r\n]/g, '').length) {
                prev = prev.previousSibling;
            }
            if (prev && prev !== sasa1) {
                if (prev.nodeType === Node.TEXT_NODE) {
                    // Place caret at end of the text node content
                    range.setStart(prev, prev.nodeValue.length);
                } else {
                    // Place caret after the last element
                    range.setStartAfter(prev);
                }
            } else {
                // Nothing meaningful between markers — place caret after SASA-1
                range.setStartAfter(sasa1);
            }
            range.collapse(true);
            const sel = win.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        }

        // Position the design caret inside the last <em> element between SASA
        // markers. This is used after SASA edits that wrap content in
        // <p class="text_obisnuit"><em>…</em></p> so that continued typing in
        // design mode stays inside the formatted element.
        function positionDesignCaretInSasaEm() {
            const iframe = document.getElementById('preview');
            if (!iframe) return;
            const iDoc = iframe.contentDocument;
            const win = iframe.contentWindow;
            if (!iDoc || !iDoc.body || !win) return;
            // Find SASA comment nodes
            let sasa1 = null, sasa2 = null;
            const walker = iDoc.createTreeWalker(iDoc.body, NodeFilter.SHOW_COMMENT, null);
            let cNode;
            while ((cNode = walker.nextNode())) {
                const val = (cNode.nodeValue || '').trim();
                if (val === 'SASA-1') sasa1 = cNode;
                else if (val === 'SASA-2') sasa2 = cNode;
            }
            if (!sasa1 || !sasa2) return;
            // Walk backwards from SASA-2 looking for the last <em> inside SASA zone
            let lastEm = null;
            let lastBlock = null;
            let node = sasa2.previousSibling;
            while (node && node !== sasa1) {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    const em = node.querySelector ? node.querySelector('em') : null;
                    if (em) { lastEm = em; break; }
                    if (!lastBlock) lastBlock = node;
                }
                node = node.previousSibling;
            }
            const range = iDoc.createRange();
            if (lastEm) {
                // Place caret at end of text inside <em>
                if (lastEm.lastChild && lastEm.lastChild.nodeType === Node.TEXT_NODE) {
                    range.setStart(lastEm.lastChild, lastEm.lastChild.nodeValue.length);
                } else if (lastEm.lastChild) {
                    range.setStartAfter(lastEm.lastChild);
                } else {
                    range.setStart(lastEm, 0);
                }
            } else if (lastBlock) {
                // No <em>: place caret at end of deepest text node inside last block
                let deepNode = lastBlock;
                while (deepNode.lastChild) deepNode = deepNode.lastChild;
                if (deepNode.nodeType === Node.TEXT_NODE) {
                    range.setStart(deepNode, deepNode.nodeValue.length);
                } else {
                    range.setStartAfter(deepNode);
                }
            } else {
                // Fallback: after SASA-1
                range.setStartAfter(sasa1);
            }
            range.collapse(true);
            const sel = win.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
        }

        // ── Browser Tab (Google Translate / web browsing) ──
        let browserPanelOpen = false;
        const BROWSER_DEFAULT_URL = 'https://translate.google.com/?sl=ro&tl=en&op=translate';

        // Construiește URL-ul către proxy-ul PHP pentru o adresă dată.
        function buildProxyUrl(url) {
            // Folosim același script (index V.4.php) cu ?action=webproxy&url=...
            const base = window.location.pathname.replace(/[#?].*$/, '');
            return base + '?action=webproxy&url=' + encodeURIComponent(url);
        }

        function toggleBrowserPanel() {
            // If a browser tab already exists, switch to it (or away from it)
            var existingBrowserTab = null;
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].type === 'browser') { existingBrowserTab = tabs[i]; break; }
            }
            if (existingBrowserTab) {
                if (activeTabId === existingBrowserTab.id) {
                    // Already on browser tab — switch to previous file tab
                    var fileTab = null;
                    for (var i = 0; i < tabs.length; i++) {
                        if (tabs[i].type === 'file') { fileTab = tabs[i]; break; }
                    }
                    if (fileTab) switchToTab(fileTab.id);
                } else {
                    switchToTab(existingBrowserTab.id);
                }
                return;
            }
            // Create a new browser tab
            saveCurrentTabState();
            var tab = createTabState({
                type: 'browser',
                tabLabel: 'Google Translate',
                fullTitle: 'Google Translate (RO → EN)',
                browserUrl: BROWSER_DEFAULT_URL
            });
            tabs.push(tab);
                    setTimeout(() => checkArticleIdentity(tab), 0);
                    scheduleIndexOrderCheck();
            activeTabId = tab.id;
            // Show browser panel
            var splitContainer = document.getElementById('splitContainer');
            var browserPanel = document.getElementById('browserPanel');
            var propsPanel = document.getElementById('propertiesPanel');
            var btnGoogle = document.getElementById('btnBrowserTab');
            splitContainer.style.display = 'none';
            if (propsPanel) propsPanel.style.display = 'none';
            browserPanel.style.display = 'flex';
            browserPanelOpen = true;
            if (btnGoogle) btnGoogle.classList.add('active');
            var urlBar = document.getElementById('browserUrlBar');
            if (urlBar) urlBar.value = BROWSER_DEFAULT_URL;
            // Încarcă Google Translate în iframe prin proxy server-side
            const frame = document.getElementById('browserFrame');
            if (frame) {
                frame.src = buildProxyUrl(BROWSER_DEFAULT_URL);
            }
            renderTabs();
        }

        function closeBrowserPanel() {
            var splitContainer = document.getElementById('splitContainer');
            var browserPanel = document.getElementById('browserPanel');
            var propsPanel = document.getElementById('propertiesPanel');
            var btn = document.getElementById('btnBrowserTab');
            browserPanel.style.display = 'none';
            splitContainer.style.display = '';
            if (propsPanel && typeof isCurrentFileHtml === 'function' && isCurrentFileHtml() &&
                (viewMode === 'design' || viewMode === 'split')) {
                propsPanel.style.display = '';
            }
            browserPanelOpen = false;
            if (btn) btn.classList.remove('active');
            const frame = document.getElementById('browserFrame');
            if (frame) frame.src = 'about:blank';
            if (editor) setTimeout(() => editor.refresh(), 50);
        }

        function browserNavigate() {
            const urlBar = document.getElementById('browserUrlBar');
            let url = urlBar.value.trim();
            if (!url) return;
            // Auto-add https:// if no protocol
            if (!/^https?:\/\//i.test(url)) {
                if (/^[a-zA-Z0-9].*\.[a-zA-Z]/.test(url)) {
                    url = 'https://' + url;
                } else {
                    url = 'https://www.google.com/search?q=' + encodeURIComponent(url);
                }
            }
            urlBar.value = url;
            // Update the tab's stored URL
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].id === activeTabId && tabs[i].type === 'browser') {
                    tabs[i].browserUrl = url;
                    break;
                }
            }
            // Navighează în iframe prin proxy, pentru a rămâne în aplicație
            const frame = document.getElementById('browserFrame');
            if (frame) {
                frame.src = buildProxyUrl(url);
            }
        }

        function browserGoBack() {
            const frame = document.getElementById('browserFrame');
            if (frame && frame.contentWindow) {
                try { frame.contentWindow.history.back(); } catch (e) { }
            }
        }

        function browserGoForward() {
            const frame = document.getElementById('browserFrame');
            if (frame && frame.contentWindow) {
                try { frame.contentWindow.history.forward(); } catch (e) { }
            }
        }

        function browserRefresh() {
            const frame = document.getElementById('browserFrame');
            if (frame && frame.contentWindow) {
                try { frame.contentWindow.location.reload(); } catch (e) { }
            }
        }

        function browserReopenWindow() {
            var tab = null;
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].id === activeTabId && tabs[i].type === 'browser') { tab = tabs[i]; break; }
            }
            if (!tab) return;
            var url = document.getElementById('browserUrlBar').value || tab.browserUrl || BROWSER_DEFAULT_URL;
            // Deschide separat doar la cerere explicită (butonul din panel),
            // nu automat când deschidem tabul.
            tab.browserWindowRef = window.open(url, 'googleTranslate');
        }

        // Actualizează bara de adrese când proxy-ul notifică schimbarea URL-ului
        window.addEventListener('message', function (e) {
            if (!e.data || e.data.type !== 'proxyUrlChange') return;
            const newUrl = e.data.url;
            const urlBar = document.getElementById('browserUrlBar');
            if (urlBar) urlBar.value = newUrl;
            // actualizează și tab-ul curent de tip browser
            for (var i = 0; i < tabs.length; i++) {
                if (tabs[i].id === activeTabId && tabs[i].type === 'browser') {
                    tabs[i].browserUrl = newUrl;
                    break;
                }
            }
        });

        // ── Diacritics Popup ──
        function toggleDiacPopup() {
            const dlg = document.getElementById('diacPopup');
            if (dlg.classList.contains('visible')) {
                closeDiacPopup();
            } else {
                dlg.classList.add('visible');
                dlg.focus();
            }
        }
        function closeDiacPopup() {
            document.getElementById('diacPopup').classList.remove('visible');
        }
        // Global Escape listener (covers focus on button, body, or anywhere outside code editor)
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                const dlg = document.getElementById('diacPopup');
                if (dlg && dlg.classList.contains('visible')) {
                    closeDiacPopup();
                }
            }
        });

        // ── Translation helper popup ──
        function toggleTranslatePopup() {
            const dlg = document.getElementById('translatePopup');
            if (dlg.classList.contains('visible')) {
                closeTranslatePopup();
            } else {
                // Reset la dimensiunea implicită de fiecare dată când se deschide
                dlg.style.width = '';
                dlg.style.height = '';
                dlg.style.bottom = 'auto';

                // Poziționare implicită: dreapta sus, sub toolbar
                const margin = 12;
                dlg.style.left = (window.innerWidth - 520 - margin) + 'px';
                dlg.style.top = '70px';
                dlg.classList.add('visible');
                loadSelectionIntoTranslate();
                dlg.focus();
            }
        }
        function closeTranslatePopup() {
            document.getElementById('translatePopup').classList.remove('visible');
        }

        // Spațiul dinaintea unui bloc poate conține și paragrafe goale în plus (<p class="text_obisnuit"></p>);
        // altfel citirea listei se oprea la ele și restul articolelor nu mai erau văzute.
        const CATEGORY_ARTICLE_BLOCK_RE = /^((?:\s|<p\s+class\s*=\s*["']text_obisnuit["'][^>]*>\s*<\/p>)*)(<table\s[^>]*\bwidth\s*=\s*["'][^"']+["'][^>]*>[\s\S]*?<\/table>\s*<p\s+class\s*=\s*["']text_obisnuit2["'][^>]*>[\s\S]*?<\/p>\s*<table\s[^>]*\bwidth\s*=\s*["'][^"']+["'][^>]*>[\s\S]*?<\/table>\s*<p\s+class\s*=\s*["']text_obisnuit["'][^>]*>\s*<\/p>)/i;

        const MARKER_CATEGORIE_START = '<!-- ARTICOL CATEGORIE START -->';
        const MARKER_CATEGORIE_FINAL = '<!-- ARTICOL CATEGORIE FINAL -->';
        const MARKER_ARTICOL_START = '<!-- ARTICOL START -->';
        const MARKER_ARTICOL_FINAL = '<!-- ARTICOL FINAL -->';
        const MARKER_SASA1 = '<!-- SASA-1 -->';

        /**
         * Zona listelor de articole: fie RO (CATEGORIE START/FINAL), fie EN (ARTICOL START … SASA-1 sau ARTICOL FINAL).
         */
        function findCategoryListRegion(html) {
            const h = String(html || '');
            let mi = h.indexOf(MARKER_CATEGORIE_START);
            let startMarker = MARKER_CATEGORIE_START;
            if (mi === -1) {
                mi = h.indexOf(MARKER_ARTICOL_START);
                startMarker = MARKER_ARTICOL_START;
            }
            if (mi === -1) {
                return { ok: false, msg: 'Lipsește <!-- ARTICOL CATEGORIE START --> sau <!-- ARTICOL START -->.' };
            }
            const afterMarker = h.slice(mi + startMarker.length);
            const divMatch = afterMarker.match(/^\s*<div\s+align\s*=\s*["']?justify["']?\s*>/i);
            if (!divMatch) {
                return { ok: false, msg: 'Lipsește &lt;div align=&quot;justify&quot;&gt; după marcajul listei.' };
            }
            const divEndGlobal = mi + startMarker.length + divMatch[0].length;
            let regionEnd = h.length;
            if (startMarker === MARKER_CATEGORIE_START) {
                const fi = h.indexOf(MARKER_CATEGORIE_FINAL, divEndGlobal);
                if (fi !== -1) regionEnd = fi;
            } else {
                const sasa1 = h.indexOf(MARKER_SASA1, divEndGlobal);
                const fi = h.indexOf(MARKER_ARTICOL_FINAL, divEndGlobal);
                if (sasa1 !== -1 && (fi === -1 || sasa1 < fi)) regionEnd = sasa1;
                else if (fi !== -1) regionEnd = fi;
            }
            return { ok: true, divEndGlobal: divEndGlobal, regionEnd: regionEnd, startMarker: startMarker };
        }

        function countCategoryListBlocks(html) {
            const reg = findCategoryListRegion(html);
            if (!reg.ok) return 0;
            return enumerateIndexCategoryBlocks(html, reg.divEndGlobal, reg.regionEnd).length;
        }

        // Între articole: nu lipi </p> de <table>; rând nou + 4 spații înainte de <table>.
        function normalizeBreakAfterTextObisnuitBeforeTable(html) {
            return String(html || '').replace(
                /(<p\s+class\s*=\s*["']text_obisnuit["'][^>]*>\s*<\/p>)[ \t\r\n\u00a0]*<table/gi,
                '$1\n    <table'
            );
        }

        // Pagini categorie: după <!-- ARTICOL CATEGORIE START --> / <div align="justify">, inserează o copie a primului bloc articol (2× table 552 + text_obisnuit2 + text_obisnuit).
        function addCatDuplicateFirstArticle() {
            if (!editor) {
                toast('Editor indisponibil.');
                return;
            }
            if (!isCurrentFileHtml()) {
                toast('ADD-CAT este doar pentru fișiere HTML.');
                return;
            }
            const src = editor.getValue();
            const reg = findCategoryListRegion(src);
            if (!reg.ok) {
                toast(reg.msg);
                return;
            }
            const divEndGlobal = reg.divEndGlobal;
            const afterDiv = src.slice(divEndGlobal);
            const bm = afterDiv.match(CATEGORY_ARTICLE_BLOCK_RE);
            if (!bm) {
                toast('Nu am recunoscut primul articol (structură table 552 + text_obisnuit2 + table + text_obisnuit).');
                return;
            }
            const insertPos = divEndGlobal + bm[1].length;
            const firstBlock = bm[2];
            const newSrc = normalizeBreakAfterTextObisnuitBeforeTable(
                src.slice(0, insertPos) + firstBlock + src.slice(insertPos)
            );
            const cur = editor.getCursor();
            editor.setValue(newSrc);
            editor.setCursor(cur);
            isDirty = true;
            toast('ADD-CAT: primul articol duplicat.');
        }

        async function addCatMergeToCategory() {
            if (!editor) {
                toast('Editor indisponibil.');
                return;
            }
            if (!isCurrentFileHtml()) {
                toast('ADD-CAT este doar pentru fișiere HTML.');
                return;
            }
            const src = editor.getValue();
            const isRoCategoryMarker = src.indexOf(MARKER_CATEGORIE_START) !== -1;
            const listBlockCount = countCategoryListBlocks(src);
            if (isRoCategoryMarker || (src.indexOf(MARKER_ARTICOL_START) !== -1 && listBlockCount >= 1)) {
                addCatDuplicateFirstArticle();
                return;
            }
            const built = buildCategoryBlockFromArticleHtml(src);
            if (!built.ok) {
                toast('ADD-CAT: ' + built.msg);
                return;
            }
            if (!currentFile) {
                toast('ADD-CAT: salvează articolul cu o cale pe disc (același dosar ca paginile categorie).');
                return;
            }
            const catPath = categoryPathBesideArticle(currentFile, built.categoryFile);
            if (normPathLoose(catPath) === normPathLoose(currentFile)) {
                toast('ADD-CAT: linkul categoriei pare să fie același fișier ca articolul; verifică text_dreapta.');
                return;
            }
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            toast('ADD-CAT: citesc ' + built.categoryFile + '…');
            try {
                const loadUrl = apiBase + '?action=load&file=' + encodeURIComponent(catPath);
                const res = await fetch(loadUrl);
                const data = await res.json();
                if (!data.ok) {
                    toast('ADD-CAT: nu pot citi categoria: ' + (data.error || 'eroare'));
                    return;
                }
                const cat = data.content || '';
                const merged = mergeCategoryBlockIntoCategoryHtml(cat, built.block);
                if (!merged.ok) {
                    toast(merged.msg);
                    return;
                }
                if (merged.action === 'skip') {
                    toast('ADD-CAT: ' + merged.msg);
                    return;
                }
                const body = new URLSearchParams();
                body.append('file', catPath);
                body.append('content', merged.html);
                const resSave = await fetch(apiBase + '?action=save', { method: 'POST', body });
                const saveData = await resSave.json();
                if (!saveData.ok) {
                    toast('ADD-CAT: nu pot salva categoria: ' + (saveData.error || 'eroare'));
                    return;
                }
                toast('ADD-CAT: ' + merged.msg);
            } catch (e) {
                console.error(e);
                toast('ADD-CAT: ' + (e.message || String(e)));
            }
        }

        // Homepage listă articole: ro/ sau en/ după folderul curent.
        const TO_INDEX_RO_HTML_PATH = 'e:/Carte/BB/17 - Site Leadership/Principal/ro/index.html';
        const TO_INDEX_EN_HTML_PATH = 'e:/Carte/BB/17 - Site Leadership/Principal/en/index.html';

        function getToIndexPathForFile(filePath) {
            if (!filePath) return TO_INDEX_RO_HTML_PATH;
            const norm = String(filePath).replace(/\\/g, '/').toLowerCase();
            if (norm.indexOf('/principal/en/') !== -1) return TO_INDEX_EN_HTML_PATH;
            return TO_INDEX_RO_HTML_PATH;
        }

        const RO_MONTH_TO_INDEX = { ianuarie: 0, februarie: 1, martie: 2, aprilie: 3, mai: 4, iunie: 5, iulie: 6, august: 7, septembrie: 8, octombrie: 9, noiembrie: 10, decembrie: 11 };
        const EN_MONTH_TO_INDEX = { january: 0, february: 1, march: 2, april: 3, may: 4, june: 5, july: 6, august: 7, september: 8, october: 9, november: 10, december: 11 };

        function monthIndexFromRoEnName(name) {
            const k = String(name || '').trim().toLowerCase()
                .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
                .replace(/[\u200b-\u200d\ufeff]/g, '');
            if (Object.prototype.hasOwnProperty.call(RO_MONTH_TO_INDEX, k)) return RO_MONTH_TO_INDEX[k];
            if (Object.prototype.hasOwnProperty.call(EN_MONTH_TO_INDEX, k)) return EN_MONTH_TO_INDEX[k];
            return null;
        }

        // Data din <td class="text_dreapta">: text vizibil „On Lună zi, an” (fără a depinde de poziția față de taguri).
        function parseCategoryArticleLineDate(blockHtml) {
            if (!blockHtml) return null;
            const tdM = blockHtml.match(/class\s*=\s*["']text_dreapta["'][^>]*>([\s\S]*?)<\/td>/i);
            if (!tdM) return null;
            const plain = tdM[1]
                .replace(/<[^>]+>/g, ' ')
                .replace(/&nbsp;|&#160;/gi, ' ')
                .replace(/\s+/g, ' ')
                .trim();
            let dm = plain.match(/\bOn\s+(.+?)\s+(\d{1,2}),\s*(\d{4})\b/i);
            if (!dm) dm = plain.match(/\bOn\s+(.+?)\s+(\d{1,2})\s+(\d{4})\b/i);
            if (!dm) return null;
            const monthIdx = monthIndexFromRoEnName(dm[1].trim());
            if (monthIdx === null) return null;
            const day = parseInt(dm[2], 10);
            const year = parseInt(dm[3], 10);
            if (!Number.isFinite(day) || !Number.isFinite(year) || day < 1 || day > 31 || year < 1900) return null;
            const date = new Date(year, monthIdx, day);
            if (date.getFullYear() !== year || date.getMonth() !== monthIdx || date.getDate() !== day) return null;
            const ms = date.getTime();
            return Number.isFinite(ms) ? ms : null;
        }

        function normPathLoose(p) {
            return String(p || '').replace(/\\/g, '/').replace(/\s+/g, '').toLowerCase();
        }

        // START…FINAL: articolul cu data calendaristică cea mai mare (ex. Martie 2026 > Ianuarie 2011). Fără date valide → primul bloc.
        function extractFirstCategoryArticleFromSource(html) {
            const reg = findCategoryListRegion(html);
            if (!reg.ok) return null;
            const divEnd = reg.divEndGlobal;
            const regionEnd = reg.regionEnd;
            const region = html.slice(divEnd, regionEnd);
            const scored = [];
            let firstFallback = null;
            let pos = 0;
            let ord = 0;
            for (;;) {
                const m = region.slice(pos).match(CATEGORY_ARTICLE_BLOCK_RE);
                if (!m) break;
                const block = m[2];
                if (firstFallback === null) firstFallback = block;
                const t = parseCategoryArticleLineDate(block);
                if (t !== null) scored.push({ t: t, ord: ord, block: block });
                pos += m[0].length;
                ord++;
            }
            if (scored.length > 0) {
                scored.sort(function (a, b) {
                    if (b.t !== a.t) return b.t - a.t;
                    return a.ord - b.ord;
                });
                return scored[0].block;
            }
            return firstFallback;
        }

        function locateIndexCategorySectionBounds(indexHtml) {
            const r = findCategoryListRegion(indexHtml);
            if (!r.ok) {
                return { ok: false, msg: 'În index lipsește secțiunea listei (ARTICOL CATEGORIE START sau ARTICOL START).' };
            }
            return { ok: true, divEndGlobal: r.divEndGlobal, regionEnd: r.regionEnd };
        }

        function locateIndexCategoryDivEnd(indexHtml) {
            const b = locateIndexCategorySectionBounds(indexHtml);
            if (!b.ok) return b;
            return { ok: true, divEndGlobal: b.divEndGlobal };
        }

        function compactArticleHtmlWs(s) {
            return String(s || '').replace(/\s+/g, ' ').trim();
        }

        function articleTitleFromBlock(blockHtml) {
            if (!blockHtml) return '';
            const m = blockHtml.match(/<a[^>]*\blinkMare\b[^>]*>([^<]*)<\/a>/i);
            return m ? m[1].replace(/\s+/g, ' ').trim().toLowerCase() : '';
        }

        function articleDateLineFromBlock(blockHtml) {
            if (!blockHtml) return '';
            const m = blockHtml.match(/class\s*=\s*["']text_dreapta["'][^>]*>([\s\S]*?)<\/td>/i);
            if (!m) return '';
            return m[1].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
        }

        // Titlu (linkMare) + linia „On … by …” din text_dreapta — pentru a evita dublura în index.
        function articleSignatureFromBlock(blockHtml) {
            const t = articleTitleFromBlock(blockHtml);
            if (!t) return '';
            let d = articleDateLineFromBlock(blockHtml);
            if (!d) {
                const ts = parseCategoryArticleLineDate(blockHtml);
                if (ts === null) return '';
                d = String(ts);
            }
            return t + '\u241e' + d;
        }

        function normalizeArticleKeyFromBlock(blockHtml) {
            if (!blockHtml) return '';
            let m = blockHtml.match(/class\s*=\s*["']den_articol["'][^>]*>[\s\S]*?<a[^>]*\bhref\s*=\s*["']([^"']+)["']/i);
            if (!m) m = blockHtml.match(/<a[^>]*\bclass\s*=\s*["'][^"']*\blinkMare\b[^"']*["'][^>]*\bhref\s*=\s*["']([^"']+)["']/i);
            if (!m) m = blockHtml.match(/<a[^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*\bclass\s*=\s*["'][^"']*\blinkMare\b[^"']*["']/i);
            if (!m) return '';
            const h = m[1].trim();
            try {
                if (/^https?:\/\//i.test(h)) {
                    const u = new URL(h);
                    return (u.pathname || '').replace(/^\/+/, '').toLowerCase();
                }
            } catch (e) { }
            const base = h.split('#')[0].split('?')[0].replace(/\\/g, '/');
            const parts = base.split('/');
            return parts[parts.length - 1].toLowerCase();
        }

        function enumerateIndexCategoryBlocks(indexHtml, divEndGlobal, regionEnd) {
            const list = [];
            const endAt = regionEnd === undefined || regionEnd === null ? indexHtml.length : regionEnd;
            const region = indexHtml.slice(divEndGlobal, endAt);
            let pos = 0;
            for (;;) {
                const m = region.slice(pos).match(CATEGORY_ARTICLE_BLOCK_RE);
                if (!m) break;
                const blockStart = divEndGlobal + pos + m[1].length;
                const blockEnd = blockStart + m[2].length;
                list.push({
                    start: blockStart,
                    end: blockEnd,
                    block: m[2],
                    key: normalizeArticleKeyFromBlock(m[2])
                });
                pos += m[0].length;
            }
            return list;
        }

        function getInsertPosAfterCategoryDiv(indexHtml, divEndGlobal) {
            const afterDiv = indexHtml.slice(divEndGlobal);
            const bm = afterDiv.match(CATEGORY_ARTICLE_BLOCK_RE);
            if (bm) return divEndGlobal + bm[1].length;
            const ws = afterDiv.match(/^(\s*)/);
            return divEndGlobal + (ws ? ws[1].length : 0);
        }

        /** Înlocuiește spațiul gol între <div align="justify"> și punctul de inserare cu un singur \n + 4 spații (fără rânduri goale multiple). */
        function collapseWhitespaceGapBeforeInsert(html, divEndGlobal, insertPos) {
            if (insertPos <= divEndGlobal) return { html: html, insertPos: insertPos };
            const gap = html.slice(divEndGlobal, insertPos);
            if (!/^\s*$/.test(gap)) return { html: html, insertPos: insertPos };
            const normalizedGap = '\n    ';
            return {
                html: html.slice(0, divEndGlobal) + normalizedGap + html.slice(insertPos),
                insertPos: divEndGlobal + normalizedGap.length
            };
        }

        function insertBlockAfterIndexCategoryDiv(indexHtml, blockHtml) {
            const loc = locateIndexCategoryDivEnd(indexHtml);
            if (!loc.ok) return loc;
            const divEnd = loc.divEndGlobal;
            let insertPos = getInsertPosAfterCategoryDiv(indexHtml, divEnd);
            const collapsed = collapseWhitespaceGapBeforeInsert(indexHtml, divEnd, insertPos);
            const htmlWork = collapsed.html;
            insertPos = collapsed.insertPos;
            const raw = htmlWork.slice(0, insertPos) + blockHtml + htmlWork.slice(insertPos);
            return {
                ok: true,
                html: normalizeBreakAfterTextObisnuitBeforeTable(raw)
            };
        }

        function categoryPathBesideArticle(articlePath, categoryFileName) {
            const ap = String(articlePath || '').replace(/[/\\]+$/, '');
            const idx = Math.max(ap.lastIndexOf('/'), ap.lastIndexOf('\\'));
            if (idx === -1) return String(categoryFileName || '');
            return ap.slice(0, idx + 1) + String(categoryFileName || '');
        }

        function cleanArticleListTitle(rawTitle) {
            return String(rawTitle || '')
                .replace(/\s+/g, ' ')
                .replace(/\s*\|\s*Neculai\s+Fantanaru(?:\s*\([^)]*\))?\s*$/i, '')
                .trim();
        }

        /**
         * Din HTML articol (fără pagină categorie): canonical, title, meta description, text_dreapta
         * → același bloc ca în listele categorie/index. Deduce leadership-foo.html din linkuri .html ≠ articol.
         */
        function buildCategoryBlockFromArticleHtml(html) {
            const canM = html.match(/<link[^>]*\brel\s*=\s*["']canonical["'][^>]*\bhref\s*=\s*["']([^"']+)["']/i)
                || html.match(/<link[^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*\brel\s*=\s*["']canonical["']/i);
            const canonical = canM ? canM[1].trim() : '';
            if (!canonical) return { ok: false, msg: 'Lipsește link canonical.' };

            let title = '';
            const h1M = html.match(/<h1\b[^>]*\bclass\s*=\s*["'][^"']*\bden_articol\b[^"']*["'][^>]*>([\s\S]*?)<\/h1>/i);
            // Doar articolele au <h1 class="den_articol">. index.html și paginile de categorie nu au —
            // fără această oprire, la Save pe index.html se insera un bloc „index” într-o categorie.
            if (!h1M) {
                return { ok: false, msg: 'Nu este o pagină de articol (lipsește &lt;h1 class=&quot;den_articol&quot;&gt;).' };
            }
            if (h1M) {
                title = cleanArticleListTitle(plainTextFromEmInnerHtml(h1M[1]));
            }
            if (!title) {
                const tM = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
                if (tM) {
                    title = cleanArticleListTitle(tM[1]);
                }
            }
            if (!title) return { ok: false, msg: 'Lipsește &lt;title&gt;.' };

            let desc = getCategorySyncDescriptionFromArticleHtml(html) || '';

            let canonFile = '';
            try {
                const u = new URL(canonical);
                const seg = (u.pathname || '').replace(/\/+$/, '').split('/');
                canonFile = decodeURIComponent(seg[seg.length - 1] || '').toLowerCase();
            } catch (e) { }

            let textDreaptaInner = '';
            const tdRe = /<td\b[^>]*\bclass\s*=\s*["']([^"']*)["'][^>]*>([\s\S]*?)<\/td>/gi;
            let m;
            let best = '';
            while ((m = tdRe.exec(html)) !== null) {
                if (!/\btext_dreapta\b/i.test(m[1])) continue;
                const inner = m[2].trim();
                if (/\bOn\s+/i.test(inner) && (/category\s+tag|\bexternal\b|rel\s*=\s*["'][^"']*category/i.test(inner) || /\.html\b/i.test(inner))) {
                    if (inner.length >= best.length) best = inner;
                }
            }
            if (!best) {
                tdRe.lastIndex = 0;
                while ((m = tdRe.exec(html)) !== null) {
                    if (!/\btext_dreapta\b/i.test(m[1])) continue;
                    const inner = m[2].trim();
                    if (/\bOn\s+/i.test(inner)) { best = inner; break; }
                }
            }
            textDreaptaInner = best;
            if (!textDreaptaInner) return { ok: false, msg: 'Nu am găsit &lt;td class=&quot;text_dreapta&quot;&gt; cu „On …” în articol.' };

            let categoryFile = '';
            const linkRe = /<a\b[^>]*\bhref\s*=\s*["']([^"']+)["']/gi;
            let lm;
            while ((lm = linkRe.exec(textDreaptaInner)) !== null) {
                const href = lm[1].trim();
                let fn = '';
                try {
                    const u = new URL(href, canonical);
                    fn = decodeURIComponent((u.pathname || '').split('/').pop() || '').toLowerCase();
                } catch (e) {
                    fn = href.split('/').pop().split('?')[0].toLowerCase();
                }
                if (!fn || !/\.html?$/i.test(fn)) continue;
                if (canonFile && fn === canonFile) continue;
                categoryFile = href.split('/').pop().split('?')[0];
                if (!/^[a-z0-9._-]+\.html?$/i.test(categoryFile)) {
                    try {
                        categoryFile = decodeURIComponent((new URL(href, canonical).pathname || '').split('/').pop() || '');
                    } catch (e2) { }
                }
                break;
            }
            if (!categoryFile) return { ok: false, msg: 'Nu am putut deduce pagina categoriei (link .html în text_dreapta, ≠ articol).' };

            let homeOrigin = 'https://neculaifantanaru.com/';
            let isEnArticle = false;
            try {
                const u = new URL(canonical);
                const p = (u.pathname || '').toLowerCase();
                if (p.indexOf('/en/') === 0 || p === '/en' || p.indexOf('/en/') !== -1) {
                    homeOrigin = u.origin + '/en/';
                    isEnArticle = true;
                } else {
                    homeOrigin = u.origin + '/';
                }
            } catch (e) { }

            const readMoreLabel = isEnArticle ? 'read more ' : 'citește mai departe ';

            const escDesc = desc.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const escTitle = title.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

            const block =
                '    <table width="601" border="0">\n' +
                '          <tbody><tr>\n' +
                '            <td><span class="den_articol"><a href="' + canonical + '" class="linkMare">' + escTitle + '</a></span></td>\n' +
                '          </tr>\n' +
                '          <tr>\n' +
                '            <td class="text_dreapta">' + textDreaptaInner + '</td>\n' +
                '          </tr>\n' +
                '        </tbody>\n' +
                '</table>\n' +
                '        <p class="text_obisnuit2"><em>' + escDesc + '</em></p>\n' +
                '        <table width="552" border="0">\n' +
                '          <tbody><tr>\n' +
                '            <td width="552"><div align="right" id="external2"><a href="' + canonical + '">' + readMoreLabel + '</a><a href="' + homeOrigin + '" title=""><img src="Arrow3_black_5x7.gif" alt="" width="5" height="7" class="arrow"></a></div>\n' +
                '</td>\n' +
                '          </tr>\n' +
                '        </tbody>\n' +
                '</table>\n' +
                '\t\t<p class="text_obisnuit"></p>';

            return { ok: true, block: block, categoryFile: categoryFile };
        }

        /**
         * Inserează / actualizează bloc în pagină categorie: ordine după dată (cel mai nou primul),
         * fără dubluri (același titlu+dat URL ca lista index).
         */
        function mergeCategoryBlockIntoCategoryHtml(categoryHtml, blockHtml) {
            const bounds = locateIndexCategorySectionBounds(categoryHtml);
            if (!bounds.ok) return { ok: false, msg: bounds.msg };
            let htmlWork = categoryHtml;
            let blocks = enumerateIndexCategoryBlocks(htmlWork, bounds.divEndGlobal, bounds.regionEnd);
            const sigNew = articleSignatureFromBlock(blockHtml);
            const keyNew = normalizeArticleKeyFromBlock(blockHtml);
            const newTs = parseCategoryArticleLineDate(blockHtml);

            const removeSegs = blocks.filter(function (b) {
                if (sigNew && articleSignatureFromBlock(b.block) === sigNew) return true;
                if (keyNew && normalizeArticleKeyFromBlock(b.block) === keyNew) return true;
                return false;
            });
            removeSegs.sort(function (a, b) { return b.start - a.start; });
            removeSegs.forEach(function (seg) {
                htmlWork = htmlWork.slice(0, seg.start) + htmlWork.slice(seg.end);
            });

            const bounds2 = locateIndexCategorySectionBounds(htmlWork);
            if (!bounds2.ok) return { ok: false, msg: bounds2.msg };
            const blocks2 = enumerateIndexCategoryBlocks(htmlWork, bounds2.divEndGlobal, bounds2.regionEnd);

            const compactNew = compactArticleHtmlWs(blockHtml);
            for (let i = 0; i < blocks2.length; i++) {
                if (compactArticleHtmlWs(blocks2[i].block) === compactNew) {
                    return {
                        ok: true,
                        html: htmlWork,
                        action: 'skip',
                        msg: 'Articolul este deja în categorie (același text).'
                    };
                }
            }

            // Ordine descrescătoare după dată (cel mai nou sus). Poziție: înainte de primul segment
            // a cărui dată e ≤ cea a articolului (inclusiv la egalitate — „cel mai apropiat” în listă).
            // Articol fără dată parsată → la sfârșitul listei (nu la început).
            let insertPos;
            if (newTs === null) {
                if (blocks2.length === 0) {
                    insertPos = getInsertPosAfterCategoryDiv(htmlWork, bounds2.divEndGlobal);
                } else {
                    insertPos = blocks2[blocks2.length - 1].end;
                }
            } else {
                let found = false;
                for (let i = 0; i < blocks2.length; i++) {
                    const bts = parseCategoryArticleLineDate(blocks2[i].block);
                    if (bts !== null && bts <= newTs) {
                        insertPos = blocks2[i].start;
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    if (blocks2.length === 0) {
                        insertPos = getInsertPosAfterCategoryDiv(htmlWork, bounds2.divEndGlobal);
                    } else {
                        insertPos = blocks2[blocks2.length - 1].end;
                    }
                }
            }

            const collapsed = collapseWhitespaceGapBeforeInsert(htmlWork, bounds2.divEndGlobal, insertPos);
            htmlWork = collapsed.html;
            insertPos = collapsed.insertPos;
            const raw = htmlWork.slice(0, insertPos) + blockHtml + htmlWork.slice(insertPos);
            const action = removeSegs.length ? 'move' : 'insert';
            const msg = removeSegs.length
                ? 'Instanță reordonată în categorie (după dată).'
                : 'Instanță adăugată în categorie (după dată).';
            return {
                ok: true,
                html: normalizeBreakAfterTextObisnuitBeforeTable(raw),
                action: action,
                msg: msg
            };
        }

        function resolveArticleLinkedCategory(filePath, html) {
            const built = buildCategoryBlockFromArticleHtml(html);
            if (!built.ok) return null;
            const catPath = categoryPathBesideArticle(filePath, built.categoryFile);
            if (normPathLoose(catPath) === normPathLoose(filePath)) return null;
            return {
                categoryPath: catPath,
                articleKey: normalizeArticleKeyFromBlock(built.block)
            };
        }

        function replaceCategoryTeaserForArticleKey(categoryHtml, articleKey, newPlainDescription) {
            if (!articleKey) return { ok: true, html: categoryHtml, changed: false };
            const bounds = findCategoryListRegion(categoryHtml);
            if (!bounds.ok) return { ok: false, html: categoryHtml, changed: false };
            const blocks = enumerateIndexCategoryBlocks(categoryHtml, bounds.divEndGlobal, bounds.regionEnd);
            let target = null;
            for (let i = 0; i < blocks.length; i++) {
                if (normalizeArticleKeyFromBlock(blocks[i].block) === articleKey) {
                    target = blocks[i];
                    break;
                }
            }
            if (!target) {
                const loose = findCategoryTeaserSegmentByArticleKey(categoryHtml, bounds, articleKey);
                if (!loose) return { ok: true, html: categoryHtml, changed: false };
                const emEscLoose = String(newPlainDescription || '')
                    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                const newLoose = loose.html.replace(
                    /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>\s*<em[^>]*>)([\s\S]*?)(<\/em>\s*<\/p>)/i,
                    '$1' + emEscLoose + '$3'
                );
                if (newLoose === loose.html) return { ok: true, html: categoryHtml, changed: false };
                const outLoose = categoryHtml.slice(0, loose.start) + newLoose + categoryHtml.slice(loose.end);
                return { ok: true, html: normalizeBreakAfterTextObisnuitBeforeTable(outLoose), changed: true };
            }
            const emEsc = String(newPlainDescription || '')
                .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            const newBlock = target.block.replace(
                /(<p\b[^>]*\bclass\s*=\s*["']text_obisnuit2["'][^>]*>\s*<em[^>]*>)([\s\S]*?)(<\/em>\s*<\/p>)/i,
                '$1' + emEsc + '$3'
            );
            if (newBlock === target.block) return { ok: true, html: categoryHtml, changed: false };
            const out = categoryHtml.slice(0, target.start) + newBlock + categoryHtml.slice(target.end);
            return { ok: true, html: normalizeBreakAfterTextObisnuitBeforeTable(out), changed: true };
        }

        // Înlocuiește întregul bloc al articolului (title + text_dreapta + teaser) pentru același articleKey.
        function articleKeyFileName(articleKey) {
            const k = String(articleKey || '').split('#')[0].split('?')[0].replace(/\\/g, '/').toLowerCase();
            const parts = k.split('/');
            return parts[parts.length - 1] || k;
        }

        function escapeRegexLiteral(s) {
            return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }

        // Fallback pentru pagini categorie serializate diferit: gaseste teaserul dupa href-ul articolului.
        function findCategoryTeaserSegmentByArticleKey(categoryHtml, bounds, articleKey) {
            if (!bounds || !bounds.ok || !articleKey) return null;
            const fileName = articleKeyFileName(articleKey);
            if (!fileName) return null;
            const regionStart = bounds.divEndGlobal;
            const regionEnd = bounds.regionEnd || categoryHtml.length;
            const region = categoryHtml.slice(regionStart, regionEnd);
            const hrefRe = new RegExp('<a\\b[^>]*\\bhref\\s*=\\s*["\'][^"\']*' + escapeRegexLiteral(fileName) + '(?:[?#][^"\']*)?["\'][^>]*>', 'i');
            const hrefM = hrefRe.exec(region);
            if (!hrefM) return null;
            const afterHref = region.slice(hrefM.index + hrefM[0].length);
            const pRe = /<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>\s*<em[^>]*>[\s\S]*?<\/em>\s*<\/p>/i;
            const pM = pRe.exec(afterHref);
            if (!pM) return null;
            const start = regionStart + hrefM.index + hrefM[0].length + pM.index;
            return { start: start, end: start + pM[0].length, html: pM[0] };
        }

        function replaceCategoryBlockForArticleKey(categoryHtml, articleKey, newBlockHtml) {
            if (!articleKey || !newBlockHtml) return { ok: true, html: categoryHtml, changed: false };
            const bounds = findCategoryListRegion(categoryHtml);
            if (!bounds.ok) return { ok: false, html: categoryHtml, changed: false };
            const blocks = enumerateIndexCategoryBlocks(categoryHtml, bounds.divEndGlobal, bounds.regionEnd);
            let target = null;
            for (let i = 0; i < blocks.length; i++) {
                if (normalizeArticleKeyFromBlock(blocks[i].block) === articleKey) {
                    target = blocks[i];
                    break;
                }
            }
            if (!target) return { ok: true, html: categoryHtml, changed: false };
            if (compactArticleHtmlWs(target.block) === compactArticleHtmlWs(newBlockHtml)) {
                return { ok: true, html: categoryHtml, changed: false };
            }
            const out = categoryHtml.slice(0, target.start) + newBlockHtml + categoryHtml.slice(target.end);
            return { ok: true, html: normalizeBreakAfterTextObisnuitBeforeTable(out), changed: true };
        }

        /** Textul din <em> din blocul listă categorie pentru articolul cu același articleKey (normalizeArticleKeyFromBlock). */
        function extractCategoryTeaserPlainForArticleKey(categoryHtml, articleKey) {
            if (!articleKey) return null;
            const bounds = findCategoryListRegion(categoryHtml);
            if (!bounds.ok) return null;
            const blocks = enumerateIndexCategoryBlocks(categoryHtml, bounds.divEndGlobal, bounds.regionEnd);
            for (let i = 0; i < blocks.length; i++) {
                if (normalizeArticleKeyFromBlock(blocks[i].block) !== articleKey) continue;
                const m = blocks[i].block.match(/<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>[\s\S]*?<em\b[^>]*>([\s\S]*?)<\/em>[\s\S]*?<\/p>/i);
                if (!m) return '';
                return plainTextFromEmInnerHtml(m[1]);
            }
            const loose = findCategoryTeaserSegmentByArticleKey(categoryHtml, bounds, articleKey);
            if (loose) {
                const m = loose.html.match(/<em\b[^>]*>([\s\S]*?)<\/em>/i);
                if (!m) return '';
                return plainTextFromEmInnerHtml(m[1]);
            }
            return null;
        }

        /**
         * Articolul este sursa de adevăr: aliniază teaserul în pagina categorie și, dacă articolul apare în index,
         * și în ro/index.html sau en/index.html (același articleKey). index e tratat silențios (fără toast la erori).
         */
        async function reconcileLinkedCategoryTeaserWithArticle(articleTab, articleHtml, opts) {
            opts = opts || {};
            if (!articleTab || articleTab.type === 'browser') return;
            refreshTabLinkedCategory(articleTab);
            const catPath = articleTab.linkedCategoryPath;
            const aKey = articleTab.linkedArticleKey;
            if (!catPath || !aKey) return;
            const articleDesc = getCategorySyncDescriptionFromArticleHtml(articleHtml);
            const builtArticleBlock = buildCategoryBlockFromArticleHtml(articleHtml);
            const articleBlock = builtArticleBlock && builtArticleBlock.ok ? builtArticleBlock.block : '';
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');

            async function syncListPageAtPath(listPath, isCategoryFile) {
                if (!listPath) return;
                try {
                    const res = await fetch(apiBase + '?action=load&file=' + encodeURIComponent(listPath));
                    const data = await res.json();
                    if (!data.ok) {
                        if (isCategoryFile && !opts.silent && opts.context !== 'focus') {
                            toast('Categorie: nu pot citi fișierul pentru alinierea descrierii.');
                        }
                        return;
                    }
                    const listHtml = data.content || '';
                    const curTeaser = extractCategoryTeaserPlainForArticleKey(listHtml, aKey);
                    if (curTeaser === null) {
                        if (isCategoryFile && !opts.silent && opts.context !== 'focus') {
                            toast('Categorie: nu am găsit intrarea articolului în lista categorie.');
                        }
                        return;
                    }
                    let rep = null;
                    if (articleBlock) {
                        rep = replaceCategoryBlockForArticleKey(listHtml, aKey, articleBlock);
                        if (rep && !rep.changed && normalizeDescCompare(articleDesc) !== normalizeDescCompare(curTeaser)) {
                            rep = replaceCategoryTeaserForArticleKey(listHtml, aKey, articleDesc);
                        }
                    } else {
                        if (normalizeDescCompare(articleDesc) === normalizeDescCompare(curTeaser)) return;
                        rep = replaceCategoryTeaserForArticleKey(listHtml, aKey, articleDesc);
                    }
                    if (!rep.changed) {
                        if (isCategoryFile && !opts.silent && normalizeDescCompare(articleDesc) !== normalizeDescCompare(curTeaser)) {
                            toast(articleBlock
                                ? 'Categorie: nu am putut înlocui blocul articolului pentru acest articol.'
                                : 'Categorie: nu am putut înlocui paragraful text_obisnuit2 pentru acest articol.');
                        }
                        return;
                    }
                    const body = new URLSearchParams();
                    body.append('file', listPath);
                    body.append('content', rep.html);
                    const resSave = await fetch(apiBase + '?action=save', { method: 'POST', body: body });
                    const saveData = await resSave.json();
                    if (!saveData.ok) {
                        if (isCategoryFile && !opts.silent) {
                            toast('Categorie: nu pot salva descrierea aliniată la articol.');
                        }
                        return;
                    }
                    if (!opts.silent && isCategoryFile) {
                        var msg = (opts.context === 'open')
                            ? 'Descrierea din articol era diferită — am actualizat și salvat pagina categorie.'
                            : (opts.context === 'save')
                                ? 'Descrierea a fost sincronizată și în pagina categorie.'
                                : 'Pagina categorie a fost aliniată la articol.';
                        toast(msg);
                    }
                    var t = findTabByPath(listPath);
                    if (t) {
                        t.editorContent = rep.html;
                        t.originalContent = rep.html;
                        t.originalContentNorm = normalizeHtmlForCompare(rep.html);
                        t.isDirty = false;
                        if (t.id === activeTabId && editor) {
                            isSyncFromDesign = true;
                            editor.setValue(rep.html);
                            isSyncFromDesign = false;
                        }
                        updateTabPresentation(t);
                    }
                } catch (err) {
                    console.error(err);
                    if (isCategoryFile && !opts.silent) {
                        toast('Eroare la alinierea descrierii articol → categorie.');
                    }
                }
            }

            await syncListPageAtPath(catPath, true);
            var idxPath = getToIndexPathForFile(articleTab.filePath || '');
            if (idxPath && normPathLoose(idxPath) !== normPathLoose(catPath)) {
                await syncListPageAtPath(idxPath, false);
            }
        }

        function refreshTabLinkedCategory(tab) {
            if (!tab || tab.type === 'browser') {
                if (tab) {
                    tab.linkedCategoryPath = null;
                    tab.linkedArticleKey = null;
                }
                return;
            }
            if (!tab.filePath) {
                tab.linkedCategoryPath = null;
                tab.linkedArticleKey = null;
                return;
            }
            tab.linkedCategoryPath = null;
            tab.linkedArticleKey = null;
            const html = String(tab.editorContent || '').replace(/\r\n/g, '\n');
            const r = resolveArticleLinkedCategory(tab.filePath, html);
            if (r) {
                tab.linkedCategoryPath = r.categoryPath;
                tab.linkedArticleKey = r.articleKey;
            }
        }

        async function syncLinkedCategoryDescriptionAfterArticleSave(tab, savedHtml) {
            await reconcileLinkedCategoryTeaserWithArticle(tab, savedHtml, { context: 'save', silent: true });
        }

        // Sincronizare robustă după Save pentru pagini de tip articol:
        // actualizează/inserează blocul complet în categoria aferentă și în index.
        async function syncArticleBlockToCategoryAndIndexAfterSave(filePath, articleHtml) {
            if (!filePath || !articleHtml) return;
            const built = buildCategoryBlockFromArticleHtml(articleHtml);
            if (!built || !built.ok) return;
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const catPath = categoryPathBesideArticle(filePath, built.categoryFile);
            const idxPath = getToIndexPathForFile(filePath);

            async function mergeIntoFile(targetPath, mergerFn) {
                if (!targetPath) return;
                try {
                    const resLoad = await fetch(apiBase + '?action=load&file=' + encodeURIComponent(targetPath));
                    const loadData = await resLoad.json();
                    if (!loadData.ok) return;
                    const srcHtml = loadData.content || '';
                    const merged = mergerFn(srcHtml, built.block);
                    if (!merged || !merged.ok || merged.action === 'skip') return;
                    const body = new URLSearchParams();
                    body.append('file', targetPath);
                    body.append('content', merged.html);
                    await fetch(apiBase + '?action=save', { method: 'POST', body: body });

                    var t = findTabByPath(targetPath);
                    if (t) {
                        t.editorContent = merged.html;
                        t.originalContent = merged.html;
                        t.originalContentNorm = normalizeHtmlForCompare(merged.html);
                        t.isDirty = false;
                        if (t.id === activeTabId && editor) {
                            isSyncFromDesign = true;
                            editor.setValue(merged.html);
                            isSyncFromDesign = false;
                        }
                        updateTabPresentation(t);
                    }
                } catch (e) {
                    console.error(e);
                }
            }

            if (normPathLoose(catPath) !== normPathLoose(filePath)) {
                await mergeIntoFile(catPath, mergeCategoryBlockIntoCategoryHtml);
            }
            if (idxPath && normPathLoose(idxPath) !== normPathLoose(filePath)) {
                await mergeIntoFile(idxPath, mergeCategoryBlockIntoIndex);
            }
        }

        // ── Data schimbată într-o pagină de categorie (sau index.html) → se schimbă și în articol ──
        // La Save pe o pagină-listă: compară data fiecărui articol din listă cu versiunea salvată
        // anterior. Unde s-a schimbat, scrie data nouă în articol și în cealaltă listă
        // (categorie ↔ index), fără să schimbe altceva în acele fișiere.
        const LIST_DATE_RE = /\bOn\s+[^\s\d,<]+\s+\d{1,2},?\s+\d{4}/i;

        function listBlockDateText(blockHtml) {
            const td = /class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i.exec(blockHtml || '');
            if (!td) return null;
            const m = LIST_DATE_RE.exec(td[1]);
            return m ? m[0] : null;
        }

        // Înlocuiește data din primul <td class="text_dreapta"> de după `fromIdx`
        function replaceTextDreaptaDate(html, fromIdx, newDate) {
            const re = /(class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>)([\s\S]*?)(<\/td>)/i;
            const slice = html.slice(fromIdx);
            const m = re.exec(slice);
            if (!m || !LIST_DATE_RE.test(m[2])) return null;
            const inner = m[2].replace(LIST_DATE_RE, newDate);
            if (inner === m[2]) return null;
            const at = fromIdx + m.index + m[1].length;
            return html.slice(0, at) + inner + html.slice(at + m[2].length);
        }

        function listDateMap(html) {
            const map = new Map();
            const r = findCategoryListRegion(html);
            if (!r.ok) return map;
            enumerateIndexCategoryBlocks(html, r.divEndGlobal, r.regionEnd).forEach(b => {
                const d = listBlockDateText(b.block);
                if (b.key && d && !map.has(b.key)) map.set(b.key, d);
            });
            return map;
        }

        async function syncListDatesToArticlesAfterSave(listPath, oldHtml, newHtml) {
            if (!listPath || !oldHtml || !newHtml || !isHtmlCategoryListingPage(newHtml)) return;
            const before = listDateMap(oldHtml);
            const after = listDateMap(newHtml);
            const changes = [];
            after.forEach((d, key) => {
                const old = before.get(key);
                if (old && old.replace(/\s+/g, ' ') !== d.replace(/\s+/g, ' ') && parseCategoryArticleLineDate('<td class="text_dreapta">' + d + '</td>') !== null) {
                    changes.push({ key, date: d });
                }
            });
            if (!changes.length) return;
            const dir = String(listPath).replace(/\\/g, '/').replace(/\/[^\/]*$/, '');
            const isIndex = /\/index\.html?$/i.test(String(listPath).replace(/\\/g, '/'));
            const updated = [];

            // Lista salvată (categoria / index-ul deschis): blocurile cu data schimbată la locul lor
            try {
                const apiBase = window.location.pathname.replace(/[#?].*$/, '');
                const body = new URLSearchParams();
                body.append('file', listPath);
                const s = await (await fetch(apiBase + '?action=sortListByDate', { method: 'POST', body })).json();
                if (s && s.ok && s.changed) {
                    await dateSyncRefreshTab(listPath);
                    toast('Am pus articolele din listă în ordinea datelor.');
                }
            } catch (e) { console.error(e); }

            for (const ch of changes) {
                const name = ch.key.split('/').pop();
                const articlePath = dir + '/' + name;
                const oldDate = before.get(ch.key);
                try {
                    // 1) articolul (doar data se schimbă)
                    if (await dateSyncReplace(articlePath, 'article', '', ch.date, '')) updated.push(name);
                    // 2) cealaltă listă: index ↔ categorie
                    let otherPath = '';
                    if (isIndex) {
                        const art = await dateSyncLoad(articlePath);
                        const h = art ? art.search(/<h1\b[^>]*class\s*=\s*["'][^"']*\bden_articol\b/i) : -1;
                        const catLink = h !== -1 ? /class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>[\s\S]*?<a\b[^>]*\bhref\s*=\s*["']([^"']+)["']/i.exec(art.slice(h)) : null;
                        if (catLink) otherPath = dir + '/' + catLink[1].split('#')[0].split('?')[0].split('/').pop();
                    } else {
                        otherPath = dir + '/index.html';
                    }
                    if (otherPath && normPathLoose(otherPath) !== normPathLoose(listPath) &&
                        await dateSyncReplace(otherPath, 'list', name, ch.date, oldDate)) {
                        updated.push(otherPath.split('/').pop());
                    }
                } catch (e) {
                    console.error(e);
                }
            }
            if (updated.length) {
                toast('Data schimbată a fost scrisă și în: ' + Array.from(new Set(updated)).join(', '));
                scheduleRecentArticlesCheck(2000);
            }
            // Articolele ro modificate → și traducerile lor din en/
            if (/\/ro$/i.test(dir)) {
                for (const ch of changes) {
                    const articlePath = dir + '/' + ch.key.split('/').pop();
                    try {
                        const art = await dateSyncLoad(articlePath);
                        if (art !== null) await syncDateToEnglishCounterpart(articlePath, art);
                    } catch (e) { console.error(e); }
                }
            }
        }

        // ── Data unui articol din ro/ → și în articolul analog din en/ ──
        // Analogul e linkul https://neculaifantanaru.com/en/… din secțiunea FLAGS a articolului ro.
        // Se actualizează: articolul en, blocul lui din categoria en și din en/index.html (dacă există).
        // Dacă traducerea nu există încă în en/, nu se face nimic.
        async function dateSyncLoad(p) {
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            try {
                const d = await (await fetch(apiBase + '?action=load&file=' + encodeURIComponent(p), { cache: 'no-store' })).json();
                return d && d.ok ? (d.content || '') : null;
            } catch (e) { return null; }
        }
        // Schimbă DOAR data în fișier (pe server, fără alte curățări). true = s-a schimbat.
        //  mode 'article' → data de sub h1; mode 'list' + name → blocul articolului `name`
        //  expect = data veche din listă (alege blocul corect dacă articolul apare de mai multe ori)
        async function dateSyncReplace(path, mode, name, newDate, expect) {
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const body = new URLSearchParams();
            body.append('file', path);
            body.append('mode', mode);
            body.append('name', name || '');
            body.append('to', newDate);
            body.append('expect', expect || '');
            let d = null;
            try { d = await (await fetch(apiBase + '?action=replaceArticleDate', { method: 'POST', body })).json(); } catch (e) { return false; }
            if (!d || !d.ok || !d.changed) return false;
            await dateSyncRefreshTab(path);
            return true;
        }

        // Fișierul a fost schimbat pe disc: dacă e deschis într-un tab nemodificat, îl reîncarcă
        async function dateSyncRefreshTab(path) {
            const t = findTabByPath(path);
            if (t && !t.isDirty) {
                const html = await dateSyncLoad(path);
                if (html !== null) {
                    t.editorContent = html;
                    t.originalContent = html;
                    t.originalContentNorm = normalizeHtmlForCompare(html);
                    if (t.id === activeTabId && editor) {
                        isSyncFromDesign = true;
                        editor.setValue(html);
                        isSyncFromDesign = false;
                        if (typeof updatePreview === 'function') updatePreview();
                    }
                    updateTabPresentation(t);
                }
            }
            return true;
        }

        async function syncDateToEnglishCounterpart(roPath, roHtml) {
            const roDir = String(roPath).replace(/\\/g, '/').replace(/\/[^\/]*$/, '');
            if (!/\/ro$/i.test(roDir)) return;
            const enDir = roDir.replace(/\/ro$/i, '/en');
            const roDate = dateDupParseArticleDate(roHtml);
            if (!roDate) return;
            // Linkul en din FLAGS
            const flags = /<!--\s*FLAGS_1\s*-->([\s\S]*?)<!--\s*FLAGS\s*-->/i.exec(roHtml);
            const enLink = /href\s*=\s*["']https?:\/\/(?:www\.)?neculaifantanaru\.com\/en\/([^"'#?\/]+\.html?)["']/i
                .exec(flags ? flags[1] : roHtml);
            if (!enLink) return;
            const enName = enLink[1];
            const enPath = enDir + '/' + enName;
            const enHtml = await dateSyncLoad(enPath);
            if (enHtml === null) return; // traducerea lipsește încă
            // Siguranță: FLAGS-ul en trebuie să trimită înapoi la ACEST articol ro. Un articol nou,
            // copiat dintr-unul vechi, păstrează FLAGS-ul vechi → nu atingem traducerea altui articol.
            const roName = String(roPath).replace(/\\/g, '/').split('/').pop().toLowerCase();
            const enFlags = /<!--\s*FLAGS_1\s*-->([\s\S]*?)<!--\s*FLAGS\s*-->/i.exec(enHtml);
            const back = /href\s*=\s*["']https?:\/\/(?:www\.)?neculaifantanaru\.com\/([^"'#?\/]+\.html?)["']/i.exec(enFlags ? enFlags[1] : '');
            if (!back || back[1].toLowerCase() !== roName) return;
            const h = enHtml.search(/<h1\b[^>]*class\s*=\s*["'][^"']*\bden_articol\b/i);
            if (h === -1) return;
            const enCur = dateDupParseArticleDate(enHtml);
            const pad = enCur ? enCur.padDay : roDate.padDay;
            const newEnDate = dateDupFormat(roDate.key, 'en', pad);
            const updated = [];
            const oldEnDate = enCur ? enCur.text : '';
            if (!enCur || enCur.key !== roDate.key) {
                if (await dateSyncReplace(enPath, 'article', '', newEnDate, '')) updated.push('en/' + enName);
            }
            // Categoria en (din linkul de lângă dată) și en/index.html
            const catLink = /class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>[\s\S]*?<a\b[^>]*\bhref\s*=\s*["']([^"']+)["']/i.exec(enHtml.slice(h));
            const enCat = catLink ? catLink[1].split('#')[0].split('?')[0].split('/').pop() : '';
            if (enCat && await dateSyncReplace(enDir + '/' + enCat, 'list', enName, newEnDate, oldEnDate)) updated.push('en/' + enCat);
            if (await dateSyncReplace(enDir + '/index.html', 'list', enName, newEnDate, oldEnDate)) updated.push('en/index.html');
            if (updated.length) toast('Data a fost schimbată și în engleză: ' + updated.join(', '));
        }

        function firstParsedIndexBlockTimestamp(blocks) {
            if (!blocks || !blocks.length) return null;
            for (let i = 0; i < blocks.length; i++) {
                const ts = parseCategoryArticleLineDate(blocks[i].block);
                if (ts !== null) return ts;
            }
            return null;
        }

        function insertIndexBlockByDate(indexHtml, blockHtml, blocks, divEndGlobal) {
            const newTs = parseCategoryArticleLineDate(blockHtml);
            let insertPos;
            if (newTs === null || !blocks.length) {
                insertPos = getInsertPosAfterCategoryDiv(indexHtml, divEndGlobal);
            } else {
                let found = false;
                for (let i = 0; i < blocks.length; i++) {
                    const bts = parseCategoryArticleLineDate(blocks[i].block);
                    if (bts !== null && bts <= newTs) {
                        insertPos = blocks[i].start;
                        found = true;
                        break;
                    }
                }
                if (!found) insertPos = blocks[blocks.length - 1].end;
            }
            const collapsed = collapseWhitespaceGapBeforeInsert(indexHtml, divEndGlobal, insertPos);
            const htmlWork = collapsed.html;
            insertPos = collapsed.insertPos;
            const raw = htmlWork.slice(0, insertPos) + blockHtml + htmlWork.slice(insertPos);
            return {
                ok: true,
                html: normalizeBreakAfterTextObisnuitBeforeTable(raw)
            };
        }

        // Fără dubluri în index: același titlu+dată, același URL articol (link den_articol / linkMare), sau același HTML compresat.
        // Index-ul homepage primește automat doar articole mai noi decât ultimul/cel mai recent fragment deja listat.
        function mergeCategoryBlockIntoIndex(indexHtml, blockHtml, options = {}) {
            const bounds = locateIndexCategorySectionBounds(indexHtml);
            if (!bounds.ok) return { ok: false, msg: bounds.msg };
            const blocks = enumerateIndexCategoryBlocks(indexHtml, bounds.divEndGlobal, bounds.regionEnd);
            const sigNew = articleSignatureFromBlock(blockHtml);
            const keyNew = normalizeArticleKeyFromBlock(blockHtml);
            const compactNew = compactArticleHtmlWs(blockHtml);
            const newTs = parseCategoryArticleLineDate(blockHtml);

            const dupBlocks = blocks.filter(function (b) {
                const sigMatch = sigNew && articleSignatureFromBlock(b.block) === sigNew;
                const keyMatch = keyNew && normalizeArticleKeyFromBlock(b.block) === keyNew;
                return !!(sigMatch || keyMatch);
            });

            if (dupBlocks.length > 0) {
                if (blocks.length === 1 && dupBlocks.length === 1 &&
                    compactArticleHtmlWs(blocks[0].block) === compactNew) {
                    return {
                        ok: true,
                        html: indexHtml,
                        action: 'skip',
                        msg: 'Articolul este deja în index (singura intrare, același conținut).'
                    };
                }
                let htmlWork = indexHtml;
                dupBlocks.slice().sort(function (a, b) { return b.start - a.start; }).forEach(function (seg) {
                    htmlWork = htmlWork.slice(0, seg.start) + htmlWork.slice(seg.end);
                });
                const bounds2 = locateIndexCategorySectionBounds(htmlWork);
                if (!bounds2.ok) return bounds2;
                const blocks2 = enumerateIndexCategoryBlocks(htmlWork, bounds2.divEndGlobal, bounds2.regionEnd);
                const ins = insertIndexBlockByDate(htmlWork, blockHtml, blocks2, bounds2.divEndGlobal);
                if (!ins.ok) return ins;
                return {
                    ok: true,
                    html: ins.html,
                    action: 'move',
                    msg: 'Instanțe vechi eliminate / actualizare în index (ordonat după dată).'
                };
            }

            for (let i = 0; i < blocks.length; i++) {
                const b = blocks[i];
                if (b.block === blockHtml) {
                    return { ok: true, html: indexHtml, action: 'skip', msg: 'Articolul este deja în index (același text).' };
                }
                if (compactNew && compactArticleHtmlWs(b.block) === compactNew) {
                    return { ok: true, html: indexHtml, action: 'skip', msg: 'Articolul este deja în index (același text).' };
                }
            }

            const newestExistingTs = firstParsedIndexBlockTimestamp(blocks);
            if (!options.explicitInsert && newestExistingTs !== null && (newTs === null || newTs <= newestExistingTs)) {
                return {
                    ok: true,
                    html: indexHtml,
                    action: 'skip',
                    msg: 'Articolul nu este mai nou decât cel mai recent fragment din index.'
                };
            }

            const ins = insertIndexBlockByDate(indexHtml, blockHtml, blocks, bounds.divEndGlobal);
            if (!ins.ok) return ins;
            return {
                ok: true,
                html: ins.html,
                action: 'insert',
                msg: 'Articol adăugat în index (ordonat după dată).'
            };
        }

        function suggestCalendarMonth(value) {
            const input = String(value).trim().toLowerCase();
            const months = [...Object.keys(RO_MONTH_TO_INDEX), ...Object.keys(EN_MONTH_TO_INDEX)];
            let best = [], distance = Infinity;
            for (const month of months) {
                let row = Array.from({ length: month.length + 1 }, (_, i) => i);
                for (let i = 1; i <= input.length; i++) {
                    const next = [i];
                    for (let j = 1; j <= month.length; j++) {
                        next[j] = Math.min(next[j - 1] + 1, row[j] + 1, row[j - 1] + (input[i - 1] === month[j - 1] ? 0 : 1));
                    }
                    row = next;
                }
                const score = row[month.length];
                if (score < distance) { best = [month]; distance = score; }
                else if (score === distance) best.push(month);
            }
            return distance <= 2 && best.length === 1 ? best[0][0].toUpperCase() + best[0].slice(1) : '';
        }

        function validateIndexArticleDates(blocks) {
            const errors = [];
            for (const entry of blocks) {
                const td = entry.block.match(/class\s*=\s*["']text_dreapta["'][^>]*>([\s\S]*?)<\/td>/i);
                const plain = td ? td[1].replace(/<[^>]+>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ').trim() : '';
                const match = plain.match(/\bOn\s+(.+?)\s+(\d{1,2}),?\s+(\d{4})\b/i);
                if (!match) {
                    errors.push({ file: entry.key, text: plain || '(dată lipsă)', reason: 'Format de dată nerecunoscut. Folosește: On Lună zi, an.', suggestion: '' });
                    continue;
                }
                const month = monthIndexFromRoEnName(match[1]);
                if (month === null) {
                    const suggested = suggestCalendarMonth(match[1]);
                    errors.push({ file: entry.key, text: match[0], reason: 'Lună scrisă greșit sau necunoscută: ' + match[1] + '.', suggestion: suggested ? 'On ' + suggested + ' ' + match[2] + ', ' + match[3] : '' });
                } else if (parseCategoryArticleLineDate(entry.block) === null) {
                    errors.push({ file: entry.key, text: match[0], reason: 'Dată calendaristică invalidă. Verifică ziua, anul și numărul de zile al lunii.', suggestion: '' });
                }
            }
            return errors;
        }

        function correctMonthInDateCells(html, error) {
            const original = error.text.match(/^On\s+(.+?)\s+(\d{1,2}),?\s+(\d{4})$/i);
            const suggested = error.suggestion && error.suggestion.match(/^On\s+(.+?)\s+(\d{1,2}),?\s+(\d{4})$/i);
            if (!original || !suggested) return { ok: false, html };
            let found = false;
            const result = html.replace(/(<td\b[^>]*class\s*=\s*["']text_dreapta["'][^>]*>)([\s\S]*?)(<\/td>)/gi, (all, open, inner, close) => {
                const fixed = inner.replace(/\bOn\s+([^<>]+?)\s+(\d{1,2}),?\s+(\d{4})\b/gi, (date, month, day, year) => {
                    if (Number(day) !== Number(original[2]) || year !== original[3]) return date;
                    if (monthIndexFromRoEnName(month) === monthIndexFromRoEnName(suggested[1])) { found = true; return date; }
                    if (month.toLowerCase() !== original[1].toLowerCase()) return date;
                    found = true;
                    return date.replace(month, suggested[1]);
                });
                return open + fixed + close;
            });
            return { ok: found, html: result };
        }

        async function correctLinkedIndexMonths(indexPath, html, errors, messages) {
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const read = async path => {
                const data = await (await fetch(apiBase + '?action=load&file=' + encodeURIComponent(path), { cache: 'no-store' })).json();
                if (!data.ok) throw new Error(data.error || 'Nu pot citi ' + path);
                return data.content;
            };
            const write = async (path, before, after) => {
                if (before === after) { messages.push(path + ' — luna este deja corectă.'); return; }
                const tab = findTabByPath(path);
                if (tab && (tab.isDirty || (tab.id === activeTabId && editor && normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(tab.originalContent)))) throw new Error('Modificări nesalvate în ' + path);
                if (await read(path) !== before) throw new Error('Fișier modificat între timp: ' + path);
                const saved = await (await fetch(apiBase + '?action=save', { method: 'POST', body: new URLSearchParams({ file: path, content: after }) })).json();
                if (!saved.ok) throw new Error(saved.error || 'Salvare eșuată: ' + path);
                messages.push(path + ' — luna a fost corectată.');
                if (tab && !tab.isDirty && (tab.id !== activeTabId || !editor || normalizeHtmlForSyncCompare(editor.getValue()) === normalizeHtmlForSyncCompare(before))) {
                    tab.editorContent = tab.originalContent = after;
                    tab.originalContentNorm = normalizeHtmlForCompare(after);
                    if (tab.id === activeTabId && editor) {
                        isSyncFromDesign = true;
                        try { editor.setValue(after); } finally { isSyncFromDesign = false; }
                        updatePreview();
                    }
                    updateTabPresentation(tab);
                }
            };
            for (const error of errors) {
                if (!error.suggestion) continue;
                try {
                    const bounds = locateIndexCategorySectionBounds(html);
                    const block = enumerateIndexCategoryBlocks(html, bounds.divEndGlobal, bounds.regionEnd).find(b => b.key === error.file);
                    if (!block) throw new Error('Intrarea nu mai există în index.');
                    const category = block.block.match(/<a\b(?=[^>]*\brel\s*=\s*["'][^"']*category)[^>]*href\s*=\s*["']([^"']+)["']/i);
                    if (!category) throw new Error('Nu am identificat categoria.');
                    const filename = value => {
                        const name = new URL(value, 'https://local.invalid/').pathname.split('/').pop();
                        if (!/^[\w.-]+\.html?$/i.test(name)) throw new Error('Nume de fișier nerecunoscut.');
                        return name;
                    };
                    const articlePath = categoryPathBesideArticle(indexPath, filename(error.file));
                    const categoryPath = categoryPathBesideArticle(indexPath, filename(category[1]));
                    const article = await read(articlePath), categoryHtml = await read(categoryPath);
                    const articleFix = correctMonthInDateCells(article, error);
                    const region = findCategoryListRegion(categoryHtml);
                    if (!region.ok) throw new Error(region.msg);
                    const matches = enumerateIndexCategoryBlocks(categoryHtml, region.divEndGlobal, region.regionEnd).filter(b => b.key === error.file);
                    if (!matches.length) throw new Error('Articolul nu a fost găsit în categorie.');
                    let categoryFixed = categoryHtml;
                    for (const entry of matches.slice().reverse()) {
                        const fixed = correctMonthInDateCells(entry.block, error);
                        if (!fixed.ok) throw new Error('Data din categorie diferă; verifică manual.');
                        categoryFixed = categoryFixed.slice(0, entry.start) + fixed.html + categoryFixed.slice(entry.end);
                    }
                    const indexFix = correctMonthInDateCells(block.block, error);
                    if (!articleFix.ok || !indexFix.ok) throw new Error('Data articolului diferă; verifică manual.');
                    await write(articlePath, article, articleFix.html);
                    await write(categoryPath, categoryHtml, categoryFixed);
                    html = html.slice(0, block.start) + indexFix.html + html.slice(block.end);
                    messages.push(error.file + ': „' + error.text + '” → „' + error.suggestion + '”.');
                } catch (errorInfo) {
                    messages.push(error.file + ' — corectare incompletă: ' + errorInfo.message + ' Data din index rămâne pentru reverificare.');
                }
            }
            return html;
        }

        function reorderIndexArticles(html) {
            const bounds = locateIndexCategorySectionBounds(html);
            if (!bounds.ok) return { ok: false, msg: bounds.msg };
            const blocks = enumerateIndexCategoryBlocks(html, bounds.divEndGlobal, bounds.regionEnd);
            const dated = blocks.map((b, i) => ({ ...b, position: i, date: parseCategoryArticleLineDate(b.block) })).filter(b => b.date !== null);
            const sorted = dated.slice().sort((a, b) => b.date - a.date || a.position - b.position);
            const changes = [];
            let result = html;
            // Replace only article blocks; preserve all surrounding HTML and undated entries.
            for (let i = dated.length - 1; i >= 0; i--) {
                const old = dated[i], replacement = sorted[i];
                if (old.position === replacement.position) continue;
                result = result.slice(0, old.start) + replacement.block + result.slice(old.end);
                changes.unshift({ file: replacement.key, from: replacement.position + 1, to: old.position + 1, date: replacement.date });
            }
            return { ok: true, html: result, changes, dateErrors: validateIndexArticleDates(blocks) };
        }

        let indexOrderTimer = null;
        let indexOrderRunning = false;
        function scheduleIndexOrderCheck() {
            clearTimeout(indexOrderTimer);
            indexOrderTimer = setTimeout(checkIndexArticleOrder, 500);
            scheduleRecentArticlesCheck();
        }

        // ── Verificare in fundal: cele mai noi 2 articole (dupa data din pagina, ro/ si en/)
        //    exista in pagina lor de categorie si in index.html? Daca nu, apare un anunt.
        //    Ruleaza la pornire, la deschiderea/inchiderea unei pagini, dupa Save, ADD-CAT si To-INDEX.
        var RECENT_ARTICLES_TO_CHECK = 2;
        var recentArticlesTimer = null, recentArticlesRunning = false, recentArticlesPending = false;
        function scheduleRecentArticlesCheck(delay) {
            clearTimeout(recentArticlesTimer);
            recentArticlesTimer = setTimeout(checkRecentArticlesInLists, delay == null ? 1500 : delay);
        }
        async function recentArticlesLoad(path) {
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const d = await (await fetch(apiBase + '?action=load&file=' + encodeURIComponent(path), { cache: 'no-store' })).json();
            if (!d.ok) throw new Error(d.error || ('Nu pot citi ' + path));
            return d.content || '';
        }
        function recentArticlesListKeys(html) {
            const r = findCategoryListRegion(html);
            if (!r.ok) return null;
            return enumerateIndexCategoryBlocks(html, r.divEndGlobal, r.regionEnd).map(function (b) { return b.key; });
        }
        function recentArticlesShortPath(p) {
            return String(p || '').replace(/\\/g, '/').split('/').slice(-2).join('/');
        }
        async function checkRecentArticlesInLists() {
            if (recentArticlesRunning) { recentArticlesPending = true; return; }
            recentArticlesRunning = true;
            const problems = [];
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            try {
                for (const idxPath of [TO_INDEX_RO_HTML_PATH, TO_INDEX_EN_HTML_PATH]) {
                    const dir = idxPath.replace(/\/[^\/]*$/, '');
                    let res = null;
                    try {
                        res = await (await fetch(apiBase + '?action=recentArticles&n=' + RECENT_ARTICLES_TO_CHECK +
                            '&dir=' + encodeURIComponent(dir), { cache: 'no-store' })).json();
                    } catch (e) { continue; }
                    if (!res || !res.ok || !res.articles) continue;
                    let idxKeys = null;
                    try { idxKeys = recentArticlesListKeys(await recentArticlesLoad(idxPath)); } catch (e) { }
                    for (const art of res.articles) {
                        const item = { file: art.file, date: art.date, missing: [], note: '' };
                        try {
                            const built = buildCategoryBlockFromArticleHtml(await recentArticlesLoad(art.file));
                            if (!built || !built.ok) {
                                const tmp = document.createElement('textarea');
                                tmp.innerHTML = (built && built.msg) || '';
                                item.note = 'Nu pot construi fragmentul pentru liste: ' + tmp.value;
                            } else {
                                const key = normalizeArticleKeyFromBlock(built.block);
                                const catPath = categoryPathBesideArticle(art.file, built.categoryFile);
                                let catKeys = null;
                                try { catKeys = recentArticlesListKeys(await recentArticlesLoad(catPath)); }
                                catch (e) { item.note = 'Nu pot citi pagina de categorie ' + recentArticlesShortPath(catPath) + '.'; }
                                if (catKeys && catKeys.indexOf(key) === -1) item.missing.push(recentArticlesShortPath(catPath));
                                if (idxKeys && idxKeys.indexOf(key) === -1) item.missing.push(recentArticlesShortPath(idxPath));
                            }
                        } catch (e) {
                            item.note = e.message;
                        }
                        if (item.missing.length || item.note) problems.push(item);
                    }
                }
            } finally {
                recentArticlesRunning = false;
            }
            showRecentArticlesNotice(problems);
            if (recentArticlesPending) { recentArticlesPending = false; scheduleRecentArticlesCheck(500); }
        }
        function showRecentArticlesNotice(problems) {
            let box = document.getElementById('recentArticlesNotice');
            if (!problems.length) { if (box) box.remove(); return; }
            if (!box) {
                box = document.createElement('div');
                box.id = 'recentArticlesNotice';
                box.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99990;max-width:520px;' +
                    'background:#1f2937;border:2px solid #f59e0b;border-radius:10px;padding:14px 16px;color:#eee;' +
                    'font-size:15px;line-height:1.45;box-shadow:0 10px 30px rgba(0,0,0,.55)';
                document.body.appendChild(box);
            }
            box.replaceChildren();
            const head = document.createElement('div');
            head.style.cssText = 'display:flex;align-items:center;gap:10px;margin-bottom:8px';
            head.innerHTML = '<i class="fas fa-exclamation-triangle" style="color:#f59e0b"></i>' +
                '<b style="flex:1">Articole noi nepreluate în liste</b>';
            const close = document.createElement('button');
            close.className = 'btn btn-ghost';
            close.textContent = '×';
            close.title = 'Ascunde (reapare la următoarea verificare)';
            close.style.cssText = 'padding:2px 10px;font-size:18px';
            close.onclick = function () { box.remove(); };
            head.appendChild(close);
            box.appendChild(head);
            problems.forEach(function (p) {
                const row = document.createElement('div');
                row.style.cssText = 'display:flex;gap:10px;align-items:flex-start;padding:6px 0;border-top:1px solid #374151';
                const text = document.createElement('div');
                text.style.flex = '1';
                const title = document.createElement('div');
                title.innerHTML = '<b></b> <span style="color:#9ca3af"></span>';
                title.querySelector('b').textContent = recentArticlesShortPath(p.file);
                title.querySelector('span').textContent = '(' + String(p.date || '').replace(/^On\s+/i, '') + ')';
                text.appendChild(title);
                const det = document.createElement('div');
                det.style.color = '#fbbf24';
                det.textContent = p.missing.length ? 'Lipsește din: ' + p.missing.join(', ') : p.note;
                text.appendChild(det);
                if (p.missing.length && p.note) {
                    const n2 = document.createElement('div');
                    n2.style.color = '#9ca3af';
                    n2.textContent = p.note;
                    text.appendChild(n2);
                }
                row.appendChild(text);
                const open = document.createElement('button');
                open.className = 'btn btn-primary';
                open.textContent = 'Deschide';
                open.style.cssText = 'padding:4px 12px;font-size:14px;white-space:nowrap';
                open.onclick = function () { openFile(p.file); };
                row.appendChild(open);
                box.appendChild(row);
            });
            const hint = document.createElement('div');
            hint.style.cssText = 'color:#9ca3af;font-size:13px;margin-top:6px';
            hint.textContent = 'Deschide articolul și apasă ADD-CAT / To-INDEX (sau salvează-l).';
            box.appendChild(hint);
        }
        document.addEventListener('click', function (e) {
            const b = e.target && e.target.closest ? e.target.closest('#btnAddCat, #btnToIndex') : null;
            if (b) scheduleRecentArticlesCheck(3000);
        }, true);

        // ── Date duplicate între articole (ro/ și en/) ──
        //  • la 10 s după ce schimbi data articolului deschis → verifică dacă mai e în alt articol
        //  • la pornirea aplicației → verificare completă în fundal
        //  Fereastra arată grupurile de dubluri colorate, fișierele ca linkuri (se deschid în editor)
        //  și 2 date libere, cât mai apropiate.
        const DATE_DUP_DELAY_MS = 10000;
        const DATE_DUP_MONTHS = {
            ro: ['Ianuarie', 'Februarie', 'Martie', 'Aprilie', 'Mai', 'Iunie', 'Iulie', 'August', 'Septembrie', 'Octombrie', 'Noiembrie', 'Decembrie'],
            en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        };
        const DATE_DUP_COLORS = ['#f59e0b', '#38bdf8', '#a78bfa', '#34d399', '#f472b6', '#fb7185', '#facc15', '#2dd4bf', '#c084fc', '#4ade80'];
        let dateDupTimer = null;

        function dateDupDirs() {
            return [TO_INDEX_RO_HTML_PATH, TO_INDEX_EN_HTML_PATH].map(p => p.replace(/\/[^\/]*$/, ''));
        }
        function dateDupNormPath(p) { return String(p || '').replace(/\\/g, '/').toLowerCase(); }
        function dateDupLangOfDir(dir) { return /\/en$/i.test(String(dir).replace(/\\/g, '/')) ? 'en' : 'ro'; }
        function dateDupDirOfFile(path) {
            const fileDir = dateDupNormPath(path).replace(/\/[^\/]*$/, '');
            return dateDupDirs().find(d => dateDupNormPath(d) === fileDir) || null;
        }
        // Zi calendaristică ca număr comparabil (aaaallzz)
        function dateDupDayKey(y, m, d) { return y * 10000 + m * 100 + d; }
        function dateDupKeyFromTs(ts) {
            const dt = new Date(ts * 1000);
            return dateDupDayKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate());
        }
        function dateDupKeyToDate(k) { return new Date(Math.floor(k / 10000), Math.floor(k / 100) % 100 - 1, k % 100); }
        function dateDupDateToKey(dt) { return dateDupDayKey(dt.getFullYear(), dt.getMonth() + 1, dt.getDate()); }

        // Data „On Luna zi, an” de sub <h1 class="den_articol"> din HTML-ul dat
        function dateDupParseArticleDate(html) {
            html = String(html || '');
            const h = html.search(/<h1\b[^>]*class\s*=\s*["'][^"']*\bden_articol\b/i);
            if (h === -1) return null;
            const td = /class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i.exec(html.slice(h));
            if (!td) return null;
            const plain = td[1].replace(/<[^>]*>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/\s+/g, ' ');
            const m = /\bOn\s+([^\s\d,]+)\s+(\d{1,2}),?\s+(\d{4})\b/i.exec(plain);
            if (!m) return null;
            const mon = m[1].toLowerCase();
            let mi = DATE_DUP_MONTHS.ro.findIndex(x => x.toLowerCase() === mon);
            if (mi === -1) mi = DATE_DUP_MONTHS.en.findIndex(x => x.toLowerCase() === mon);
            if (mi === -1) return null;
            const y = +m[3], d = +m[2];
            const test = new Date(y, mi, d);
            if (test.getMonth() !== mi || test.getDate() !== d) return null;
            return { key: dateDupDayKey(y, mi + 1, d), text: m[0], padDay: /^0\d$/.test(m[2]) };
        }

        function dateDupFormat(key, lang, padDay) {
            const dt = dateDupKeyToDate(key);
            const day = padDay ? String(dt.getDate()).padStart(2, '0') : String(dt.getDate());
            return 'On ' + DATE_DUP_MONTHS[lang][dt.getMonth()] + ' ' + day + ', ' + dt.getFullYear();
        }

        // 2 date libere, cât mai apropiate: prima înainte și prima după (dacă „după” ar fi
        // în viitor, a doua alternativă e tot înainte).
        function dateDupAlternatives(key, usedKeys, todayKey) {
            const out = [];
            const before = [];
            let dt = dateDupKeyToDate(key);
            for (let i = 0; i < 4000 && before.length < 2; i++) {
                dt.setDate(dt.getDate() - 1);
                const k = dateDupDateToKey(dt);
                if (!usedKeys.has(k)) before.push(k);
            }
            let after = null;
            dt = dateDupKeyToDate(key);
            for (let i = 0; i < 4000; i++) {
                dt.setDate(dt.getDate() + 1);
                const k = dateDupDateToKey(dt);
                if (todayKey && k > todayKey) break;
                if (!usedKeys.has(k)) { after = k; break; }
            }
            if (before[0]) out.push(before[0]);
            if (after) out.push(after);
            else if (before[1]) out.push(before[1]);
            return out.sort((a, b) => b - a);
        }

        async function dateDupFetchDir(dir) {
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const res = await (await fetch(apiBase + '?action=articleDates&dir=' + encodeURIComponent(dir), { cache: 'no-store' })).json();
            if (!res || !res.ok) throw new Error((res && res.error) || 'Nu pot citi datele articolelor');
            const todayKey = res.today ? dateDupKeyFromTs(res.today) : dateDupDateToKey(new Date());
            const items = (res.articles || []).map(a => ({
                file: a.file, key: dateDupKeyFromTs(a.ts), date: a.date, cat: a.cat || '', catName: a.catName || '',
                listed: a.listed !== false, created: a.created || 0, mtime: a.mtime || 0
            }));
            const padDay = items.some(a => /\s0\d,/.test(a.date));
            return { dir, lang: dateDupLangOfDir(dir), todayKey, items, padDay };
        }

        // Verificare completă: toate grupurile de articole cu aceeași dată, pe fiecare limbă
        let dateDupFullBusy = false;
        let dateDupLastAutomaticSignature = null;

        // Jurnalul verificărilor (verificari-log.txt, lângă editor): același fișier ca verificarea RO–EN
        function appendCheckLog(lines) {
            if (!lines || !lines.length) return;
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            fetch(apiBase + '?action=appendCheckLog', { method: 'POST', body: new URLSearchParams({ lines: JSON.stringify(lines) }) }).catch(() => { });
        }
        // Grupurile de date duplicate: GĂSIT când apar prima dată, REZOLVAT când dispar
        function logDateDupGroups(sections) {
            let before = {};
            try { before = JSON.parse(localStorage.getItem('dateDupLoggedGroups') || '{}'); } catch (_) { before = {}; }
            const now = {};
            for (const sec of sections) for (const g of sec.groups) {
                const key = sec.lang + ':' + g.key;
                now[key] = '[Dată duplicată] ' + sec.lang + ': ' + String(g.files[0].date || '').replace(/^On\s+/i, '') + ' — '
                    + g.files.map(f => f.file.replace(/\\/g, '/').split('/').pop()).join(', ');
            }
            const lines = [];
            for (const k in now) if (!(k in before)) lines.push('GĂSIT      ' + now[k]);
            for (const k in before) if (!(k in now)) lines.push('REZOLVAT   ' + before[k]);
            try { localStorage.setItem('dateDupLoggedGroups', JSON.stringify(now)); } catch (_) { }
            appendCheckLog(lines);
        }

        // Articolele en care au deja o propunere RO–EN cu dată (la OK primesc data din RO):
        // nu le mai arăt și ca dată duplicată — fereastra RO–EN are prioritate.
        function datesFixedByCategoryPairs() {
            const set = new Set();
            for (const p of (window.lastCategoryPairResult && window.lastCategoryPairResult.proposals) || []) {
                if (p.date_correct && p.lang === 'en') set.add(String(p.article).toLowerCase());
            }
            return set;
        }

        async function runFullDateDuplicateCheck(manual) {
            if (postponeValidation('all-dates', () => runFullDateDuplicateCheck(manual))) return;
            if (dateDupFullBusy) return;
            if (!manual && !tabs.some(t => t.filePath && t.type !== 'browser')) {
                // Prioritate: întâi verificarea RO–EN (poate repara singură data). Dacă rulează sau dacă
                // site-ul s-a schimbat de la ultima ei rulare, o las pe ea întâi; ea pornește apoi și verificarea asta.
                if (typeof syncCategoryPairs === 'function' && typeof getSiteStamp === 'function') {
                    if (window.categoryPairSyncRunning) return;
                    const stamp = await getSiteStamp();
                    if (stamp && stamp !== window.lastCategoryPairStamp) { syncCategoryPairs().catch(console.error); return; }
                }
            }
            dateDupFullBusy = true;
            try {
            const sections = [];
            const fixedByPairs = datesFixedByCategoryPairs();
            for (const dir of dateDupDirs()) {
                let data;
                try { data = await dateDupFetchDir(dir); } catch (e) { continue; }
                const byKey = new Map();
                data.items.filter(a => a.listed || a.cat)
                    .filter(a => !(data.lang === 'en' && fixedByPairs.has(a.file.replace(/\\/g, '/').split('/').pop().toLowerCase())))
                    .forEach(a => {
                    if (!byKey.has(a.key)) byKey.set(a.key, []);
                    byKey.get(a.key).push(a);
                });
                const used = new Set(byKey.keys());
                const groups = [];
                byKey.forEach((files, key) => {
                    if (files.length < 2) return;
                    // Articolul creat cel mai recent (de obicei copia nouă) e cel care primește data nouă;
                    // apare primul în grup și marcat distinct
                    files.sort((a, b) => (b.created - a.created) || (b.mtime - a.mtime) || a.file.localeCompare(b.file));
                    groups.push({
                        key, files, target: files[0].file,
                        alts: dateDupAlternatives(key, used, data.todayKey).map(k => dateDupFormat(k, data.lang, data.padDay))
                    });
                });
                groups.sort((a, b) => b.key - a.key);
                if (groups.length) sections.push({ lang: data.lang, dir, groups });
            }
            // Automat (la pornire): lista mare apare doar dacă nu e deschis niciun HTML.
            // Cu un fișier deschis, apare doar fereastra mică, după ce îi schimbi data.
            if (postponeValidation('all-dates', () => runFullDateDuplicateCheck(manual))) return;
            logDateDupGroups(sections);
            const signature = JSON.stringify(sections);
            if (!manual && signature === dateDupLastAutomaticSignature) return;
            dateDupLastAutomaticSignature = signature;
            if (sections.length) showDateDuplicatesDialog(sections, null);
            else if (manual) { closeDateDuplicatesDialog('all'); toast('Nicio dată duplicată în articolele din ro/ și en/.'); }
            else closeDateDuplicatesDialog('all');
            } finally { dateDupFullBusy = false; }
        }

        // Verificarea articolului deschis (data din editor, chiar nesalvată)
        // onlyPath: verifică doar dacă acel fișier e încă cel deschis (s-ar putea să fi schimbat tab-ul)
        // silent: fără mesaj când data e unică (verificarea de la deschiderea fișierului)
        // force: verifică și un articol încă neadăugat în nicio categorie (folosit după Save)
        async function runCurrentDateDuplicateCheck(onlyPath, silent, force) {
            if (postponeValidation('current-date', () => runCurrentDateDuplicateCheck(null, true, force))) return;
            if (!editor || !currentFile) return;
            if (onlyPath && dateDupNormPath(onlyPath) !== dateDupNormPath(currentFile)) return;
            const dir = dateDupDirOfFile(currentFile);
            if (!dir) return;
            const cur = dateDupParseArticleDate(editor.getValue());
            if (!cur) return;
            let data;
            try { data = await dateDupFetchDir(dir); } catch (e) { return; }
            const me = dateDupNormPath(currentFile);
            // Articol nou (încă în nicio categorie, de obicei copiat dintr-unul vechi): la deschidere
            // nu verificăm — data o schimbi oricum la final; verificarea vine după ce schimbi data.
            const meListed = data.items.some(a => a.listed && dateDupNormPath(a.file) === me);
            // New copies must be checked even before they are listed in a category.
            // celelalte articole (doar cele din categorii); fișierul deschis e verificat oricum
            const others = data.items.filter(a => (a.listed || a.cat) && dateDupNormPath(a.file) !== me);
            const same = others.filter(a => a.key === cur.key);
            if (!same.length) {
                closeDateDuplicatesDialog('file');
                if (!silent) toast('Data „' + cur.text.replace(/^On\s+/i, '') + '” nu mai apare în alt articol.');
                return;
            }
            // O copie noua pastreaza slugul paginii-sursa in canonical, FLAGS si JSON-LD.
            // Dupa confirmarea datei duplicate, aliniem toate aparitiile la numele fisierului.
            const identityFix = repairCopiedArticleIdentity(editor.getValue(), currentFile);
            if (identityFix.changed) {
                editor.setValue(identityFix.html);
                const active = tabs.find(t => t.id === activeTabId);
                if (active) active._identityRepairNotice = identityFix.message;
            }
            const used = new Set(others.map(a => a.key));
            const mine = data.items.find(a => dateDupNormPath(a.file) === me);
            const meEntry = { file: currentFile, key: cur.key, date: cur.text, cat: mine ? mine.cat : '', catName: mine ? mine.catName : '', current: true };
            showDateDuplicatesDialog([{
                lang: data.lang, dir,
                groups: [{
                    key: cur.key, files: [meEntry].concat(same), target: currentFile,
                    alts: dateDupAlternatives(cur.key, used, data.todayKey).map(k => dateDupFormat(k, data.lang, cur.padDay || data.padDay))
                }]
            }], currentFile);
        }

        // Chemat la fiecare schimbare în cod: dacă s-a schimbat data articolului, verifică după 10 s
        function repairCopiedArticleIdentity(source, filePath) {
            const site = /\/Principal\/(ro|en)\/([^/]+\.html?)$/i.exec(String(filePath || '').replace(/\\/g, '/'));
            if (!site) return { html: source, changed: false, message: '' };
            const fileName = site[2];
            let html = String(source || '');
            const link = html.match(/<link\b[^>]*\brel\s*=\s*["']canonical["'][^>]*>/i);
            const hrefMatch = link && link[0].match(/\bhref\s*=\s*["']([^"']+)["']/i);
            let oldName = '';
            if (hrefMatch) {
                try { oldName = decodeURIComponent(new URL(hrefMatch[1], 'https://neculaifantanaru.com').pathname.split('/').pop() || ''); }
                catch (_) { oldName = hrefMatch[1].split(/[?#]/)[0].split('/').pop() || ''; }
            }
            let replacedSlug = false;
            if (oldName && oldName.toLowerCase() !== fileName.toLowerCase()) {
                const escaped = oldName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const re = new RegExp(escaped, 'gi');
                replacedSlug = re.test(html);
                re.lastIndex = 0;
                html = html.replace(re, fileName);
            }
            const beforeExtensionFix = html;
            html = html.replace(/\.html(?:\.html)+/gi, '.html');
            const extensionFixed = html !== beforeExtensionFix;
            const changed = html !== source;
            const items = [];
            if (replacedSlug) items.push('slugul vechi a fost inlocuit cu ' + fileName + ' peste tot (canonical si FLAGS incluse)');
            if (extensionFixed) items.push('extensiile .html.html au fost corectate');
            return { html, changed, message: changed ? 'Identitate sincronizata automat: ' + items.join('; ') + '. Salveaza cu Ctrl+S.' : '' };
        }

        function noteEditorChangeForDateCheck() {
            if (!editor || !activeTabId || !currentFile || !dateDupDirOfFile(currentFile)) return;
            const tab = tabs.find(t => t.id === activeTabId);
            if (!tab) return;
            const cur = dateDupParseArticleDate(editor.getValue());
            const k = cur ? cur.key : null;
            const path = currentFile;
            if (tab._dateDupKey === undefined || tab._dateDupFile !== currentFile) {
                // Fișier abia deschis: verifică data lui după 10 s (fereastră doar dacă e dublură)
                tab._dateDupKey = k;
                tab._dateDupFile = currentFile;
                if (k !== null) {
                    clearTimeout(dateDupTimer);
                    dateDupTimer = setTimeout(() => runCurrentDateDuplicateCheck(path, true), DATE_DUP_DELAY_MS);
                }
                return;
            }
            if (k === tab._dateDupKey) return;
            tab._dateDupKey = k;
            if (k === null) return;
            clearTimeout(dateDupTimer);
            dateDupTimer = setTimeout(() => runCurrentDateDuplicateCheck(path, false), DATE_DUP_DELAY_MS);
        }

        // ── Link-Duble: același articol apare de 2+ ori în paginile de categorie (ro/ sau en/) ──
        async function runLinkDuplicateCheck() {
            toast('Caut linkurile duble în paginile de categorie…');
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            const sections = [];
            for (const dir of dateDupDirs()) {
                let res = null;
                try {
                    res = await (await fetch(apiBase + '?action=categoryLinks&dir=' + encodeURIComponent(dir), { cache: 'no-store' })).json();
                } catch (e) { continue; }
                if (!res || !res.ok) continue;
                const byName = new Map();
                (res.categories || []).forEach(cat => {
                    (cat.links || []).forEach(l => {
                        if (!byName.has(l[0])) byName.set(l[0], []);
                        byName.get(l[0]).push({ cat, text: l[1] });
                    });
                });
                const groups = [];
                byName.forEach((hits, name) => {
                    if (hits.length < 2) return;
                    // aceeași categorie poate apărea de mai multe ori → un rând per categorie, cu numărul
                    const perCat = new Map();
                    hits.forEach(h => {
                        const k = h.cat.file;
                        perCat.set(k, (perCat.get(k) || { cat: h.cat, n: 0 }));
                        perCat.get(k).n++;
                    });
                    const files = [{ file: dir + '/' + name, info: '(articolul)' }];
                    perCat.forEach(v => {
                        const catTitle = String(v.cat.title || '').replace(/\s*\|.*$/, '');
                        files.push({
                            file: v.cat.file,
                            info: (catTitle ? 'categoria: ' + catTitle : 'pagină de categorie') + (v.n > 1 ? ' — de ' + v.n + ' ori aici' : '')
                        });
                    });
                    groups.push({
                        key: name,
                        title: (hits[0].text || name) + ' — apare de ' + hits.length + ' ori în categorii',
                        files, alts: []
                    });
                });
                groups.sort((a, b) => a.title.localeCompare(b.title, 'ro'));
                if (groups.length) sections.push({ lang: dateDupLangOfDir(dir), dir, groups });
            }
            if (!sections.length) {
                const old = document.getElementById('linkDuplicatesDialog');
                if (old) old.remove();
                toast('Niciun link dublu în paginile de categorie din ro/ și en/.');
                return;
            }
            showDateDuplicatesDialog(sections, null, {
                id: 'linkDuplicatesDialog',
                title: n => 'Linkuri duble în categorii (' + n + ' ' + (n === 1 ? 'articol' : 'articole') + ')',
                recheck: runLinkDuplicateCheck
            });
        }

        // Butonul Date-Duble (ecranul de pornire): lista mare cu datele duplicate
        function openDateDuplicatesFromStart() {
            toast('Caut datele duplicate…');
            runFullDateDuplicateCheck(true);
        }

        // Butonul „Aplică”: înlocuiește data de sub <h1 class="den_articol"> în articolul deschis
        // (în cod; Design-ul se actualizează singur). Întoarce true dacă a schimbat-o.
        function applyDateToOpenArticle(path, newDate) {
            if (!editor || !currentFile || dateDupNormPath(path) !== dateDupNormPath(currentFile)) {
                toast('Deschide întâi articolul ' + String(path).split('/').pop() + '.');
                return false;
            }
            const v = editor.getValue();
            const h = v.search(/<h1\b[^>]*class\s*=\s*["'][^"']*\bden_articol\b/i);
            if (h === -1) { toast('Nu găsesc titlul articolului (h1 den_articol).'); return false; }
            const td = /class\s*=\s*["'][^"']*\btext_dreapta\b[^"']*["'][^>]*>([\s\S]*?)<\/td>/i.exec(v.slice(h));
            const d = td ? /\bOn\s+[^\s\d,<]+\s+\d{1,2},?\s+\d{4}/i.exec(td[1]) : null;
            if (!d) { toast('Nu găsesc data articolului.'); return false; }
            const from = h + td.index + td[0].indexOf(td[1]) + d.index;
            editor.operation(() => {
                editor.replaceRange(newDate, editor.posFromIndex(from), editor.posFromIndex(from + d[0].length), '+applyDate');
            });
            return true;
        }

        // Data scrisă de mână: „On <Lună> <zi>, <an>”, cu luna în limba folderului.
        // Întoarce textul normalizat („On Aprilie 21, 2026”) sau un mesaj de eroare.
        function parseManualArticleDate(value, lang) {
            const months = DATE_DUP_MONTHS[lang] || DATE_DUP_MONTHS.ro;
            const example = lang === 'en' ? 'On April 21, 2026' : 'On Aprilie 21, 2026';
            const m = /^On\s+([^\s\d,]+)\s+(\d{1,2}),\s*(\d{4})$/i.exec(String(value || '').trim().replace(/\s+/g, ' '));
            if (!m) return { error: 'Scrie data exact în forma „' + example + '”.' };
            const mi = months.findIndex(x => x.toLowerCase() === m[1].toLowerCase());
            if (mi === -1) return { error: 'Luna „' + m[1] + '” nu e o lună ' + (lang === 'en' ? 'în engleză' : 'în română') + ' (ex. „' + example + '”).' };
            const day = +m[2], year = +m[3];
            const d = new Date(year, mi, day);
            if (d.getFullYear() !== year || d.getMonth() !== mi || d.getDate() !== day) return { error: 'Data nu există în calendar: ' + day + ' ' + months[mi] + ' ' + year + '.' };
            if (d > new Date()) return { error: 'Data e în viitor.' };
            return { text: 'On ' + months[mi] + ' ' + String(day).padStart(2, '0') + ', ' + year };
        }

        function manualDateRow(lang, g, currentPath, box, card) {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:8px';
            const label = document.createElement('span');
            label.style.cssText = 'color:#9ca3af;font-size:14px';
            label.textContent = 'Sau scrie tu data:';
            const input = document.createElement('input');
            input.type = 'text';
            input.placeholder = lang === 'en' ? 'On April 21, 2026' : 'On Aprilie 21, 2026';
            input.style.cssText = 'flex:0 1 230px;min-width:180px;background:#15161d;border:1px solid #444;border-radius:6px;padding:5px 10px;color:#eee;font-size:14px';
            const add = document.createElement('button');
            add.type = 'button';
            add.textContent = 'Adaugă';
            add.style.cssText = 'padding:5px 16px;border:1px solid #b91c1c;border-radius:6px;background:#dc2626;color:#fff;font:600 14px system-ui;cursor:pointer';
            const msg = document.createElement('div');
            msg.style.cssText = 'flex-basis:100%;font-size:13px;color:#fca5a5;display:none';
            const run = async () => {
                const parsed = parseManualArticleDate(input.value, lang);
                if (parsed.error) { msg.textContent = parsed.error; msg.style.display = 'block'; input.focus(); return; }
                msg.style.display = 'none';
                // Data ta înlocuiește propunerile: le scot din card
                card.querySelectorAll('button').forEach(b => { if (/^On\s/.test(b.textContent)) b.remove(); });
                const proposals = Array.from(card.querySelectorAll('div')).find(d => /^Date libere/.test(d.textContent || ''));
                if (proposals) proposals.remove();
                add.disabled = true; input.disabled = true; add.style.opacity = '.6';
                let ok;
                if (currentPath) {
                    ok = applyDateToOpenArticle(currentPath, parsed.text);
                    if (ok) {
                        box.remove();
                        toast('Data a fost schimbată în ' + parsed.text.replace(/^On\s+/i, '') + '. Verific din nou peste 10 s; salvează (Ctrl+S) ca să intre și în categorie.');
                    }
                } else {
                    const tf = g.files.find(x => dateDupNormPath(x.file) === dateDupNormPath(g.target));
                    ok = await applyDateToFileOnDisk(g.target, tf ? tf.date : '', tf ? tf.cat : '', parsed.text);
                    if (ok) runFullDateDuplicateCheck(true); // din nou verificarea normală: poate data ta se repetă
                }
                if (!ok) { add.disabled = false; input.disabled = false; add.style.opacity = ''; }
            };
            add.onclick = run;
            input.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Enter') { e.preventDefault(); run(); } });
            row.append(label, input, add, msg);
            return row;
        }

        // „Aplică” din lista mare: schimbă data direct în fișier (doar textul datei, cu backup pe server),
        // apoi în blocul lui din categorie și din index, iar pentru ro și în traducerea en.
        async function applyDateToFileOnDisk(path, oldDate, catLink, newDate) {
            const name = String(path).replace(/\\/g, '/').split('/').pop();
            const dir = String(path).replace(/\\/g, '/').replace(/\/[^\/]*$/, '');
            const open = findTabByPath(path);
            if (open && open.isDirty) {
                toast(name + ' e deschis și are modificări nesalvate. Salvează-l sau închide-l întâi.');
                return false;
            }
            if (!await dateSyncReplace(path, 'article', '', newDate, '')) {
                toast('Nu am putut schimba data în ' + name + '.');
                return false;
            }
            const done = [name];
            const cat = String(catLink || '').split('#')[0].split('?')[0].split('/').pop();
            appendCheckLog(['REPARAT    [Dată duplicată] ' + name + ': ' + String(oldDate || '?').replace(/^On\s+/i, '') + ' → '
                + newDate.replace(/^On\s+/i, '') + ' (din fereastra Date duplicate)']);
            if (cat && await dateSyncReplace(dir + '/' + cat, 'list', name, newDate, oldDate)) done.push(cat);
            if (await dateSyncReplace(dir + '/index.html', 'list', name, newDate, oldDate)) done.push('index.html');
            if (/\/ro$/i.test(dir)) {
                const html = await dateSyncLoad(path);
                if (html !== null) { try { await syncDateToEnglishCounterpart(path, html); } catch (e) { console.error(e); } }
            }
            toast('Data ' + newDate.replace(/^On\s+/i, '') + ' a fost scrisă în: ' + done.join(', ') + '.');
            return true;
        }

        // Toate dublurile ca text simplu (butonul Copy), ex. pentru un .txt
        function dateDuplicatesAsText(sections) {
            const lines = [];
            sections.forEach(sec => {
                lines.push((sec.lang === 'en' ? 'ENGLEZĂ' : 'ROMÂNĂ') + ' — ' + sec.dir.replace(/\\/g, '/') + '/');
                lines.push('');
                sec.groups.forEach(g => {
                    lines.push(g.title || (String(g.files[0].date || '').replace(/^On\s+/i, '') + ' — ' + g.files.length + ' articole'));
                    g.files.forEach(f => {
                        const extra = f.info !== undefined ? f.info : (f.catName ? 'categoria: ' + f.catName : '');
                        const mark = g.target && dateDupNormPath(g.target) === dateDupNormPath(f.file) ? '   <- aici se schimba data' : '';
                        lines.push('   ' + f.file.replace(/\\/g, '/') + (extra ? '   (' + extra + ')' : '') + mark);
                    });
                    if (g.alts.length) lines.push('   Date libere apropiate: ' + g.alts.join('  |  '));
                    lines.push('');
                });
            });
            return lines.join('\r\n');
        }

        // which: 'all' = lista mare, 'file' = fereastra fișierului deschis, nimic = ambele
        function closeDateDuplicatesDialog(which) {
            if (which !== 'file') { const a = document.getElementById('dateDuplicatesDialog'); if (a) a.remove(); }
            if (which !== 'all') { const f = document.getElementById('dateDupFileDialog'); if (f) f.remove(); }
        }

        // opts (opțional): { id, title, recheck } — folosit și de fereastra Link-Duble
        function showDateDuplicatesDialog(sections, currentPath, opts) {
            opts = opts || {};
            if (postponeValidation('date-dialog-' + (opts.id || currentPath || 'all'), () => {
                if (opts.id === 'linkDuplicatesDialog') return runLinkDuplicateCheck();
                dateDupLastAutomaticSignature = '';
                return currentPath ? runCurrentDateDuplicateCheck(currentPath, true, true) : runFullDateDuplicateCheck(false);
            })) return;
            const boxId = opts.id || (currentPath ? 'dateDupFileDialog' : 'dateDuplicatesDialog');
            let box = document.getElementById(boxId);
            const keepPos = box ? { left: box.style.left, top: box.style.top } : null;
            if (box) box.remove();
            box = document.createElement('div');
            box.id = boxId;
            box.style.cssText = 'position:fixed;left:50%;top:80px;transform:translateX(-50%);z-index:99991;' +
                'width:min(760px,calc(100vw - 32px));max-height:calc(100vh - 120px);display:flex;flex-direction:column;' +
                'background:#1f2937;border:2px solid #ef4444;border-radius:10px;color:#eee;font-size:15px;line-height:1.45;' +
                'box-shadow:0 12px 36px rgba(0,0,0,.6)';
            if (currentPath) {
                // Fereastra fișierului deschis: mai mică, în dreapta, ca să nu acopere lista mare
                box.style.left = 'auto';
                box.style.right = '24px';
                box.style.top = '120px';
                box.style.transform = 'none';
                box.style.width = 'min(620px,calc(100vw - 32px))';
            }
            if (keepPos && keepPos.left) {
                box.style.left = keepPos.left; box.style.top = keepPos.top; box.style.transform = 'none';
                box.style.right = 'auto';
            }
            const head = document.createElement('div');
            head.style.cssText = 'display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid #374151;cursor:move;user-select:none';
            const total = sections.reduce((n, s) => n + s.groups.length, 0);
            head.innerHTML = '<i class="fas fa-calendar-times" style="color:#ef4444"></i><b style="flex:1"></b>';
            head.querySelector('b').textContent = opts.title ? opts.title(total) : currentPath
                ? 'Data acestui articol mai apare în alt articol'
                : 'Date duplicate în articole (' + total + ' ' + (total === 1 ? 'grup' : 'grupuri') + ')';
            const recheck = document.createElement('button');
            recheck.className = 'btn btn-ghost';
            recheck.textContent = 'Reverifică';
            recheck.title = 'Verifică din nou toate articolele din ro/ și en/';
            recheck.style.cssText = 'padding:3px 10px;font-size:14px';
            if (currentPath) recheck.title = 'Verifică din nou data acestui articol';
            recheck.onclick = () => {
                recheck.textContent = 'Verific…';
                if (opts.recheck) {
                    opts.recheck();
                } else if (currentPath) {
                    closeDateDuplicatesDialog('file');
                    runCurrentDateDuplicateCheck();
                } else {
                    runFullDateDuplicateCheck(true);
                }
            };
            const close = document.createElement('button');
            close.className = 'btn btn-ghost';
            close.textContent = '×';
            close.title = 'Închide';
            close.style.cssText = 'padding:2px 10px;font-size:18px';
            close.onclick = () => box.remove();
            head.appendChild(recheck);
            head.appendChild(close);
            box.appendChild(head);
            if (currentPath) {
                const active = tabs.find(t => t.id === activeTabId);
                if (active && active._identityRepairNotice) {
                    const notice = document.createElement('div');
                    notice.style.cssText = 'padding:8px 16px;color:#86efac;background:rgba(34,197,94,.08);border-bottom:1px solid #374151;font-size:13px';
                    notice.textContent = active._identityRepairNotice;
                    box.appendChild(notice);
                }
            }

            // Fereastra mare: Find propriu (caută doar în dublurile de aici) + Copy (tot ca text)
            let findInput = null, findInfo = null;
            if (!currentPath) {
                const bar = document.createElement('div');
                bar.style.cssText = 'display:flex;align-items:center;gap:8px;padding:8px 16px;border-bottom:1px solid #374151';
                findInput = document.createElement('input');
                findInput.type = 'text';
                findInput.placeholder = 'Find în dubluri: fișier, dată, categorie…';
                findInput.style.cssText = 'flex:1;background:#15161d;border:1px solid #444;border-radius:4px;padding:6px 10px;color:#eee;font-size:14px';
                findInput.addEventListener('keydown', e => {
                    e.stopPropagation(); // nu declanșa scurtăturile editorului
                    if (e.key === 'Escape') { findInput.value = ''; applyFind(); }
                });
                findInfo = document.createElement('span');
                findInfo.style.cssText = 'color:#9ca3af;font-size:13px;white-space:nowrap';
                const copyBtn = document.createElement('button');
                copyBtn.className = 'btn btn-ghost';
                copyBtn.textContent = 'Copy';
                copyBtn.title = 'Copiază toate dublurile ca text (pentru un .txt)';
                copyBtn.style.cssText = 'padding:4px 12px;font-size:14px';
                copyBtn.onclick = () => {
                    const txt = dateDuplicatesAsText(sections);
                    const done = () => toast('Am copiat ' + total + ' grupuri.');
                    try {
                        navigator.clipboard.writeText(txt).then(done, () => { fallbackCopy(txt); done(); });
                    } catch (e) { fallbackCopy(txt); done(); }
                };
                bar.appendChild(findInput);
                bar.appendChild(findInfo);
                bar.appendChild(copyBtn);
                box.appendChild(bar);
            }
            function fallbackCopy(txt) {
                const ta = document.createElement('textarea');
                ta.value = txt;
                ta.style.cssText = 'position:fixed;left:-9999px';
                document.body.appendChild(ta);
                ta.select();
                try { document.execCommand('copy'); } catch (e) { }
                ta.remove();
            }

            const body = document.createElement('div');
            body.style.cssText = 'overflow:auto;padding:8px 16px 14px';
            let colorIdx = 0;
            sections.forEach(sec => {
                if (!currentPath) {
                    const h = document.createElement('div');
                    h.className = 'dd-sec';
                    h.style.cssText = 'margin:10px 0 4px;color:#9ca3af;font-size:13px;text-transform:uppercase;letter-spacing:.05em';
                    h.textContent = (sec.lang === 'en' ? 'Engleză' : 'Română') + ' — ' + sec.dir.replace(/\\/g, '/').split('/').slice(-2).join('/') + '/';
                    body.appendChild(h);
                }
                sec.groups.forEach(g => {
                    const color = DATE_DUP_COLORS[colorIdx++ % DATE_DUP_COLORS.length];
                    const card = document.createElement('div');
                    card.className = 'dd-card';
                    card.style.cssText = 'border-left:4px solid ' + color + ';background:rgba(255,255,255,.03);border-radius:6px;padding:8px 12px;margin:8px 0';
                    const title = document.createElement('div');
                    title.style.cssText = 'font-weight:700;color:' + color;
                    title.textContent = g.title || (String(g.files[0].date || '').replace(/^On\s+/i, '') + ' — ' + g.files.length + ' articole');
                    card.appendChild(title);
                    g.files.forEach(f => {
                        const row = document.createElement('div');
                        row.style.cssText = 'display:flex;gap:8px;align-items:baseline;padding:2px 0';
                        const link = document.createElement('a');
                        link.href = '#';
                        link.textContent = f.file.replace(/\\/g, '/').split('/').pop();
                        link.title = 'Deschide în editor: ' + f.file;
                        link.style.cssText = 'color:' + color + ';font-weight:600;text-decoration:underline;cursor:pointer';
                        link.onclick = e => {
                            e.preventDefault();
                            window._dateDupOpeningFromList = true; // lista mare rămâne deschisă
                            Promise.resolve(openFile(f.file)).finally(() => { window._dateDupOpeningFromList = false; });
                        };
                        row.appendChild(link);
                        const info = document.createElement('span');
                        info.style.cssText = 'color:#9ca3af;font-size:13px';
                        info.textContent = f.info !== undefined ? f.info
                            : (f.current ? '(articolul deschis acum) ' : '') + (f.catName ? 'categoria: ' + f.catName : '');
                        row.appendChild(info);
                        // Articolul la care se schimbă data (cel mai nou / cel deschis): marcat distinct
                        if (g.target && dateDupNormPath(g.target) === dateDupNormPath(f.file)) {
                            row.style.cssText += ';background:rgba(250,204,21,.12);border:1px dashed #facc15;border-radius:6px;padding:3px 8px;margin:2px -8px';
                            const badge = document.createElement('span');
                            badge.textContent = '✎ aici se schimbă data';
                            badge.title = currentPath ? 'Articolul deschis acum' : 'Fișierul creat cel mai recent din acest grup';
                            badge.style.cssText = 'margin-left:auto;background:#facc15;color:#111;border-radius:10px;padding:0 8px;font-size:12px;font-weight:700;white-space:nowrap';
                            row.appendChild(badge);
                        }
                        card.appendChild(row);
                    });
                    if (g.alts.length) {
                        const alt = document.createElement('div');
                        alt.style.cssText = 'margin-top:4px;font-size:14px';
                        const targetName = g.target ? g.target.replace(/\\/g, '/').split('/').pop() : '';
                        alt.innerHTML = '<span style="color:#9ca3af"></span>';
                        alt.firstChild.textContent = targetName ? 'Date libere pentru ' + targetName + ': ' : 'Date libere apropiate: ';
                        g.alts.forEach((a, i) => {
                            // Data propusă e chiar butonul: click = data se scrie în articolul marcat
                            const chip = document.createElement('button');
                            chip.type = 'button';
                            chip.textContent = a;
                            chip.style.cssText = 'display:inline-block;margin:2px 8px 2px 0;padding:2px 10px;border-radius:10px;border:1px solid #10b981;' +
                                'background:#065f46;color:#d1fae5;cursor:pointer;font-weight:600;font-size:14px';
                            chip.onmouseenter = () => { chip.style.background = '#047857'; };
                            chip.onmouseleave = () => { chip.style.background = '#065f46'; };
                            if (currentPath) {
                                // Fereastra articolului deschis: data se scrie în articol (în editor)
                                chip.title = 'Click = pune data ' + a + ' în articolul deschis';
                                chip.onclick = () => {
                                    if (applyDateToOpenArticle(currentPath, a)) {
                                        box.remove();
                                        toast('Data a fost schimbată în ' + a.replace(/^On\s+/i, '') + '. Salvează (Ctrl+S) ca să intre și în categorie' +
                                            (/\/ro\//i.test(String(currentPath).replace(/\\/g, '/')) ? ', index și en.' : ' și index.'));
                                    }
                                };
                            } else if (g.target && !opts.id) {
                                // Lista mare: data se scrie direct în fișierul marcat (articol, categorie,
                                // index și traducerea en), fără să-l deschizi
                                chip.title = 'Click = pune data ' + a + ' în ' + targetName;
                                chip.onclick = async () => {
                                    const tf = g.files.find(x => dateDupNormPath(x.file) === dateDupNormPath(g.target));
                                    chip.disabled = true;
                                    chip.style.opacity = '.6';
                                    const ok = await applyDateToFileOnDisk(g.target, tf ? tf.date : '', tf ? tf.cat : '', a);
                                    if (ok) runFullDateDuplicateCheck(true);
                                    else { chip.disabled = false; chip.style.opacity = ''; }
                                };
                            } else {
                                chip.title = 'Click = copiază data';
                                chip.onclick = () => {
                                    try { navigator.clipboard.writeText(a); toast('Copiat: ' + a); } catch (e) { }
                                };
                            }
                            alt.appendChild(chip);
                        });
                        card.appendChild(alt);
                    }
                    // O dată aleasă de tine, în locul celor propuse: „On Aprilie 21, 2026” (ro) / „On April 21, 2026” (en)
                    if (g.target && !opts.id) card.appendChild(manualDateRow(sec.lang, g, currentPath, box, card));
                    body.appendChild(card);
                });
            });
            box.appendChild(body);
            document.body.appendChild(box);

            // Textele în care caută Find-ul ferestrei (titlu grup, fișiere, categorii, date libere)
            const searchable = Array.from(body.querySelectorAll('.dd-card > div:first-child, .dd-card a, .dd-card span, .dd-card button'))
                .filter(el => !el.children.length);
            searchable.forEach(el => { el.dataset.ddText = el.textContent; });
            function applyFind() {
                if (!findInput) return;
                const q = findInput.value.trim();
                let re = null;
                if (q) { try { re = new RegExp(buildDiacInsensitivePattern(q), 'gi'); } catch (e) { re = null; } }
                const esc = s => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
                searchable.forEach(el => {
                    const t = el.dataset.ddText;
                    el.innerHTML = re
                        ? esc(t).replace(new RegExp(buildDiacInsensitivePattern(esc(q)), 'gi'), m => '<mark style="background:#facc15;color:#111;border-radius:2px">' + m + '</mark>')
                        : esc(t);
                });
                let shown = 0, hits = 0;
                const cards = Array.from(body.querySelectorAll('.dd-card'));
                cards.forEach(c => {
                    const n = c.querySelectorAll('mark').length;
                    const ok = !re || n > 0;
                    c.style.display = ok ? '' : 'none';
                    if (ok) shown++;
                    hits += n;
                });
                // Titlul de limbă (ro / en) dispare dacă nu are niciun grup vizibil
                body.querySelectorAll('.dd-sec').forEach(sec => {
                    let el = sec.nextElementSibling, any = false;
                    while (el && !el.classList.contains('dd-sec')) {
                        if (el.style.display !== 'none') { any = true; break; }
                        el = el.nextElementSibling;
                    }
                    sec.style.display = any ? '' : 'none';
                });
                findInfo.textContent = re ? (hits + ' potriviri în ' + shown + ' grupuri') : (cards.length + ' grupuri');
                const first = body.querySelector('mark');
                if (first) first.scrollIntoView({ block: 'nearest' });
            }
            if (findInput) {
                let ft = null;
                findInput.addEventListener('input', () => { clearTimeout(ft); ft = setTimeout(applyFind, 150); });
                applyFind();
            }

            // Fereastra se poate muta trăgând de bara de sus
            head.addEventListener('mousedown', e => {
                if (e.button !== 0 || e.target.closest('button')) return;
                e.preventDefault();
                const r = box.getBoundingClientRect();
                box.style.transform = 'none';
                box.style.right = 'auto';
                box.style.left = r.left + 'px';
                box.style.top = r.top + 'px';
                const sx = e.clientX, sy = e.clientY, sl = r.left, st = r.top;
                document.querySelectorAll('iframe').forEach(f => f.style.pointerEvents = 'none');
                const move = ev => {
                    box.style.left = Math.max(0, Math.min(window.innerWidth - 80, sl + ev.clientX - sx)) + 'px';
                    box.style.top = Math.max(0, Math.min(window.innerHeight - 40, st + ev.clientY - sy)) + 'px';
                };
                const up = () => {
                    window.removeEventListener('mousemove', move);
                    window.removeEventListener('mouseup', up);
                    document.querySelectorAll('iframe').forEach(f => f.style.pointerEvents = '');
                };
                window.addEventListener('mousemove', move);
                window.addEventListener('mouseup', up);
            });
        }

        // La pornire: verificare completă imediat (scanarea vine din cache, durează ~1 s)
        setTimeout(() => { runFullDateDuplicateCheck(false).catch(() => { }); }, 0);

        // Discover files copied into RO/EN while the start screen stays open.
        setInterval(() => {
            if (!document.hidden && !tabs.some(t => t.filePath && t.type !== 'browser')) {
                runFullDateDuplicateCheck(false).catch(console.error);
            }
        }, 30000);
        window.addEventListener('focus', () => {
            if (!tabs.some(t => t.filePath && t.type !== 'browser')) runFullDateDuplicateCheck(false).catch(console.error);
        });

        function showIndexOrderReport(reports) {
            if (postponeValidation('index-order', () => showIndexOrderReport(reports))) return;
            let dialog = document.getElementById('indexOrderReport');
            if (!dialog) {
                dialog = document.createElement('dialog');
                dialog.id = 'indexOrderReport';
                dialog.style.cssText = 'max-width:620px;width:calc(100% - 48px);max-height:80vh;overflow:auto;padding:28px;border:1px solid #526080;border-radius:16px;background:#242735;color:#f1f3f9;box-shadow:0 20px 70px #0008;font:16px/1.6 system-ui';
                dialog.setAttribute('aria-labelledby', 'indexOrderReportTitle');
                dialog.innerHTML = '<h2 id="indexOrderReportTitle" style="margin-top:0">Verificarea articolelor din index</h2><div class="report"></div><form method="dialog"><button autofocus style="padding:10px 24px;background:#397ce8;color:white;border:0;border-radius:8px;font:inherit;cursor:pointer">Am înțeles</button></form>';
                document.body.appendChild(dialog);
            }
            const container = dialog.querySelector('.report');
            if (!dialog.open) container.replaceChildren();
            for (const report of reports) {
                const title = document.createElement('p');
                title.textContent = report.path + (report.changes.length ? ' — ordinea datelor a fost corectată și salvată:' : ' — date de verificat:');
                container.appendChild(title);
                for (const text of (report.corrections || [])) {
                    const detail = document.createElement('p');
                    detail.textContent = text;
                    container.appendChild(detail);
                }
                const list = document.createElement('ul');
                for (const change of report.changes) {
                    const item = document.createElement('li');
                    const date = new Intl.DateTimeFormat('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(change.date));
                    item.textContent = change.file + ' (' + date + '): poziția ' + change.from + ' → ' + change.to + '.';
                    list.appendChild(item);
                }
                container.appendChild(list);
                if (report.dateErrors && report.dateErrors.length) {
                    const note = document.createElement('p');
                    note.textContent = 'Datele de mai jos necesită corectare manuală. Articolele respective nu au fost mutate automat:';
                    container.appendChild(note);
                    const errors = document.createElement('ul');
                    for (const error of report.dateErrors) {
                        const item = document.createElement('li');
                        item.textContent = error.file + ' — „' + error.text + '”. ' + error.reason + (error.suggestion ? ' Sugestie: „' + error.suggestion + '”.' : '');
                        errors.appendChild(item);
                    }
                    container.appendChild(errors);
                }
            }
            if (!dialog.open) dialog.showModal();
        }

        async function checkIndexArticleOrder() {
            if (indexOrderRunning) { scheduleIndexOrderCheck(); return; }
            indexOrderRunning = true;
            const reports = [];
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            try {
                for (const path of [TO_INDEX_RO_HTML_PATH, TO_INDEX_EN_HTML_PATH]) {
                    const hasEdits = () => {
                        const tab = findTabByPath(path);
                        return tab && (tab.isDirty || (tab.id === activeTabId && editor && normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(tab.originalContent)));
                    };
                    if (hasEdits()) { toast('Verificare index amânată: salvează modificările din ' + path); continue; }
                    const url = apiBase + '?action=load&file=' + encodeURIComponent(path);
                    const data = await (await fetch(url, { cache: 'no-store' })).json();
                    if (!data.ok) { toast('Verificare index: ' + (data.error || path)); continue; }
                    let result = reorderIndexArticles(data.content);
                    if (!result.ok) { toast('Verificare index: ' + result.msg); continue; }
                    const report = { path, changes: [], dateErrors: result.dateErrors, corrections: [] };
                    reports.push(report);
                    const corrected = await correctLinkedIndexMonths(path, data.content, result.dateErrors, report.corrections);
                    result = reorderIndexArticles(corrected);
                    if (!result.changes.length && corrected === data.content) continue;
                    // Re-read before saving so external edits made during the check are not overwritten.
                    const latest = await (await fetch(url, { cache: 'no-store' })).json();
                    if (!latest.ok || latest.content !== data.content || hasEdits()) { scheduleIndexOrderCheck(); continue; }
                    const body = new URLSearchParams({ file: path, content: result.html });
                    const saved = await (await fetch(apiBase + '?action=save', { method: 'POST', body })).json();
                    if (!saved.ok) { toast('Indexul nu a putut fi reordonat: ' + (saved.error || path)); continue; }
                    report.changes = result.changes;
                    report.dateErrors = result.dateErrors;
                    if (corrected !== data.content) report.corrections.push(path + ' — luna corectată și indexul salvat.');
                    const tab = findTabByPath(path);
                    if (tab && !hasEdits()) {
                        tab.editorContent = tab.originalContent = result.html;
                        tab.originalContentNorm = normalizeHtmlForCompare(result.html);
                        if (tab.id === activeTabId && editor) {
                            isSyncFromDesign = true;
                            try { editor.setValue(result.html); } finally { isSyncFromDesign = false; }
                            updatePreview();
                        }
                        updateTabPresentation(tab);
                    }
                }
            } catch (error) {
                console.error(error);
                toast('Verificarea indexului nu a reușit: ' + error.message);
            } finally {
                indexOrderRunning = false;
                const visibleReports = reports.filter(r => r.changes.length || r.dateErrors.length || r.corrections.length);
                if (visibleReports.length) showIndexOrderReport(visibleReports);
            }
        }
        window.addEventListener('load', scheduleIndexOrderCheck);

        function articleIdentityIssues(source, path) {
            // Doar fișierele aflate direct în Principal/ro sau Principal/en (fără subfoldere, fără
            // copii de backup din alte foldere): acolo canonicalul trebuie să fie chiar fișierul.
            const site = /\/Principal\/(ro|en)\/([^\/]+\.html?)$/i.exec(String(path || '').replace(/\\/g, '/'));
            if (!site) return [];
            const file = site[2];
            const doc = new DOMParser().parseFromString(source, 'text/html');
            const language = site[1].toLowerCase();
            const expected = 'https://neculaifantanaru.com/' + (language === 'en' ? 'en/' : '') + file;
            const issues = [];
            const inspect = (label, value) => {
                try {
                    const url = new URL(value, expected);
                    const target = decodeURIComponent(url.pathname.split('/').pop());
                    if (url.pathname.toLowerCase() !== new URL(expected).pathname.toLowerCase()) issues.push({ label, value: url.href, target, expected });
                } catch (_) { issues.push({ label, value, target: '', expected }); }
            };
            for (const canonical of doc.querySelectorAll('link[rel~="canonical"]')) inspect('Canonical', canonical.getAttribute('href') || '');
            return issues;
        }

        function canonicalLocalPath(filePath, canonicalUrl) {
            const url = new URL(canonicalUrl);
            if (!/^(www\.)?neculaifantanaru\.com$/i.test(url.hostname)) return null;
            const match = url.pathname.match(/^\/(en\/)?([^/]+\.html?)$/i);
            if (!match) return null;
            const file = decodeURIComponent(match[2]);
            if (!/^[\w.-]+\.html?$/i.test(file)) return null;
            const path = String(filePath).replace(/\\/g, '/');
            const root = path.match(/^(.*)\/(?:ro|en)\/[^/]+$/i);
            if (!root) return null;
            return root[1] + '/' + (match[1] ? 'en' : 'ro') + '/' + file;
        }

        let identityDialogQueue = Promise.resolve();
        async function checkArticleIdentity(tab, closing = false) {
            if (postponeValidation('canonical-' + (tab && tab.id), () => checkArticleIdentity(tab))) return true;
            if (!tab || tab.type === 'browser' || !tab.filePath) return true;
            const source = tab.id === activeTabId && editor ? editor.getValue() : tab.editorContent;
            const issues = articleIdentityIssues(source || '', tab.filePath);
            if (!issues.length) return true;
            const task = async () => {
                if (!tabs.includes(tab)) return true;
                const details = [];
                for (const issue of issues) {
                    let duplicate = '';
                    if (/^[\w.-]+\.html?$/i.test(issue.target)) {
                        try {
                            const path = canonicalLocalPath(tab.filePath, issue.value);
                            if (!path) throw new Error('Canonical fără corespondent local');
                            const data = await (await fetch('?action=load&file=' + encodeURIComponent(path), { cache: 'no-store', signal: AbortSignal.timeout(5000) })).json();
                            if (data.ok) {
                                const other = new DOMParser().parseFromString(data.content, 'text/html');
                                const canonical = other.querySelector('link[rel~="canonical"]');
                                if (canonical && new URL(canonical.getAttribute('href'), issue.value).href === issue.value) duplicate = ' Mai există un fișier cu același canonical: ' + path + '.';
                            }
                        } catch (_) { /* The filename mismatch remains useful even when the other file cannot be read. */ }
                    }
                    details.push({ label: issue.label, value: issue.value, expected: issue.expected, duplicate: duplicate.trim() });
                }
                const current = tab.id === activeTabId && editor ? editor.getValue() : tab.editorContent;
                if (!tabs.includes(tab)) return true;
                const currentIssues = articleIdentityIssues(current || '', tab.filePath);
                if (!currentIssues.length) return true;
                if (JSON.stringify(currentIssues) !== JSON.stringify(issues)) {
                    if (!closing) setTimeout(() => checkArticleIdentity(tab), 0);
                    return false;
                }
                if (postponeValidation('canonical-' + tab.id, () => checkArticleIdentity(tab))) return true;
                return new Promise(resolve => {
                    if (!document.getElementById('canonicalCheckStyle')) {
                        const st = document.createElement('style');
                        st.id = 'canonicalCheckStyle';
                        st.textContent =
                            '#canonicalCheck{margin:auto;inset:0;max-height:calc(100vh - 48px);overflow-y:auto;max-width:720px;width:calc(100% - 48px);box-sizing:border-box;padding:0;border:1px solid #46516d;border-radius:16px;background:#1f2330;color:#f1f3f9;box-shadow:0 24px 80px #000a;font:15px/1.55 system-ui;overflow:hidden}' +
                            '#canonicalCheck::backdrop{background:#0c0f17b8}' +
                            '#canonicalCheck .cc-head{display:flex;gap:14px;align-items:center;padding:20px 26px;background:linear-gradient(90deg,#3b2a12,#2a2414);border-bottom:1px solid #6b4f1d}' +
                            '#canonicalCheck .cc-icon{flex:none;width:40px;height:40px;border-radius:50%;background:#f59e0b;color:#1f2330;display:flex;align-items:center;justify-content:center;font:700 22px system-ui}' +
                            '#canonicalCheck h2{margin:0;font-size:21px}' +
                            '#canonicalCheck .cc-sub{margin:2px 0 0;color:#fcd9a0;font-size:14px}' +
                            '#canonicalCheck .cc-body{padding:20px 26px 8px}' +
                            '#canonicalCheck .cc-file{margin:0 0 18px;color:#9aa3b8;font-size:13px;overflow-wrap:anywhere}' +
                            '#canonicalCheck .cc-file b{display:block;color:#f1f3f9;font-size:17px;margin-bottom:2px}' +
                            '#canonicalCheck .cc-row{border-radius:10px;padding:10px 14px;overflow-wrap:anywhere}' +
                            '#canonicalCheck .cc-row small{display:block;font:700 12px system-ui;letter-spacing:.06em;text-transform:uppercase;margin-bottom:3px}' +
                            '#canonicalCheck .cc-row code{font:14px/1.45 ui-monospace,Consolas,monospace}' +
                            '#canonicalCheck .cc-bad{background:#3a1d22;border:1px solid #b4414f}' +
                            '#canonicalCheck .cc-bad small,#canonicalCheck .cc-bad code{color:#ff9aa5}' +
                            '#canonicalCheck .cc-good{background:#16332a;border:1px solid #2f9e74}' +
                            '#canonicalCheck .cc-good small,#canonicalCheck .cc-good code{color:#7ee2b8}' +
                            '#canonicalCheck .cc-gap{height:14px}' +
                            '#canonicalCheck .cc-dup{margin:12px 0 0;padding:8px 12px;border-radius:8px;background:#3a3214;border:1px solid #a58a2b;color:#fde68a;font-size:14px;overflow-wrap:anywhere}' +
                            '#canonicalCheck .cc-issue+.cc-issue{margin-top:22px;padding-top:18px;border-top:1px dashed #46516d}' +
                            '#canonicalCheck .cc-foot{display:flex;justify-content:flex-end;gap:12px;padding:16px 26px 22px}' +
                            '#canonicalCheck button{padding:10px 20px;border-radius:8px;font:600 15px system-ui;cursor:pointer}' +
                            '#canonicalCheck .cc-stay{border:0;background:#397ce8;color:#fff}' +
                            '#canonicalCheck .cc-stay:hover{background:#4b8bf0}' +
                            '#canonicalCheck .cc-leave{border:1px solid #5a6480;background:transparent;color:#d6dbe8}' +
                            '#canonicalCheck .cc-leave:hover{background:#2c3244}' +
                            '#canonicalCheck button:focus-visible{outline:3px solid #b8d2ff;outline-offset:2px}';
                        document.head.appendChild(st);
                    }
                    const el = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; };
                    const dialog = el('dialog');
                    dialog.id = 'canonicalCheck';
                    const head = el('div', 'cc-head');
                    head.appendChild(el('div', 'cc-icon', '!'));
                    const titles = el('div');
                    titles.appendChild(el('h2', null, 'Verifică linkul canonical'));
                    titles.appendChild(el('p', 'cc-sub', 'Linkul indică alt articol — probabil a rămas din fișierul copiat.'));
                    head.appendChild(titles);
                    dialog.appendChild(head);
                    const body = el('div', 'cc-body');
                    const fileBox = el('p', 'cc-file');
                    const path = String(tab.filePath).replace(/\\/g, '/');
                    fileBox.appendChild(el('b', null, path.split('/').pop()));
                    fileBox.appendChild(document.createTextNode(path));
                    body.appendChild(fileBox);
                    for (const d of details) {
                        const issue = el('div', 'cc-issue');
                        const bad = el('div', 'cc-row cc-bad');
                        bad.appendChild(el('small', null, '✗ ' + d.label + ' din fișier (greșit)'));
                        bad.appendChild(el('code', null, d.value));
                        issue.appendChild(bad);
                        issue.appendChild(el('div', 'cc-gap'));
                        const good = el('div', 'cc-row cc-good');
                        good.appendChild(el('small', null, '✓ Link corect pentru acest fișier'));
                        good.appendChild(el('code', null, d.expected));
                        issue.appendChild(good);
                        if (d.duplicate) issue.appendChild(el('p', 'cc-dup', '⚠ ' + d.duplicate));
                        body.appendChild(issue);
                    }
                    dialog.appendChild(body);
                    const foot = el('div', 'cc-foot');
                    const finish = value => { dialog.close(); dialog.remove(); resolve(value); };
                    if (closing) {
                        const leave = el('button', 'cc-leave', 'Închid oricum');
                        leave.onclick = () => finish(true);
                        foot.appendChild(leave);
                    }
                    const stay = el('button', 'cc-stay', 'Revin la editare');
                    stay.autofocus = true;
                    stay.onclick = () => finish(false);
                    foot.appendChild(stay);
                    dialog.appendChild(foot);
                    dialog.addEventListener('cancel', event => { event.preventDefault(); finish(false); });
                    document.body.appendChild(dialog); dialog.showModal();
                });
            };
            const result = identityDialogQueue.then(task, task);
            identityDialogQueue = result.catch(() => true);
            return result;
        }

        function newerIndexEntry(indexHtml, blockHtml) {
            const bounds = locateIndexCategorySectionBounds(indexHtml);
            if (!bounds.ok) return null;
            const timestamp = parseCategoryArticleLineDate(blockHtml);
            if (timestamp === null) return null;
            const key = normalizeArticleKeyFromBlock(blockHtml);
            let newest = null;
            for (const entry of enumerateIndexCategoryBlocks(indexHtml, bounds.divEndGlobal, bounds.regionEnd)) {
                const date = parseCategoryArticleLineDate(entry.block);
                if (entry.key !== key && date !== null && date > timestamp && (!newest || date > newest.date)) {
                    newest = { date, file: entry.key };
                }
            }
            return newest;
        }

        function showIndexDateNotice(entry) {
            let dialog = document.getElementById('indexDateNotice');
            if (!dialog) {
                const style = document.createElement('style');
                style.textContent = '#indexDateNotice{max-width:520px;width:calc(100% - 64px);box-sizing:border-box;padding:28px;border:1px solid #46516d;border-radius:16px;background:#242735;color:#f1f3f9;box-shadow:0 20px 70px #0008;font:16px/1.6 system-ui}#indexDateNotice::backdrop{background:#10131caa}#indexDateNotice h3{margin:0 0 16px;font-size:21px}#indexDateNotice p{margin:12px 0;overflow-wrap:anywhere}#indexDateNotice strong{color:#9fc4ff}#indexDateNotice button{display:block;margin:24px 0 0 auto;padding:10px 24px;border:0;border-radius:8px;background:#397ce8;color:white;font:600 15px system-ui;cursor:pointer}#indexDateNotice button:focus-visible{outline:3px solid #b8d2ff;outline-offset:3px}';
                document.head.appendChild(style);
                dialog = document.createElement('dialog');
                dialog.id = 'indexDateNotice';
                dialog.setAttribute('aria-labelledby', 'indexDateNoticeTitle');
                dialog.innerHTML = '<h3 id="indexDateNoticeTitle">Articol adăugat în index</h3><p class="date-message"></p><p>Articolul curent este în index, sub intrarea mai recentă, în ordinea datelor. Poți corecta ulterior data articolului precedent.</p><form method="dialog"><button autofocus>Am înțeles</button></form>';
                document.body.appendChild(dialog);
            }
            const date = document.createElement('strong');
            date.textContent = new Intl.DateTimeFormat('ro-RO', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(entry.date));
            const file = document.createElement('strong');
            file.textContent = entry.file;
            dialog.querySelector('.date-message').replaceChildren(document.createTextNode('Există deja o intrare mai recentă datată '), date, document.createTextNode(', la articolul '), file, document.createTextNode('.'));
            if (!dialog.open) dialog.showModal();
        }

        async function pushFirstCategoryBlockToIndex() {
            if (!editor) {
                toast('Editor indisponibil.');
                return;
            }
            if (!isCurrentFileHtml()) {
                toast('To-INDEX este doar pentru fișiere HTML.');
                return;
            }
            const indexPath = getToIndexPathForFile(currentFile);
            if (currentFile && normPathLoose(currentFile) === normPathLoose(indexPath)) {
                toast('Ești în index.html; deschide articolul (.html) sau o pagină categorie.');
                return;
            }
            const src = editor.getValue();
            const hasCategMarker = src.indexOf(MARKER_CATEGORIE_START) !== -1;
            const listCount = countCategoryListBlocks(src);
            let block;
            if (hasCategMarker || listCount >= 1) {
                const blockEx = extractFirstCategoryArticleFromSource(src);
                if (!blockEx) {
                    toast('Nu am găsit niciun articol în lista din pagina categorie / index.');
                    return;
                }
                block = blockEx;
            } else {
                const built = buildCategoryBlockFromArticleHtml(src);
                if (!built.ok) {
                    toast('To-INDEX: ' + built.msg);
                    return;
                }
                block = built.block;
            }
            const apiBase = window.location.pathname.replace(/[#?].*$/, '');
            toast('To-INDEX: citesc index…');
            try {
                const loadUrl = apiBase + '?action=load&file=' + encodeURIComponent(indexPath);
                const res = await fetch(loadUrl);
                const data = await res.json();
                if (!data.ok) {
                    toast('Nu pot citi index: ' + (data.error || 'eroare'));
                    return;
                }
                const idx = data.content || '';
                const newerEntry = newerIndexEntry(idx, block);
                const merged = mergeCategoryBlockIntoIndex(idx, block, { explicitInsert: true });
                if (!merged.ok) {
                    toast(merged.msg);
                    return;
                }
                if (merged.action === 'skip') {
                    toast('To-INDEX: ' + merged.msg);
                    return;
                }
                const body = new URLSearchParams();
                body.append('file', indexPath);
                body.append('content', merged.html);
                const resSave = await fetch(apiBase + '?action=save', { method: 'POST', body });
                const saveData = await resSave.json();
                if (!saveData.ok) {
                    toast('Nu pot salva index: ' + (saveData.error || 'eroare'));
                    return;
                }
                toast('To-INDEX: ' + merged.msg);
                if (newerEntry) showIndexDateNotice(newerEntry);
            } catch (e) {
                console.error(e);
                toast('To-INDEX: ' + (e.message || String(e)));
            }
        }

        function getCurrentSelectionText() {
            // 1) Dacă suntem în Design / Split, încercăm din iframe
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if ((viewMode === 'design' || viewMode === 'split') && doc && doc.body) {
                const win = iframe.contentWindow;
                const sel = win && win.getSelection && win.getSelection();
                if (sel && sel.toString().trim()) {
                    return sel.toString();
                }
            }
            // 2) Altfel, din CodeMirror
            if (editor) {
                const sel = editor.getSelection();
                if (sel && sel.trim()) return sel;
            }
            return '';
        }

        function loadSelectionIntoTranslate() {
            const src = document.getElementById('trSourceText');
            const status = document.getElementById('trStatus');
            if (!src) return;
            const txt = getCurrentSelectionText();
            if (txt) {
                src.value = txt;
                status.textContent = 'Text preluat din selecție.';
            } else {
                status.textContent = 'Nicio selecție; poți scrie manual textul.';
            }
        }

        function runTranslate() {
            const src = document.getElementById('trSourceText');
            const dst = document.getElementById('trResultText');
            const status = document.getElementById('trStatus');
            const sl = document.getElementById('trSourceLang').value || 'auto';
            const tl = document.getElementById('trTargetLang').value || 'en';
            const text = (src.value || '').trim();
            if (!text) {
                status.textContent = 'Introdu sau preia un text pentru traducere.';
                return;
            }
            status.textContent = 'Se traduce...';
            dst.value = '';
            // Folosim un API public neoficial Google Translate (fără autentificare),
            // prin endpoint-ul PHP ?action=translate.
            const url = window.location.pathname.replace(/[#?].*$/, '') +
                '?action=translate&sl=' + encodeURIComponent(sl) +
                '&tl=' + encodeURIComponent(tl) +
                '&q=' + encodeURIComponent(text);
            fetch(url)
                .then(r => {
                    if (!r.ok) throw new Error('HTTP ' + r.status);
                    return r.json();
                })
                .then(data => {
                    if (data && data.ok && typeof data.text === 'string') {
                        dst.value = data.text;
                        status.textContent = 'Traducere finalizată.';
                    } else {
                        status.textContent = 'Eroare la traducere (răspuns nevalid).';
                    }
                })
                .catch(err => {
                    console.error(err);
                    status.textContent = 'Eroare la traducere: ' + err.message;
                });
        }

        function applyTranslatedToSelection() {
            const dst = document.getElementById('trResultText');
            const status = document.getElementById('trStatus');
            const text = (dst && dst.value) || '';
            if (!text) {
                status.textContent = 'Nu există un text tradus de inserat.';
                return;
            }
            let replaced = false;
            // 1) Dacă suntem în Design, înlocuim selecția acolo
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if ((viewMode === 'design' || viewMode === 'split') && doc && doc.body) {
                const win = iframe.contentWindow;
                const sel = win && win.getSelection && win.getSelection();
                if (sel && sel.rangeCount > 0 && sel.toString()) {
                    const range = sel.getRangeAt(0);
                    range.deleteContents();
                    range.insertNode(doc.createTextNode(text));
                    sel.removeAllRanges();
                    const r2 = doc.createRange();
                    r2.setStart(range.endContainer, range.endOffset);
                    r2.collapse(true);
                    sel.addRange(r2);
                    clearTimeout(designInputDebounceTimer);
                    designInputDebounceTimer = setTimeout(syncFromDesign, 100);
                    replaced = true;
                }
            }
            // 2) dacă nu s-a reușit în Design, încearcă în CodeMirror
            if (!replaced && editor) {
                const sel = editor.getSelection();
                if (sel) {
                    editor.replaceSelection(text);
                    replaced = true;
                }
            }
            if (replaced) {
                status.textContent = 'Textul tradus a fost inserat în document.';
            } else {
                status.textContent = 'Nu există o selecție de înlocuit; poți copia manual din caseta „Text tradus”.';
            }
        }
        // Insert a diacritical character at the current cursor position
        // (works in both code editor and design panel)
        function insertDiac(ch) {
            const vm = viewMode; // 'code', 'design', or 'split'
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            // Try design panel first (if it has focus / a selection)
            if ((vm === 'design' || vm === 'split') && doc && doc.body) {
                const win = iframe.contentWindow;
                const sel = win && win.getSelection();
                if (sel && sel.rangeCount > 0) {
                    // If the design body is contentEditable and focused, insert there
                    if (doc.body.isContentEditable) {
                        designSaveSnapshot();
                        doc.execCommand('insertText', false, ch);
                        clearTimeout(designInputDebounceTimer);
                        designInputDebounceTimer = setTimeout(syncFromDesign, 80);
                        closeDiacPopup();
                        win.focus();
                        return;
                    }
                }
            }
            // Otherwise insert in code editor
            if (editor) {
                editor.replaceSelection(ch);
                editor.focus();
            }
            closeDiacPopup();
        }

        // ── Find & Replace ──
        let frCurrentMatches = [];
        let frCurrentIdx = -1;
        let frMarks = [];
        let frDesignMatchCount = 0;
        let _frLastQuery = '';       // last search string used to build matches
        let _frLastCaseSens = false; // last Case Sensitive state
        let _frLastWholeWord = false; // last Whole Word state
        let _frLastDesignScope = false; // was last search design-scoped?

        // Returns true when the search should be limited to the article zone
        // (between <!-- ARTICOL START --> and <!-- ARTICOL FINAL -->).
        function _isFindDesignScoped() {
            if (viewMode === 'design') return true;
            if (viewMode === 'code') return false;
            // split mode — check if the iframe (design panel) had focus recently
            const iframe = document.getElementById('preview');
            try {
                if (document.activeElement === iframe) return true;
                // When find dialog takes focus, remember last active panel.
                // The iframe's body being contentEditable means the user was
                // working in design before opening Find.
            } catch (e) {}
            return _frDesignWasLastFocused;
        }

        // Track which panel the user interacted with last (for split mode).
        let _frDesignWasLastFocused = false;

        function toggleFindReplace() {
            const dlg = document.getElementById('findReplaceDialog');
            if (dlg.classList.contains('visible')) {
                closeFindReplace();
            } else {
                // Deactivate SELECT / CROP so they don't interfere with FIND
                if (sasaSelectionActive) deactivateSasa();
                if (cropHighlightActive) deactivateCrop();
                dlg.classList.add('visible');
                const inp = document.getElementById('frFindInput');
                const repInp = document.getElementById('frReplaceInput');
                // Pre-fill with current selection, or clear if nothing selected
                if (editor) {
                    let sel = editor.getSelection();
                    if (viewMode === 'design') {
                        let dt = '';
                        try {
                            const w = document.getElementById('preview').contentWindow;
                            dt = (w.getSelection() || '').toString();
                        } catch (e) { }
                        sel = dt && dt.trim() && !/\n/.test(dt) ? dt.trim() : '';
                    }
                    if (sel) {
                        inp.value = sel;
                    } else {
                        inp.value = '';
                        repInp.value = '';
                    }
                } else {
                    inp.value = '';
                    repInp.value = '';
                }
                inp.focus();
                inp.select();
            }
        }

        function closeFindReplace() {
            document.getElementById('findReplaceDialog').classList.remove('visible');
            clearFindMarks();
            frCurrentMatches = [];
            document.getElementById('frInfo').textContent = '';
            _frLastQuery = '';
            frCurrentIdx = -1;
            // Deselect in CodeMirror — just collapse cursor to remove selection highlight
            if (editor) {
                const cursor = editor.getCursor('from');
                editor.setCursor(cursor);
                editor.focus();
            }
            // Also deselect in design panel
            try {
                const iframe = document.getElementById('preview');
                const win = iframe && iframe.contentWindow;
                if (win && win.getSelection) {
                    win.getSelection().removeAllRanges();
                }
            } catch (e) {}
        }

        function clearFindMarks() {
            frMarks.forEach(m => m.clear());
            frMarks = [];
            frDesignMatchCount = 0;
            clearDesignFindHighlights();
        }

        function clearDesignFindHighlights() {
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body) return;
            // Remove all find highlight marks from design panel
            const marks = doc.querySelectorAll('mark[data-fr-highlight]');
            marks.forEach(mark => {
                const parent = mark.parentNode;
                while (mark.firstChild) parent.insertBefore(mark.firstChild, mark);
                parent.removeChild(mark);
                parent.normalize(); // merge adjacent text nodes back
            });
        }

        function highlightFindInDesign() {
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body) return 0;
            if (viewMode !== 'design' && viewMode !== 'split') return 0;

            clearDesignFindHighlights();

            const regex = buildSearchRegex();
            if (!regex) return 0;

            // Walk all text nodes in the design body and highlight matches
            const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, {
                acceptNode(node) {
                    // Skip script/style/empty nodes
                    const tag = node.parentNode && node.parentNode.tagName;
                    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'MARK') return NodeFilter.FILTER_REJECT;
                    if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_SKIP;
                    return NodeFilter.FILTER_ACCEPT;
                }
            });

            const textNodes = [];
            let tNode;
            while ((tNode = walker.nextNode())) textNodes.push(tNode);

            textNodes.forEach(node => {
                const text = node.nodeValue;
                regex.lastIndex = 0;
                let match;
                const parts = [];
                let lastIdx = 0;
                while ((match = regex.exec(text)) !== null) {
                    if (match.index > lastIdx) {
                        parts.push(doc.createTextNode(text.slice(lastIdx, match.index)));
                    }
                    const mark = doc.createElement('mark');
                    mark.setAttribute('data-fr-highlight', '1');
                    mark.style.background = 'rgba(255, 165, 0, 0.45)';
                    mark.style.borderBottom = '2px solid #f59e0b';
                    mark.style.padding = '0';
                    mark.style.color = 'inherit';
                    mark.textContent = match[0];
                    parts.push(mark);
                    lastIdx = match.index + match[0].length;
                    if (match[0].length === 0) break; // prevent infinite loop on zero-length match
                }
                if (parts.length > 0) {
                    if (lastIdx < text.length) {
                        parts.push(doc.createTextNode(text.slice(lastIdx)));
                    }
                    const parent = node.parentNode;
                    parts.forEach(p => parent.insertBefore(p, node));
                    parent.removeChild(node);
                }
            });
            return doc.querySelectorAll('mark[data-fr-highlight]').length;
        }

        /** Grup regex: un caracter RO indiferent dacă e scris cu sau fără diacritice (inclusiv ş/ţ vechi). */
        function buildDiacInsensitivePattern(text) {
            const esc = (ch) => (/[.*+?^${}()|[\]\\]/.test(ch) ? '\\' + ch : ch);
            let result = '';
            for (const ch of text) {
                if (/^[aAăĂâÂ]$/.test(ch)) {
                    result += '[aAăĂâÂ]';
                } else if (/^[iIîÎ]$/.test(ch)) {
                    result += '[iIîÎ]';
                } else if (/^[sSșȘşŞ]$/.test(ch)) {
                    result += '[sSșȘşŞ]';
                } else if (/^[tTțȚţŢ]$/.test(ch)) {
                    result += '[tTțȚţŢ]';
                } else {
                    result += esc(ch);
                }
            }
            return result;
        }

        function buildSearchRegex() {
            const query = document.getElementById('frFindInput').value;
            if (!query) return null;
            const caseSensitive = document.getElementById('frCaseSensitive').checked;
            const wholeWord = document.getElementById('frWholeWord').checked;
            let pattern = buildDiacInsensitivePattern(query);
            if (wholeWord) pattern = '\\b' + pattern + '\\b';
            const flags = caseSensitive ? 'g' : 'gi';
            try { return new RegExp(pattern, flags); } catch (e) { return null; }
        }

        function findAllMatches() {
            clearFindMarks();
            frCurrentMatches = [];
            frCurrentIdx = -1;
            if (!editor) return;
            const regex = buildSearchRegex();
            if (!regex) {
                document.getElementById('frInfo').textContent = '';
                return;
            }
            const src = editor.getValue();

            // Design search covers every text node visible in the preview.
            const designScoped = _isFindDesignScoped();
            _frLastDesignScope = designScoped;

            let m;
            while ((m = regex.exec(src)) !== null) {
                const from = editor.posFromIndex(m.index);
                const to = editor.posFromIndex(m.index + m[0].length);
                frCurrentMatches.push({ from, to, index: m.index, length: m[0].length });
                // Highlight all matches with a dim background
                const mark = editor.markText(from, to, {
                    className: 'cm-find-highlight'
                });
                frMarks.push(mark);
            }
            frDesignMatchCount = highlightFindInDesign();
            const resultCount = designScoped ? frDesignMatchCount : frCurrentMatches.length;
            document.getElementById('frInfo').textContent = resultCount === 1
                ? '1 rezultat gasit'
                : resultCount + ' rezultate gasite';
        }

        function getFindResultCount() {
            return _isFindDesignScoped() ? frDesignMatchCount : frCurrentMatches.length;
        }

        // Rebuild match list only when query or options changed since last search.
        function _ensureFindMatches() {
            const q = document.getElementById('frFindInput').value;
            const cs = document.getElementById('frCaseSensitive').checked;
            const ww = document.getElementById('frWholeWord').checked;
            const ds = _isFindDesignScoped();
            if (q === _frLastQuery && cs === _frLastCaseSens && ww === _frLastWholeWord
                && ds === _frLastDesignScope && getFindResultCount() > 0) {
                return; // matches are still valid
            }
            _frLastQuery = q;
            _frLastCaseSens = cs;
            _frLastWholeWord = ww;
            findAllMatches();
            if (ds && frDesignMatchCount > 0) {
                // Design: pornește de la primul rezultat de după cursorul din Design
                frCurrentIdx = -1;
                try {
                    const ifr = document.getElementById('preview');
                    const dsel = ifr.contentWindow.getSelection();
                    if (dsel && dsel.rangeCount) {
                        const cur = dsel.getRangeAt(0);
                        const marks = ifr.contentDocument.querySelectorAll('mark[data-fr-highlight]');
                        for (let i = 0; i < marks.length; i++) {
                            const mr = ifr.contentDocument.createRange();
                            mr.selectNode(marks[i]);
                            if (mr.compareBoundaryPoints(Range.START_TO_START, cur) >= 0) { frCurrentIdx = i - 1; break; }
                        }
                    }
                } catch (e) { frCurrentIdx = -1; }
                return;
            }
            // After a fresh search, position index so the NEXT call lands on
            // the first match at or after the current cursor.
            if (frCurrentMatches.length > 0) {
                const cursorIdx = editor.indexFromPos(editor.getCursor('from'));
                frCurrentIdx = -1; // will be incremented by findNext
                for (let i = 0; i < frCurrentMatches.length; i++) {
                    if (frCurrentMatches[i].index >= cursorIdx) {
                        frCurrentIdx = i - 1; // so +1 lands on i
                        break;
                    }
                }
                // If cursor is past all matches, wrap to start
                if (frCurrentIdx === -1 && frCurrentMatches[0].index < cursorIdx) {
                    frCurrentIdx = frCurrentMatches.length - 1; // wrap: next +1 → 0
                }
            }
        }

        function findNext() {
            _ensureFindMatches();
            const resultCount = getFindResultCount();
            if (resultCount === 0) {
                document.getElementById('frInfo').textContent = 'Niciun rezultat';
                return;
            }
            frCurrentIdx = (frCurrentIdx + 1) % resultCount;
            goToMatch(frCurrentIdx);
        }

        function findPrev() {
            _ensureFindMatches();
            const resultCount = getFindResultCount();
            if (resultCount === 0) {
                document.getElementById('frInfo').textContent = 'Niciun rezultat';
                return;
            }
            frCurrentIdx = (frCurrentIdx - 1 + resultCount) % resultCount;
            goToMatch(frCurrentIdx);
        }

        function goToMatch(idx) {
            // În Design, rezultatele sunt marcajele din Design (nu pozițiile din cod,
            // care pot fi altele: <title>, meta, marcaje vechi etc.).
            if (_isFindDesignScoped() && (viewMode === 'design' || viewMode === 'split')) {
                const doc = document.getElementById('preview').contentDocument;
                const marks = doc ? doc.querySelectorAll('mark[data-fr-highlight]') : [];
                if (marks.length !== frDesignMatchCount || marks.length === 0) {
                    // Design-ul a fost reîncărcat între timp → refă marcajele
                    frDesignMatchCount = highlightFindInDesign();
                    if (frDesignMatchCount === 0) {
                        document.getElementById('frInfo').textContent = 'Niciun rezultat';
                        return;
                    }
                    if (idx >= frDesignMatchCount) idx = frCurrentIdx = 0;
                }
                // Nu lăsa panoul de jos (Font, Clasa…) să sară la fiecare rezultat
                window._frNavigatingUntil = Date.now() + 800;
                try { scrollToDesignMatch(idx); } catch (e) { }
                if (viewMode === 'split') {
                    try { syncSelectionToCodeFromDesign(); } catch (e) { }
                }
                document.getElementById('frInfo').textContent =
                    'Rezultat ' + (idx + 1) + ' din ' + frDesignMatchCount;
                return;
            }
            const match = frCurrentMatches[idx];
            if (match) {
                editor.setSelection(match.from, match.to);
                editor.scrollIntoView({ from: match.from, to: match.to }, 80);
                if (viewMode === 'code') editor.focus();
            }
            // Scroll to the active match in Design panel and highlight it
            try {
                if (viewMode === 'design' || viewMode === 'split') {
                    scrollToDesignMatch(idx);
                }
            } catch (e) {
                // daca apare vreo eroare, nu blocam cautarea in cod
            }
            const resultCount = getFindResultCount();
            document.getElementById('frInfo').textContent =
                'Rezultat ' + (idx + 1) + ' din ' + resultCount;
        }

        function scrollToDesignMatch(idx) {
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body) return;
            const marks = doc.querySelectorAll('mark[data-fr-highlight]');
            if (marks.length === 0) return;
            // Reset all to default style
            marks.forEach(m => {
                m.style.background = 'rgba(255, 165, 0, 0.45)';
                m.style.outline = 'none';
            });
            // Highlight active match more prominently
            // idx is the code match index; design marks may differ in count
            // but usually they correspond, so we use min(idx, marks.length-1)
            const activeIdx = Math.min(idx, marks.length - 1);
            if (marks[activeIdx]) {
                const activeMark = marks[activeIdx];
                activeMark.style.background = 'rgba(255, 140, 0, 0.8)';
                activeMark.style.outline = '2px solid #f59e0b';
                activeMark.scrollIntoView({ behavior: 'smooth', block: 'center' });

                const win = iframe.contentWindow;
                const selection = win && win.getSelection ? win.getSelection() : null;
                if (selection) {
                    const range = doc.createRange();
                    range.selectNodeContents(activeMark);
                    selection.removeAllRanges();
                    selection.addRange(range);
                    rememberDesignSelectionRange(win, doc);
                }
            }
        }

        function replaceCurrent() {
            if (!editor) return;
            const findText = document.getElementById('frFindInput').value;
            const replaceText = document.getElementById('frReplaceInput').value;
            if (!findText) return;

            // Check if the current CodeMirror selection already matches the search term
            const currentSel = editor.getSelection();
            const regex = buildSearchRegex();
            const selTestFlags = (regex && regex.flags) ? regex.flags.replace(/g/g, '') : '';
            if (regex && currentSel && new RegExp('^' + regex.source + '$', selTestFlags).test(currentSel)) {
                // The selection IS a match — replace it immediately
                editor.replaceSelection(replaceText);
                isDirty = true;
                // Re-find and go to next match
                findAllMatches();
                if (frCurrentMatches.length > 0) {
                    // Find the match at or after current cursor position
                    const cursorIdx = editor.indexFromPos(editor.getCursor('from'));
                    frCurrentIdx = 0;
                    for (let i = 0; i < frCurrentMatches.length; i++) {
                        if (frCurrentMatches[i].index >= cursorIdx) {
                            frCurrentIdx = i;
                            break;
                        }
                    }
                    goToMatch(frCurrentIdx);
                } else {
                    document.getElementById('frInfo').textContent = 'Niciun rezultat ramas';
                }
            } else {
                // Selection doesn't match — find the first match, then replace it
                _ensureFindMatches();
                if (frCurrentMatches.length === 0) {
                    document.getElementById('frInfo').textContent = 'Niciun rezultat';
                    return;
                }
                // Find closest match to cursor
                const cursorIdx = editor.indexFromPos(editor.getCursor('from'));
                frCurrentIdx = 0;
                for (let i = 0; i < frCurrentMatches.length; i++) {
                    if (frCurrentMatches[i].index >= cursorIdx) {
                        frCurrentIdx = i;
                        break;
                    }
                }
                const match = frCurrentMatches[frCurrentIdx];
                editor.setSelection(match.from, match.to);
                editor.replaceSelection(replaceText);
                isDirty = true;
                // Re-find and advance
                findAllMatches();
                if (frCurrentMatches.length > 0) {
                    const newCursorIdx = editor.indexFromPos(editor.getCursor('from'));
                    frCurrentIdx = 0;
                    for (let i = 0; i < frCurrentMatches.length; i++) {
                        if (frCurrentMatches[i].index >= newCursorIdx) {
                            frCurrentIdx = i;
                            break;
                        }
                    }
                    goToMatch(frCurrentIdx);
                } else {
                    document.getElementById('frInfo').textContent = 'Niciun rezultat ramas';
                }
            }
        }

        function replaceAll() {
            if (!editor) return;
            const findText = document.getElementById('frFindInput').value;
            const replaceText = document.getElementById('frReplaceInput').value;
            if (!findText) return;
            const regex = buildSearchRegex();
            if (!regex) return;
            const src = editor.getValue();
            const count = (src.match(regex) || []).length;
            if (count === 0) {
                document.getElementById('frInfo').textContent = 'Niciun rezultat';
                return;
            }
            const newSrc = src.replace(regex, replaceText);
            const cursor = editor.getCursor();
            editor.setValue(newSrc);
            editor.setCursor(cursor);
            isDirty = true;
            clearFindMarks();
            frCurrentMatches = [];
            frCurrentIdx = -1;
            document.getElementById('frInfo').textContent = count + ' inlocuiri efectuate';
            toast(count + ' inlocuiri effectuate');
        }

        function initEditor() {
            editor = CodeMirror.fromTextArea(document.getElementById('code'), {
                mode: 'application/x-httpd-php',
                lineNumbers: true,
                theme: 'material-darker',
                lineWrapping: true,
                indentUnit: 4,
                indentWithTabs: false,
                tabSize: 4
            });
            window.editor = editor;
            // CodeMirror may scroll the outer page to reveal its cursor, even while
            // hidden in Design. Background synchronization must not move the viewport.
            editor.on('scrollCursorIntoView', (cm, event) => {
                if (viewMode === 'design' || isSyncFromDesign || isSelectionFromDesign) {
                    event.preventDefault();
                }
            });
            editor.setSize('100%', '100%');
            // Diacritice românești în editorul de cod
            editor.addKeyMap({
                'Enter': cm => {
                    // Insert a single newline without extra indentation
                    cm.replaceSelection('\n');
                },
                'Ctrl-A': cm => { cm.replaceSelection('ă'); },
                'Ctrl-I': cm => { cm.replaceSelection('î'); },
                'Shift-Ctrl-S': cm => { cm.replaceSelection('ș'); },
                'Alt-T': cm => { cm.replaceSelection('ț'); },
                'Alt-Shift-T': cm => { cm.replaceSelection('Ț'); },
                'Alt-S': cm => { cm.replaceSelection('Ș'); },
                'Alt-I': cm => { cm.replaceSelection('Î'); },
                'Alt-A': cm => { cm.replaceSelection('â'); },
            });

            // ── Paste into empty / selected <p> blocks (code editor) ──
            // Rich HTML / entity-encoded tags from the clipboard (e.g. DeepSeek) are
            // reduced to plain text, then wrapped only in <p class="text_obisnuit">…</p>.
            function mergePasteIntoTextObisnuitParagraph(cm, change) {
                if (typeof isCurrentFileHtml !== 'function' || !isCurrentFileHtml()) return false;
                if (change.origin !== 'paste') return false;
                const fromIdx = cm.indexFromPos(change.from);
                const toIdx = cm.indexFromPos(change.to);
                const src = cm.getValue();

                function clipToPlainMultiline(text) {
                    let t = Array.isArray(text) ? text.join('\n') : String(text);
                    // Entity-encoded tags (&lt;p …&gt;) → decode, then strip markup to plain text only.
                    if (/&(?:#(?:x[\da-f]+|\d+)|[a-z][a-z0-9]*);/i.test(t)) {
                        const ta = document.createElement('textarea');
                        ta.innerHTML = t;
                        t = ta.value;
                    }
                    if (/<[a-z!?\/]/i.test(t)) {
                        const tmp = document.createElement('div');
                        tmp.innerHTML = t;
                        t = tmp.textContent || tmp.innerText || '';
                    }
                    return t.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
                }
                function escapeHtmlText(s) {
                    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                }
                function normalizeParagraphChunks(plain, minBlocksHint) {
                    let t = plain.replace(/\u00a0/g, ' ').trim();
                    if (!t) return [];
                    let parts = t.split(/\n\s*\n+/).map(function (p) {
                        return p.replace(/ {2,}/g, ' ').trim();
                    }).filter(Boolean);
                    if (parts.length === 1 && minBlocksHint >= 2 && /\n/.test(t)) {
                        var lines = t.split('\n').map(function (l) {
                            return l.replace(/ {2,}/g, ' ').trim();
                        }).filter(Boolean);
                        if (lines.length >= 2) parts = lines;
                    }
                    return parts;
                }
                /** Whitespace + optional second empty <p class="text_obisnuit"></p> (duplicate placeholder). */
                function lenFollowingEmptyTextObisnuitSibling(html, idx) {
                    const m = html.slice(idx).match(/^\s*<p\s+class\s*=\s*["']text_obisnuit["']\s*>\s*<\/p>/i);
                    return m ? m[0].length : 0;
                }
                function htmlToPlainTextForCompare(html) {
                    const tmp = document.createElement('div');
                    tmp.innerHTML = String(html || '').replace(/<br\s*\/?>/gi, '\n');
                    return (tmp.textContent || tmp.innerText || '').replace(/\u00a0/g, ' ');
                }
                function normalizeTextForCompare(value) {
                    return String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
                }
                function replaceFullSpanTextObisnuitSelection() {
                    if (fromIdx >= toIdx) return false;
                    const rawMulti = clipToPlainMultiline(change.text);
                    const parts = normalizeParagraphChunks(rawMulti, 1);
                    if (!parts.length) return false;
                    const selectedPlain = normalizeTextForCompare(htmlToPlainTextForCompare(src.slice(fromIdx, toIdx)));
                    if (!selectedPlain) return false;
                    const fullSpanRe = /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit\b[^"']*["'][^>]*>)(\s*<span\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>)([\s\S]*?)(<\/span>\s*<\/p>)/gi;
                    let m;
                    while ((m = fullSpanRe.exec(src)) !== null) {
                        const pStart = m.index;
                        const pEnd = m.index + m[0].length;
                        const innerStart = m.index + m[1].length + m[2].length;
                        const innerEnd = innerStart + m[3].length;
                        const selectionWithinParagraph = fromIdx >= pStart && toIdx <= pEnd;
                        const selectionCoversInner = fromIdx <= innerStart && toIdx >= innerEnd;
                        const selectionInsideInner = fromIdx >= innerStart && toIdx <= innerEnd;
                        if (!selectionWithinParagraph && !selectionCoversInner && !selectionInsideInner) continue;
                        if (selectedPlain !== normalizeTextForCompare(htmlToPlainTextForCompare(m[3]))) continue;
                        const lineStart = src.lastIndexOf('\n', pStart - 1) + 1;
                        const indent = (src.slice(lineStart, pStart).match(/^\s*/) || [''])[0];
                        let replacement;
                        if (parts.length === 1) {
                            replacement = m[1] + escapeHtmlText(parts[0]) + '</p>';
                        } else {
                            replacement = parts.map(function (part, idx) {
                                const pOpen = idx === 0 ? m[1] : '<p class="text_obisnuit">';
                                return (idx === 0 ? '' : indent) + pOpen + escapeHtmlText(part) + '</p>';
                            }).join('\n');
                        }
                        change.cancel();
                        cm.operation(function () {
                            cm.replaceRange(replacement, cm.posFromIndex(pStart), cm.posFromIndex(pEnd));
                            cm.setCursor(cm.posFromIndex(pStart + replacement.length));
                        });
                        return true;
                    }
                    return false;
                }

                // Non-empty selection that looks like one or more <p>…</p> → replace with plain text_obisnuit blocks only.
                if (fromIdx < toIdx) {
                    if (replaceFullSpanTextObisnuitSelection()) {
                        return true;
                    }
                    const sel = src.slice(fromIdx, toIdx);
                    const nPOpen = (sel.match(/<p\b/gi) || []).length;
                    const nPClose = (sel.match(/<\/p>/gi) || []).length;
                    const looksLikeParagraphReplace = (nPOpen >= 1 && nPClose >= 1) || nPOpen >= 2 || nPClose >= 2;
                    if (looksLikeParagraphReplace) {
                        const rawMulti = clipToPlainMultiline(change.text);
                        const parts = normalizeParagraphChunks(rawMulti, Math.max(1, nPOpen, nPClose));
                        if (!parts.length) return false;
                        const lineStart = src.lastIndexOf('\n', fromIdx - 1) + 1;
                        const indent = (src.slice(lineStart).match(/^(\s*)/) || ['', ''])[1];
                        const blocks = parts.map(function (part) {
                            return indent + '<p class="text_obisnuit">' + escapeHtmlText(part) + '</p>';
                        }).join('\n');
                        change.cancel();
                        cm.operation(function () {
                            cm.replaceRange(blocks, cm.posFromIndex(fromIdx), cm.posFromIndex(toIdx));
                            cm.setCursor(cm.posFromIndex(fromIdx + blocks.length));
                        });
                        return true;
                    }
                }

                let raw = clipToPlainMultiline(change.text);
                raw = raw.replace(/\n/g, ' ').replace(/ {2,}/g, ' ').trim();
                if (!raw) return false;
                const esc = escapeHtmlText(raw);
                const openRe = /<p\s+class\s*=\s*["']text_obisnuit["']\s*>/gi;
                let matchB = null;
                let m;
                while ((m = openRe.exec(src)) !== null) {
                    const oStart = m.index;
                    const oEnd = m.index + m[0].length;
                    const closeIdx = src.indexOf('</p>', oEnd);
                    if (closeIdx === -1) continue;
                    const inner = src.slice(oEnd, closeIdx);
                    if (!/^\s*$/.test(inner)) continue;
                    if (fromIdx < oEnd || fromIdx >= closeIdx) continue;
                    if (toIdx < oEnd || toIdx > closeIdx) continue;
                    matchB = { oStart: oStart, closeEnd: closeIdx + 5 };
                }
                const insertFull = '<p class="text_obisnuit">' + esc + '</p>';
                if (matchB) {
                    const closeEndExtended = matchB.closeEnd +
                        lenFollowingEmptyTextObisnuitSibling(src, matchB.closeEnd);
                    change.cancel();
                    cm.operation(() => {
                        cm.replaceRange(insertFull,
                            cm.posFromIndex(matchB.oStart),
                            cm.posFromIndex(closeEndExtended));
                        cm.setCursor(cm.posFromIndex(matchB.oStart + insertFull.length));
                    });
                    return true;
                }
                const before = src.slice(0, fromIdx);
                // Include newlines/tabs after </p> — cursor is often on the next line before the next <p>.
                const emptyPSuffix = /<p\s+class\s*=\s*["']text_obisnuit["']\s*>\s*<\/p>\s*$/i;
                const mA = before.match(emptyPSuffix);
                if (mA) {
                    const replStart = fromIdx - mA[0].length;
                    const pasteEnd = toIdx + lenFollowingEmptyTextObisnuitSibling(src, toIdx);
                    change.cancel();
                    cm.operation(() => {
                        cm.replaceRange(insertFull,
                            cm.posFromIndex(replStart),
                            cm.posFromIndex(pasteEnd));
                        cm.setCursor(cm.posFromIndex(replStart + insertFull.length));
                    });
                    return true;
                }
                return false;
            }

            // ── SASA code-side interception ──
            // When SASA is active and user types/deletes/pastes in the CODE editor,
            // cancel CodeMirror's default change, manually replace the SASA range,
            // and position the cursor between markers — all in one atomic operation.
            editor.on('beforeChange', (cm, change) => {
                if (!sasaSelectionActive && mergePasteIntoTextObisnuitParagraph(cm, change)) {
                    return;
                }
                if (!sasaSelectionActive) return;
                const o = change.origin;
                if (o !== '+input' && o !== '+delete' && o !== 'paste' && o !== 'cut') return;
                change.cancel();
                const range = getSasaRange();
                if (!range) { deactivateSasa(); return; }
                // Strip SASA visual highlights from DOM BEFORE saving snapshot
                // so that undo states never contain highlight artefacts.
                clearSasaDesignHighlight();
                // Save the current design state to undo stack BEFORE the SASA edit
                designSaveSnapshot();
                const rawText = (o === '+delete' || o === 'cut') ? '' : change.text.join('\n');
                // Wrap typed/pasted text in <p class="text_obisnuit"><em>…</em></p>
                const insertText = rawText.length > 0 ? wrapTextForSasa(rawText) : '';
                deactivateSasa();
                isSyncFromDesign = true;
                editor.operation(() => {
                    editor.replaceRange(insertText, range.from, range.to);
                    if (insertText.length > 0) {
                        if (o === '+input') {
                            // Typing: position cursor INSIDE <em>, right after
                            // the typed character so continued typing stays
                            // inside the tag.
                            // Wrapped: <p class="text_obisnuit"><em>X</em></p>
                            //           prefix = 28 chars ─────────^
                            const prefix = '<p class="text_obisnuit"><em>';
                            const endPos = {
                                line: range.from.line,
                                ch: range.from.ch + prefix.length + rawText.length
                            };
                            editor.setCursor(endPos);
                            editor.scrollIntoView(endPos, 60);
                        } else {
                            // Paste: position cursor at end of all wrapped content
                            const lines = insertText.split('\n');
                            const endPos = {
                                line: range.from.line + lines.length - 1,
                                ch: lines[lines.length - 1].length
                            };
                            editor.setCursor(endPos);
                            editor.scrollIntoView(endPos, 60);
                        }
                    } else {
                        // Delete/cut: position at start of empty line between markers
                        positionCursorBetweenSasa();
                    }
                });
                isSyncFromDesign = false;
                applyCodeToDesignPanel();
            });

            // Data articolului schimbată (în Code sau Design) → verificare dubluri după 10 s
            editor.on('change', () => {
                try { noteEditorChangeForDateCheck(); } catch (e) { }
            });

            // Paste în Code cu <span style="font-family…"> (stil AI) → rescris imediat în stilul site-ului
            editor.on('change', (cm, change) => {
                if (!change || change.origin !== 'paste') return;
                if (!/<(?:span|em|i|strong|b|u)\b[^>]*\bstyle\s*=/i.test((change.text || []).join('\n'))) return;
                if (!isCurrentFileHtml()) return;
                setTimeout(() => {
                    const src = cm.getValue();
                    const edits = computeAiStyledSpanEdits(src);
                    if (!edits.length) return;
                    cm.operation(() => {
                        for (let i = edits.length - 1; i >= 0; i--) {
                            cm.replaceRange(edits[i].text, cm.posFromIndex(edits[i].from), cm.posFromIndex(edits[i].to), '+aiStyleCleanup');
                        }
                    });
                }, 0);
            });

            editor.on('change', () => {
                // Clear design-click highlight when user edits in code
                if (_imgClickMark) { _imgClickMark.clear(); _imgClickMark = null; }
                refreshClassListFromCode();
                // Skip dirty recalculation during tab restore — the tab already has correct isDirty
                if (!_isRestoringTab && activeTabId) {
                    var _t = null;
                    for (var _i = 0; _i < tabs.length; _i++) { if (tabs[_i].id === activeTabId) { _t = tabs[_i]; break; } }
                    if (_t) {
                        var nowDirty = (normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(_t.originalContent));
                        if (nowDirty !== _t.isDirty) {
                            _t.isDirty = nowDirty;
                            isDirty = nowDirty;
                            var _el = document.querySelector('.editor-tab[data-tab-id="' + activeTabId + '"]');
                            if (_el) { if (nowDirty) _el.classList.add('dirty'); else _el.classList.remove('dirty'); }
                            if (nowDirty) backupDirtyTabs();
                        }
                    }
                }
                if (!_isRestoringTab) scheduleLiveH1TitleSync();
                if (isSyncFromDesign) return;
                if (isApplyingUndoRedo) return;
                // Collapse multiple consecutive spaces in code (preserve leading indentation).
                // Runs on every change; uses replaceRange only when something actually changed.
                (function collapseSpacesInCode() {
                    if (_isRestoringTab) return;
                    // Only collapse spaces on the line where the cursor is (preserve indentation elsewhere)
                    const cursor = editor.getCursor();
                    const i = cursor.line;
                    const line = editor.getLine(i);
                    if (!line) return;
                    // Find leading whitespace length to preserve indentation
                    const leadingMatch = line.match(/^(\s*)/);
                    const leadLen = leadingMatch ? leadingMatch[1].length : 0;
                    const afterIndent = line.substring(leadLen);
                    // Only collapse 2+ spaces inside text content (between tags),
                    // not in tag attributes or indentation. Mirrors Notepad++ regex:
                    // \x20{2,}(?=[^<>]*<)  — spaces followed by non-tag chars then <
                    // Also handle trailing text after last > (no < follows):
                    const cleaned = afterIndent
                        .replace(/ {2,}(?=[^<>]*<)/g, ' ')
                        .replace(/(?<=>)([^<]*)$/g, function(m) { return m.replace(/ {2,}/g, ' '); });
                    if (cleaned !== afterIndent) {
                        const cursorCh = cursor.ch;
                        isSyncFromDesign = true; // prevent re-trigger
                        editor.operation(() => {
                            editor.replaceRange(cleaned,
                                { line: i, ch: leadLen },
                                { line: i, ch: leadLen + afterIndent.length });
                        });
                        // Adjust cursor position for removed spaces
                        const diff = afterIndent.length - cleaned.length;
                        const newCh = Math.max(leadLen, cursorCh - diff);
                        editor.setCursor({ line: i, ch: newCh });
                        isSyncFromDesign = false;
                    }
                })();
                if (Date.now() < skipPreviewUpdateUntil) return;
                // If the page previously had a <body> structure but undo/change
                // removed it (or vice-versa), force a full blob reload so CSS
                // and override styles are rebuilt correctly.
                const nowHasBody = /<body\b/i.test(editor.getValue());
                if (nowHasBody !== lastPreviewHadBody) {
                    lastPreviewHadBody = nowHasBody;
                    clearTimeout(previewDebounceTimer);
                    previewDebounceTimer = null;
                    isSyncFromCode = true;
                    updatePreview();
                    setTimeout(() => { isSyncFromCode = false; }, 500);
                    return;
                }
                clearTimeout(previewDebounceTimer);
                previewDebounceTimer = setTimeout(() => {
                    const _iframe = document.getElementById('preview');
                    const _doc = _iframe && _iframe.contentDocument;
                    if (isCurrentFileHtml() && _doc && _doc.body) {
                        // Design panel already loaded — inject body directly without disk reload
                        applyCodeToDesignPanel();
                        lastPreviewHadBody = /<body\b/i.test(editor.getValue());
                    } else {
                        isSyncFromCode = true;
                        updatePreview();
                        setTimeout(() => { isSyncFromCode = false; }, 500);
                    }
                }, 500);
            });

            let _isCodeDragging = false;
            editor.getWrapperElement().addEventListener('mousedown', () => {
                _isCodeDragging = true;
                _frDesignWasLastFocused = false; // user clicked in code panel
                // Clear persistent image/icon highlight when user clicks in code
                if (_imgClickMark) { _imgClickMark.clear(); _imgClickMark = null; }
            });
            window.addEventListener('mouseup', () => {
                if (_isCodeDragging) {
                    _isCodeDragging = false;
                    // Trigger sync once drag ends
                    if (editor && !isCursorInsideSasa() && !sasaSelectionActive) {
                        syncSelectionToDesignFromCode();
                    }
                }
            });
            // ── Double/triple-click in code editor: select inner content of tag ──
            // Shared logic: find the tag content surrounding the cursor and highlight it.
            // Returns true if a selection was made, false otherwise.
            function _selectTagContentAtCursor() {
                const cursor = editor.getCursor();
                const src = editor.getValue();
                const cursorIdx = editor.indexFromPos(cursor);

                // ── Strategy 1: Cursor inside a tag — select attribute value between quotes ──
                let tagStart = -1;
                for (let i = cursorIdx; i >= 0; i--) {
                    if (src[i] === '<') { tagStart = i; break; }
                    if (src[i] === '>' && i < cursorIdx) { tagStart = -1; break; }
                }

                if (tagStart !== -1) {
                    const tagEnd = findTagClose(src, tagStart + 1);
                    if (tagEnd !== -1 && cursorIdx <= tagEnd) {
                        let i = tagStart + 1;
                        while (i <= tagEnd) {
                            const ch = src[i];
                            if (ch === '"' || ch === "'") {
                                const quoteChar = ch;
                                const valStart = i + 1;
                                let valEnd = valStart;
                                while (valEnd <= tagEnd && src[valEnd] !== quoteChar) valEnd++;
                                if (cursorIdx >= valStart && cursorIdx <= valEnd) {
                                    const from = editor.posFromIndex(valStart);
                                    const to = editor.posFromIndex(valEnd);
                                    if (syncSelectionMark) { syncSelectionMark.clear(); syncSelectionMark = null; }
                                    isSelectionFromDesign = true;
                                    editor.setSelection(from, to);
                                    editor.scrollIntoView({ from, to }, 100);
                                    isSelectionFromDesign = false;
                                    syncSelectionMark = editor.markText(from, to, { className: 'cm-selection-highlight' });
                                    return true;
                                }
                                i = valEnd + 1;
                                continue;
                            }
                            i++;
                        }
                        return false; // inside tag but not in attribute value
                    }
                }

                // ── Strategy 2: Cursor between tags — select inner content of enclosing element ──
                const beforeCursor = src.substring(0, cursorIdx);
                const openTagPatterns = [
                    /<p\s+class="text_obisnuit">/gi,
                    /<p\s+class="text_obisnuit2">/gi,
                    /<h1\s+class="den_articol"[^>]*>/gi,
                    /<title>/gi,
                ];
                const closeTagMap = {
                    'p': /<\/p>/gi,
                    'h1': /<\/h1>/gi,
                    'title': /<\/title>/gi,
                };

                let bestMatchEnd = -1;
                let bestTagName = '';

                for (const pattern of openTagPatterns) {
                    pattern.lastIndex = 0;
                    let m;
                    while ((m = pattern.exec(beforeCursor)) !== null) {
                        const matchEnd = m.index + m[0].length;
                        if (matchEnd > bestMatchEnd) {
                            bestMatchEnd = matchEnd;
                            const tn = m[0].match(/^<(\w+)/);
                            bestTagName = tn ? tn[1].toLowerCase() : '';
                        }
                    }
                }

                if (bestMatchEnd !== -1 && bestTagName) {
                    const closePattern = closeTagMap[bestTagName];
                    if (closePattern) {
                        closePattern.lastIndex = 0;
                        const restSrc = src.substring(bestMatchEnd);
                        const closeMatch = closePattern.exec(restSrc);
                        if (closeMatch) {
                            const contentStart = bestMatchEnd;
                            const contentEnd = bestMatchEnd + closeMatch.index;
                            if (cursorIdx >= contentStart && cursorIdx <= contentEnd) {
                                const from = editor.posFromIndex(contentStart);
                                const to = editor.posFromIndex(contentEnd);
                                if (syncSelectionMark) { syncSelectionMark.clear(); syncSelectionMark = null; }
                                isSelectionFromDesign = true;
                                editor.setSelection(from, to);
                                editor.scrollIntoView({ from, to }, 100);
                                isSelectionFromDesign = false;
                                syncSelectionMark = editor.markText(from, to, { className: 'cm-selection-highlight' });
                                return true;
                            }
                        }
                    }
                }
                return false;
            }

            // Track whether our tag-content selection is active so triple-click
            // doesn't override it with CodeMirror's default line selection.
            let _tagContentSelected = false;

            // Intercept triple-click (and beyond) at mousedown BEFORE CodeMirror
            // processes it, so it cannot select the whole line.
            editor.getWrapperElement().addEventListener('mousedown', (e) => {
                if (e.detail >= 3 && _tagContentSelected) {
                    // Block CodeMirror's line/paragraph selection
                    e.preventDefault();
                    e.stopPropagation();
                    // Re-apply tag content selection (it was set by dblclick)
                    setTimeout(() => { _selectTagContentAtCursor(); }, 0);
                }
            }, true); // capture phase — fires before CodeMirror's handler

            editor.getWrapperElement().addEventListener('dblclick', () => {
                setTimeout(() => {
                    _tagContentSelected = _selectTagContentAtCursor();
                }, 10);
            });
            editor.on('cursorActivity', () => {
                if (isSelectionFromDesign) return;
                if (isSyncFromDesign) return;
                if (isApplyingUndoRedo) return;
                // Always clear design-click highlights when user moves cursor in code
                if (syncSelectionMark) { syncSelectionMark.clear(); syncSelectionMark = null; }
                if (_imgClickMark) { _imgClickMark.clear(); _imgClickMark = null; }
                _tagContentSelected = false;
                // Daca cursorul este in interiorul zonei SASA, nu incercam sa facem
                // „sync selection” catre Design (altfel se comporta ca un FIND si sare).
                if (isCursorInsideSasa()) return;
                // If the user manually moves the cursor/clicks while SASA is active,
                // deactivate the SASA selection (the initial setSelection inside
                // selectSasaRegion() fires cursorActivity BEFORE sasaSelectionActive
                // is set to true, so this won't interfere with the initial selection).
                if (sasaSelectionActive) deactivateSasa();
                // In afara zonei SASA putem sincroniza selectia spre Design.
                // IMPORTANT: Nu sincronizam cat timp user-ul tine click apasat 
                // pentru a trage o selectie in mod cursiv, altfel scroll-ul 
                // din Design va rupe focus-ul si va arunca selectia din Code-Mirror in jos.
                if (!sasaSelectionActive && !_isCodeDragging) {
                    syncSelectionToDesignFromCode();
                }
            });

            window.addEventListener('keydown', e => {
                const activeEl = document.activeElement;
                const activeTag = activeEl && activeEl.tagName ? activeEl.tagName.toLowerCase() : '';
                const isPlainInput = activeTag === 'input' || activeTag === 'textarea' || activeTag === 'select';
                if ((e.ctrlKey || e.metaKey) && !isPlainInput &&
                    (e.key === 'z' || e.key === 'Z') && !e.shiftKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    doUndoFromDesign();
                    return;
                }
                if ((e.ctrlKey || e.metaKey) && !isPlainInput &&
                    (e.key === 'y' || e.key === 'Y' ||
                        (e.shiftKey && (e.key === 'z' || e.key === 'Z')))) {
                    e.preventDefault();
                    e.stopPropagation();
                    doRedoFromDesign();
                    return;
                }
                if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key === 's') {
                    e.preventDefault();
                    saveFile();
                }
                // F3 / Shift+F3 — Find Next / Find Prev (only when Find dialog is open)
                if (e.key === 'F3') {
                    const dlg = document.getElementById('findReplaceDialog');
                    if (dlg && dlg.classList.contains('visible')) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (e.shiftKey) findPrev(); else findNext();
                        return;
                    }
                }
                // Ctrl+H — open Find & Replace
                if ((e.ctrlKey || e.metaKey) && (e.key === 'h' || e.key === 'H')) {
                    e.preventDefault();
                    toggleFindReplace();
                }
                // Ctrl+F — open Find & Replace (find mode)
                if ((e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F') && !e.shiftKey) {
                    e.preventDefault();
                    toggleFindReplace();
                }
                // Escape — close Find & Replace / Diacritics popup if open
                if (e.key === 'Escape') {
                    const diacDlg = document.getElementById('diacPopup');
                    if (diacDlg && diacDlg.classList.contains('visible')) {
                        closeDiacPopup();
                    }
                    const dlg = document.getElementById('findReplaceDialog');
                    if (dlg && dlg.classList.contains('visible')) {
                        closeFindReplace();
                    }
                }
            }, true);
            setViewMode('design');
            initSplitter();
        }

        function setViewMode(mode) {
            viewMode = mode;
            const split = document.getElementById('splitContainer');
            if (!split) return;
            // resetam latimile custom cand schimbam modul
            const leftPane = split.querySelector('.editor-pane');
            const rightPane = split.querySelector('.preview-pane');
            if (leftPane && rightPane) {
                leftPane.style.flex = '';
                rightPane.style.flex = '';
            }
            split.classList.remove('mode-code', 'mode-split', 'mode-design');
            if (mode === 'code') split.classList.add('mode-code');
            else if (mode === 'design') split.classList.add('mode-design');
            else split.classList.add('mode-split');
            const btnCode = document.getElementById('btnViewCode');
            const btnSplit = document.getElementById('btnViewSplit');
            const btnDesign = document.getElementById('btnViewDesign');
            if (btnCode && btnSplit && btnDesign) {
                btnCode.classList.toggle('active', mode === 'code');
                btnSplit.classList.toggle('active', mode === 'split');
                btnDesign.classList.toggle('active', mode === 'design');
            }
            // CodeMirror needs refresh when becoming visible after being hidden
            if (mode !== 'design' && typeof editor !== 'undefined' && editor) {
                setTimeout(() => editor.refresh(), 20);
            }
        }

        function initSplitter() {
            const divider = document.getElementById('splitDivider');
            const split = document.getElementById('splitContainer');
            if (!divider || !split) return;
            let dragging = false;
            let startX = 0;
            let startLeftWidth = 0;
            const leftPane = split.querySelector('.editor-pane');
            const rightPane = split.querySelector('.preview-pane');
            let overlay = split.querySelector('.split-overlay');
            if (!overlay) {
                overlay = document.createElement('div');
                overlay.className = 'split-overlay';
                split.appendChild(overlay);
            }
            divider.addEventListener('mousedown', e => {
                if (viewMode !== 'split') return;
                dragging = true;
                startX = e.clientX;
                startLeftWidth = leftPane.getBoundingClientRect().width;
                document.body.style.cursor = 'col-resize';
                overlay.style.display = 'block';
                e.preventDefault();
            });
            overlay.addEventListener('mousemove', e => {
                if (!dragging) return;
                const dx = e.clientX - startX;
                const totalWidth = split.getBoundingClientRect().width;
                let newLeft = Math.max(150, Math.min(totalWidth - 150, startLeftWidth + dx));
                const percent = (newLeft / totalWidth) * 100;
                leftPane.style.flex = '0 0 ' + percent + '%';
                rightPane.style.flex = '1 0 auto';
            });
            const stopDrag = () => {
                if (!dragging) return;
                dragging = false;
                document.body.style.cursor = '';
                overlay.style.display = 'none';
            };
            overlay.addEventListener('mouseup', stopDrag);
            window.addEventListener('mouseup', stopDrag);
        }

        function refreshClassListFromCode() {
            if (!editor) return;
            const code = editor.getValue();
            const re = /class\s*=\s*["']([^"']+)["']/gi;
            const set = new Set();
            let m;
            while ((m = re.exec(code)) !== null) {
                const parts = m[1].split(/\s+/);
                parts.forEach(c => {
                    if (c) set.add(c);
                });
            }
            cssClasses = Array.from(set).sort((a, b) => a.localeCompare(b, 'ro'));
            const sel = document.getElementById('propClass');
            if (!sel) return;
            sel.innerHTML = '<option value=\"\">(fara)</option>';
            cssClasses.forEach(c => {
                const opt = document.createElement('option');
                opt.value = c;
                opt.textContent = c;
                sel.appendChild(opt);
            });
        }

        // Style the class combo options with colors/sizes from the CSS in the preview iframe.
        // Called ONLY after preview is fully loaded (from makeDesignEditable), never during
        // undo/redo/sync flows, to avoid manipulating the iframe body at unsafe times.
        function styleClassOptions() {
            const sel = document.getElementById('propClass');
            if (!sel) return;
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            const win = iframe && iframe.contentWindow;
            if (!doc || !doc.body || !win) return;

            let hiddenSpan = doc.createElement('span');
            hiddenSpan.style.visibility = 'hidden';
            hiddenSpan.style.position = 'absolute';
            hiddenSpan.style.whiteSpace = 'nowrap';
            hiddenSpan.innerHTML = 'Test';
            doc.body.appendChild(hiddenSpan);

            let defaultBg = '#ffffff';
            const bodyComp = win.getComputedStyle(doc.body);
            if (bodyComp && bodyComp.backgroundColor && bodyComp.backgroundColor !== 'rgba(0, 0, 0, 0)' && bodyComp.backgroundColor !== 'transparent') {
                defaultBg = bodyComp.backgroundColor;
            }

            // Style each <option> in the combo
            const options = sel.querySelectorAll('option');
            for (let i = 0; i < options.length; i++) {
                const opt = options[i];
                if (!opt.value) continue; // skip "(fara)"
                hiddenSpan.className = opt.value;
                const comp = win.getComputedStyle(hiddenSpan);
                if (comp) {
                    opt.style.backgroundColor = defaultBg;
                    if (comp.color && comp.color !== 'rgba(0, 0, 0, 0)' && comp.color !== 'transparent') {
                        opt.style.color = comp.color;
                    } else {
                        opt.style.color = '#000000';
                    }
                    if (comp.fontSize) {
                        opt.style.fontSize = comp.fontSize;
                    }
                    if (comp.fontWeight) {
                        opt.style.fontWeight = comp.fontWeight;
                    }
                    if (comp.backgroundColor && comp.backgroundColor !== 'rgba(0, 0, 0, 0)' && comp.backgroundColor !== 'transparent') {
                        opt.style.backgroundColor = comp.backgroundColor;
                    }
                }
            }

            hiddenSpan.parentNode.removeChild(hiddenSpan);
        }

        async function refreshList(dir) {
            if (dir === undefined) dir = currentDir;
            currentDir = dir;
            const cont = document.getElementById('fileList');
            cont.textContent = 'Se incarca...';
            try {
                const url = '?action=list' + (dir ? '&dir=' + encodeURIComponent(dir) : '');
                const res = await fetch(url);
                const data = await res.json();
                renderList(data, dir);
            } catch (e) {
                cont.textContent = 'Eroare la listare';
            }
        }

        function renderList(items, dir) {
            const cont = document.getElementById('fileList');
            cont.innerHTML = '';
            if (dir) {
                const back = document.createElement('div');
                back.className = 'dir';
                back.style.cursor = 'pointer';
                back.style.color = '#60a5fa';
                back.innerHTML = '<span>&#8592; Inapoi</span>';
                const parent = dir.includes('/') ? dir.split('/').slice(0, -1).join('/') : '';
                back.onclick = () => refreshList(parent);
                cont.appendChild(back);
            }
            const dirLabel = document.createElement('div');
            dirLabel.className = 'dir';
            dirLabel.innerHTML = '<span>' + (dir || '(root)') + '</span>';
            cont.appendChild(dirLabel);

            const sorted = [...items].sort((a, b) => {
                if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
                return a.name.localeCompare(b.name);
            });
            sorted.forEach(it => {
                if (it.type === 'dir') {
                    const el = document.createElement('div');
                    el.className = 'file';
                    el.style.color = '#60a5fa';
                    el.innerHTML = '<span>&#128193; ' + it.name + '</span>';
                    el.onclick = () => refreshList(it.path);
                    cont.appendChild(el);
                } else {
                    const el = document.createElement('div');
                    el.className = 'file';
                    el.dataset.path = it.path;
                    el.innerHTML = '<span>' + it.name + '</span><span class="path">' + it.ext + '</span>';
                    el.onclick = () => openFile(it.path, el);
                    cont.appendChild(el);
                }
            });
        }

        // Butonul NEW din fereastra de start: deschide pagina model si afiseaza un memento.
        // Template-ul nu se salveaza niciodata peste el: la Save, pagina se scrie intr-un fisier nou
        // numit dupa CANONICAL (ex. .../bebe-new-go.html -> bebe-new-go.html), iar model-new.html ramane neatins.
        // Fara extensie intentionat: daca ajunge din greseala pe server, nu e servit ca pagina .html.
        var NEW_MODEL_PATH = 'e:/Carte/BB/17 - Site Leadership/Principal/ro/model-new';
        function normTplPath(p) { return String(p || '').replace(/\\/g, '/').replace(/\/+/g, '/').toLowerCase(); }
        function isTemplatePath(p) { return !!p && normTplPath(p) === normTplPath(NEW_MODEL_PATH); }
        async function openNewFromModel() {
            await openFile(NEW_MODEL_PATH);
            if (isTemplatePath(currentFile)) showModelReminder();
        }
        async function resolveTemplateSaveTarget(html) {
            var tplName = NEW_MODEL_PATH.split('/').pop();
            var link = String(html || '').match(/<link\b[^>]*\brel\s*=\s*["']canonical["'][^>]*>/i);
            var href = link ? (link[0].match(/\bhref\s*=\s*["']([^"']*)["']/i) || [])[1] : '';
            var name = '';
            if (href) {
                name = href.split('#')[0].split('?')[0].replace(/\/+$/, '').split('/').pop() || '';
                try { name = decodeURIComponent(name); } catch (e) { }
            }
            var tplBase = tplName.replace(/\.html?$/i, '').toLowerCase();
            if (!name || !/\.html?$/i.test(name) || name.replace(/\.html?$/i, '').toLowerCase() === tplBase) {
                showErrorPopup(
                    'Acesta este TEMPLATE-ul (' + tplName + ') si nu poate fi salvat peste el.\n\n' +
                    'Schimba mai intai CANONICAL LINK, de exemplu:\n' +
                    '<link rel="canonical" href="https://neculaifantanaru.com/pagina-noua.html" />\n\n' +
                    'La Save, pagina se va salva ca fisier nou cu numele din canonical.');
                return null;
            }
            var dir = NEW_MODEL_PATH.replace(/\/[^\/]*$/, '');
            var input = window.prompt(
                'Pagina noua (din template) va fi salvata ca:\n' +
                '(poti schimba folderul daca vrei)', dir + '/' + name);
            if (input === null) { toast('Salvare anulata'); return null; }
            input = input.trim().replace(/\\/g, '/');
            if (!input) { toast('Salvare anulata'); return null; }
            if (isTemplatePath(input)) {
                showErrorPopup('Nu poti salva peste template-ul ' + tplName + '. Alege alt nume.');
                return null;
            }
            try {
                var chk = await (await fetch('?action=load&file=' + encodeURIComponent(input))).json();
                if (chk && chk.ok && !window.confirm('Fisierul exista deja:\n' + input + '\n\nIl suprascrii?')) {
                    toast('Salvare anulata');
                    return null;
                }
            } catch (eChk) { }
            return input;
        }
        function showModelReminder() {
            var old = document.getElementById('modelReminderPopup');
            if (old) old.remove();
            var box = document.createElement('div');
            box.id = 'modelReminderPopup';
            box.style.cssText = 'position:fixed;inset:0;z-index:100000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.45)';
            box.innerHTML =
                '<div style="background:#1f2937;border:2px solid #facc15;border-radius:10px;padding:24px 32px;max-width:520px;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.6)">' +
                '<div style="font-size:22px;font-weight:700;color:#facc15;margin-bottom:10px"><i class="fas fa-exclamation-triangle"></i> Atentie</div>' +
                '<div style="font-size:18px;color:#eee;margin-bottom:20px">Schimba <b>TITLUL</b> si <b>CANONICAL LINK</b></div>' +
                '<button class="btn btn-primary" style="font-size:16px;padding:8px 28px">OK</button></div>';
            box.addEventListener('click', function (e) {
                if (e.target === box || e.target.tagName === 'BUTTON') box.remove();
            });
            document.body.appendChild(box);
            box.querySelector('button').focus();
        }

        async function openFile(path, el) {
            // Lista mare cu toate datele duplicate e doar pentru pornire (fără HTML deschis);
            // rămâne deschisă doar când fișierul e deschis chiar din link-ul ei.
            if (!window._dateDupOpeningFromList && typeof closeDateDuplicatesDialog === 'function') {
                closeDateDuplicatesDialog('all');
                const ld = document.getElementById('linkDuplicatesDialog');
                if (ld) ld.remove();
            }
            // Check if file is already open in a tab
            var existing = findTabByPath(path);
            if (existing) {
                switchToTab(existing.id);
                hideOverlay();
                return;
            }
            try {
                toast('Se deschide...');
                const res = await fetch('?action=load&file=' + encodeURIComponent(path));
                const data = await res.json();
                if (!data.ok) { toast('Eroare: ' + data.error); return; }

                // Close browser panel if open (switching to a file tab)
                if (browserPanelOpen) {
                    document.getElementById('browserPanel').style.display = 'none';
                    document.getElementById('splitContainer').style.display = '';
                    browserPanelOpen = false;
                    var _bg = document.getElementById('btnBrowserTab');
                    if (_bg) _bg.classList.remove('active');
                }
                // Deactivate CROP and SELECT modes when opening a new file
                if (typeof deactivateSasa === 'function') deactivateSasa();
                if (typeof deactivateCrop === 'function' && typeof cropHighlightActive !== 'undefined' && cropHighlightActive) deactivateCrop();

                // Save current tab state before creating new one
                saveCurrentTabState();

                var label = getTabLabel(data.content, data.file);
                var fullT = getTabFullTitle(data.content, data.file);
                var tab = createTabState({
                    filePath: data.file,
                    fileName: shortName(data.file),
                    tabLabel: label,
                    fullTitle: fullT,
                    editorContent: data.content,
                    originalContent: data.content,
                    viewMode: 'design',
                    lastPreviewHadBody: /<body\b/i.test(data.content)
                });
                tabs.push(tab);
                    setTimeout(() => checkArticleIdentity(tab), 0);
                    scheduleIndexOrderCheck();
                activeTabId = tab.id;

                currentFile = data.file;
                addToRecentFiles(currentFile);
                setViewMode('design');
                _isRestoringTab = true;
                isSyncFromDesign = true;
                editor.setValue(data.content);
                isSyncFromDesign = false;
                _isRestoringTab = false;
                editor.getDoc().clearHistory();
                const aiFixedOpen = cleanAiStyleInOpenedTab(tab, data.file);
                lastPreviewHadBody = tab.lastPreviewHadBody;
                clearTimeout(previewDebounceTimer);
                previewDebounceTimer = null;
                document.querySelectorAll('.file').forEach(f => f.classList.remove('active'));
                if (el) el.classList.add('active');
                updatePreview();
                isDirty = false;
                designUndoStack = [];
                designRedoStack = [];
                lastDesignSnapshot = null;
                markTabDirtyAfterAiCleanup(tab, aiFixedOpen);

                setViewMode('design');
                renderTabs();
                hideOverlay();
                refreshTabLinkedCategory(tab);
                try {
                    await reconcileLinkedCategoryTeaserWithArticle(tab, tab.editorContent, { context: 'open', silent: true });
                } catch (eSync) { console.error(eSync); }
            } catch (e) {
                toast('Eroare la deschidere: ' + e.message);
            }
        }

        async function saveFile() {
            if (!editor) return;
            if (typeof flushPendingDesignSync === 'function') flushPendingDesignSync(true);
            if (!currentFile) {
                const hint =
                    'Acest fisier a fost deschis prin Drag & Drop si nu are o cale cunoscuta pe disc.\n\n' +
                    'Scrie mai jos CALEA COMPLETA unde vrei sa fie salvat,\n' +
                    'de exemplu:\n' +
                    'e:/Carte/BB/17 - Site Leadership/Principal/en/the-feelings-of-an-artist-fascinated-by-the-meticulousness-of-his-passion.html';
                const input = window.prompt(hint, '');
                if (!input) {
                    showErrorPopup(
                        'Salvarea a fost anulata.\n\n' +
                        'Motiv: fisierul nu are o cale cunoscuta pe disc, iar nicio cale noua nu a fost furnizata.\n\n' +
                        'Poti deschide fisierul prin campul de cale din ecranul initial\n' +
                        'sau poti apasa din nou Save si sa introduci o cale completa.');
                    return;
                }
                const trimmed = input.trim();
                if (!trimmed) {
                    showErrorPopup('Calea introdusa este goala. Te rog sa incerci din nou cu o cale completa catre fisier.');
                    return;
                }
                currentFile = trimmed;
            }
            var savedFromTemplate = null, templateWritten = false;
            if (isTemplatePath(currentFile)) {
                var tplTarget = await resolveTemplateSaveTarget(editor.getValue());
                if (!tplTarget) return;
                savedFromTemplate = currentFile;
                currentFile = tplTarget;
            }
            try {
                var rawContent = editor.getValue();
                var contentToSave = rawContent;
                if (isCurrentFileHtml() && typeof removePasteWhitespaceNormalSpansFromHtml === 'function') {
                    contentToSave = removePasteWhitespaceNormalSpansFromHtml(contentToSave);
                }
                if (isCurrentFileHtml() && typeof cleanAiStyledSpansInHtml === 'function') {
                    contentToSave = stripFindMarksFromHtml(contentToSave);
                    contentToSave = cleanAiStyledSpansInHtml(contentToSave);
                }
                if (isCurrentFileHtml() && typeof removeOrphanClosingSpansFromParagraphs === 'function') {
                    contentToSave = removeOrphanClosingSpansFromParagraphs(contentToSave);
                }
                if (isCurrentFileHtml() && typeof normalizeTextParagraphInlineFormatting === 'function') {
                    contentToSave = normalizeTextParagraphInlineFormatting(contentToSave);
                }
                if (isCurrentFileHtml() && typeof joinSasaParagraphClosingTags === 'function') {
                    contentToSave = joinSasaParagraphClosingTags(contentToSave);
                }
                if (isCurrentFileHtml() && typeof applySasaTeaserToMetaDescription === 'function') {
                    contentToSave = applySasaTeaserToMetaDescription(contentToSave);
                }
                if (isCurrentFileHtml() && typeof applyH1ToPageTitles === 'function') {
                    contentToSave = applyH1ToPageTitles(contentToSave);
                }
                var protectedTail = null;
                if (activeTabId) {
                    for (var _sti = 0; _sti < tabs.length; _sti++) {
                        if (tabs[_sti].id === activeTabId) {
                            protectedTail = tabs[_sti].protectedBodyScriptTail;
                            break;
                        }
                    }
                }
                if (protectedTail && typeof applyProtectedScriptsToFullHtml === 'function') {
                    contentToSave = applyProtectedScriptsToFullHtml(contentToSave, protectedTail);
                }
                const body = new URLSearchParams();
                body.append('file', currentFile);
                body.append('content', contentToSave);
                const res = await fetch('?action=save', { method: 'POST', body });
                const data = await res.json();
                if (!data.ok) {
                    if (savedFromTemplate) currentFile = savedFromTemplate;
                    toast('Eroare la salvare: ' + data.error);
                    return;
                }
                if (savedFromTemplate) { templateWritten = true; addToRecentFiles(currentFile); }
                // Dacă doar serverul a sincronizat meta (client vechi / cache), reîncarcă fișierul salvat
                if (data.metaSynced && contentToSave === rawContent && data.file) {
                    try {
                        const resReload = await fetch('?action=load&file=' + encodeURIComponent(data.file));
                        const reloadData = await resReload.json();
                        if (reloadData.ok && reloadData.content) {
                            contentToSave = reloadData.content;
                        }
                    } catch (eReload) { /* păstrăm contentToSave */ }
                }
                if (contentToSave !== rawContent) {
                    const codeScroll = editor.getScrollInfo();
                    const codeSelections = editor.listSelections();
                    const wasSyncFromDesign = isSyncFromDesign;
                    isSyncFromDesign = true;
                    try {
                        editor.operation(() => {
                            editor.setValue(contentToSave);
                            editor.setSelections(codeSelections, undefined, { scroll: false });
                            editor.scrollTo(codeScroll.left, codeScroll.top);
                        });
                    } finally {
                        isSyncFromDesign = wasSyncFromDesign;
                    }
                    // Save-time normalization updates the source only. Keep the live Design
                    // DOM, selection and scroll intact; the clean baseline is recorded below.
                }
                if (data.metaSynced || contentToSave !== rawContent) {
                    toast('Meta description și titluri pagină actualizate din articol (SASA-1 / H1).');
                }
                isDirty = false;
                if (activeTabId) {
                    var tab = null;
                    for (var i = 0; i < tabs.length; i++) { if (tabs[i].id === activeTabId) { tab = tabs[i]; break; } }
                    if (tab) {
                        tab.isDirty = false;
                        tab.filePath = currentFile;
                        tab.fileName = shortName(currentFile);
                        var _prevSavedContent = tab.originalContent;
                        tab.originalContent = contentToSave;
                        tab.originalContentNorm = normalizeHtmlForCompare(tab.originalContent);
                        tab.editorContent = tab.originalContent;
                        var _newTail = extractProtectedBodyScriptTail(contentToSave);
                        if (_newTail) tab.protectedBodyScriptTail = _newTail;
                        lastDesignSnapshot = getDesignBodyHtml();
                        tab.lastDesignSnapshot = lastDesignSnapshot;
                        // Save always establishes a new clean baseline. Keep the undo/redo
                        // history, but compare future Design syncs with what was just saved,
                        // not with the version that was clean before the edit.
                        designCleanCode = contentToSave;
                        designCleanBodyHtml = lastDesignSnapshot;
                        tab.designCleanCode = designCleanCode;
                        tab.designCleanBodyHtml = designCleanBodyHtml;
                        tab.designUndoStack = designUndoStack.slice();
                        tab.designRedoStack = designRedoStack.slice();
                        tab.undoHistory = editor.getDoc().getHistory();
                        tab.tabLabel = getTabLabel(contentToSave, currentFile);
                        tab.fullTitle = getTabFullTitle(contentToSave, currentFile);
                        removeTabBackup(tab.id);
                        if (typeof syncLinkedCategoryDescriptionAfterArticleSave === 'function' && tab.type !== 'browser' &&
                            currentFile && isCurrentFileHtml()) {
                            refreshTabLinkedCategory(tab);
                            await syncLinkedCategoryDescriptionAfterArticleSave(tab, tab.originalContent);
                            await syncArticleBlockToCategoryAndIndexAfterSave(currentFile, tab.originalContent);
                            // Pagină de categorie / index: data schimbată la un articol → și în articol
                            try { await syncListDatesToArticlesAfterSave(currentFile, _prevSavedContent, tab.originalContent); } catch (e) { console.error(e); }
                            // Articol din ro/ → aceeași dată și în traducerea din en/ (articol + categorie + index)
                            if (!isHtmlCategoryListingPage(tab.originalContent)) {
                                try { await syncDateToEnglishCounterpart(currentFile, tab.originalContent); } catch (e) { console.error(e); }
                                // După Save: dacă data articolului e deja a altui articol → fereastra cu
                                // propuneri, imediat (și pentru un articol nou, copiat din altul)
                                try { runCurrentDateDuplicateCheck(currentFile, true, true); } catch (e) { console.error(e); }
                            }
                        }
                        tab.categorySyncDescriptionBaseline = getCategorySyncDescriptionFromArticleHtml(tab.originalContent);
                        updateTabPresentation(tab);
                    }
                }
                // Silent save: NO preview reload — avoids page flicker
                // Preview is already up-to-date (changes are synced live)
                toast('Salvat!');
                scheduleRecentArticlesCheck(2500);
            } catch (e) {
                if (savedFromTemplate && !templateWritten) currentFile = savedFromTemplate;
                toast('Eroare la salvare');
            }
        }

        function isCurrentFileHtml() {
            if (!currentFile) return true;
            if (isTemplatePath(currentFile)) return true; // template-ul NEW e HTML, desi n-are extensie
            const n = currentFile.toLowerCase();
            return n.endsWith('.html') || n.endsWith('.htm');
        }

        // Preserve original tag names when the browser normalises equivalent
        // inline tags during contentEditable editing (e.g. <i>→<em>, <b>→<strong>).
        // Compares old body HTML (from code editor) with new innerHTML (from design
        // panel) and restores the original tag variant wherever the browser swapped it.
        function preserveEquivTags(oldBodyContent, newBodyContent) {
            var EQUIV = {'b':'strong','strong':'b'};
            // Extract all tags with their positions
            function extractTags(html) {
                var result = [];
                var re = /<(\/?)([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g;
                var m;
                while ((m = re.exec(html)) !== null) {
                    result.push({
                        index: m.index,
                        length: m[0].length,
                        closing: m[1] === '/',
                        name: m[2].toLowerCase(),
                        attrs: m[3],
                        raw: m[0]
                    });
                }
                return result;
            }
            var oldTags = extractTags(oldBodyContent);
            var newTags = extractTags(newBodyContent);
            // Keep only tags that participate in equiv-pairs for alignment
            var oldEquiv = oldTags.filter(function(t) { return !!EQUIV[t.name]; });
            var newEquiv = newTags.filter(function(t) { return !!EQUIV[t.name]; });
            var replacements = [];
            var oi = 0;
            for (var ni = 0; ni < newEquiv.length && oi < oldEquiv.length; ni++) {
                var nt = newEquiv[ni];
                var ot = oldEquiv[oi];
                // Tags must match in open/close direction and be from the same equiv pair
                if (nt.closing === ot.closing &&
                    (nt.name === ot.name || EQUIV[nt.name] === ot.name)) {
                    if (nt.name !== ot.name) {
                        // Browser swapped the tag name — restore original
                        var prefix = nt.closing ? '</' : '<';
                        replacements.push({
                            index: nt.index,
                            length: nt.raw.length,
                            replacement: prefix + ot.name + nt.attrs + '>'
                        });
                    }
                    oi++;
                }
                // If they don't match at all (different pair, e.g. i vs b) we leave nt
                // as-is and try the next newEquiv against the same oldEquiv position.
            }
            if (replacements.length === 0) return newBodyContent;
            // Apply in reverse so earlier offsets stay valid
            var result = newBodyContent;
            for (var r = replacements.length - 1; r >= 0; r--) {
                var rep = replacements[r];
                result = result.substring(0, rep.index) + rep.replacement +
                         result.substring(rep.index + rep.length);
            }
            return result;
        }

        // Collapse runs of spaces/&nbsp; into a single space ONLY in the text node
        // where the cursor is. Preserves the caret position so the user can keep typing.
        function collapseSpacesInDesignDOM(doc) {
            if (!doc || !doc.body) return;
            const win = doc.defaultView;
            const sel = win && win.getSelection();
            if (!sel || sel.rangeCount === 0 || !sel.isCollapsed) return;
            const cursorNode = sel.getRangeAt(0).startContainer;
            let cursorOffset = sel.getRangeAt(0).startOffset;
            // Only process the text node where the cursor is
            if (!cursorNode || cursorNode.nodeType !== Node.TEXT_NODE) return;
            // Skip <pre>, <code>, <script>, <style> contents
            const parent = cursorNode.parentNode;
            if (parent && /^(PRE|CODE|SCRIPT|STYLE|TEXTAREA)$/i.test(parent.tagName)) return;
            const orig = cursorNode.nodeValue;
            // Replace &nbsp; (\u00A0) with regular space, then collapse 2+ spaces into one
            const cleaned = orig.replace(/[\u00A0]/g, ' ').replace(/ {2,}/g, ' ');
            if (cleaned !== orig) {
                // Adjust cursor offset: count how many chars were removed before cursor
                if (cursorOffset > 0) {
                    let newOffset = 0, origIdx = 0;
                    for (let ci = 0; ci < cleaned.length && origIdx < cursorOffset; ci++) {
                        while (origIdx < orig.length && origIdx < cursorOffset &&
                               (orig[origIdx] === ' ' || orig[origIdx] === '\u00A0') &&
                               ci < cleaned.length && cleaned[ci] === ' ' &&
                               origIdx + 1 < orig.length &&
                               (orig[origIdx + 1] === ' ' || orig[origIdx + 1] === '\u00A0')) {
                            origIdx++;
                        }
                        origIdx++;
                        newOffset = ci + 1;
                    }
                    cursorOffset = Math.min(newOffset, cleaned.length);
                }
                cursorNode.nodeValue = cleaned;
                // Restore caret
                try {
                    const safeOffset = Math.min(cursorOffset, cursorNode.nodeValue.length);
                    const range = doc.createRange();
                    range.setStart(cursorNode, safeOffset);
                    range.setEnd(cursorNode, safeOffset);
                    sel.removeAllRanges();
                    sel.addRange(range);
                } catch (e) {}
            }
        }

        // Remove accidental boundary <br> placeholders in normal paragraphs after Enter/Backspace.
        // Keep internal/manual line breaks untouched; only trim leading/trailing <br> when text exists.
        function cleanupParagraphBoundaryBrArtifacts(doc) {
            if (!doc || !doc.body) return;
            const ps = doc.querySelectorAll('p.text_obisnuit, p.text_obisnuit2');
            for (let i = 0; i < ps.length; i++) {
                const p = ps[i];
                const hasMeaningfulText = (p.textContent || '').replace(/\u200B/g, '').trim().length > 0;
                if (!hasMeaningfulText) continue;
                // Trim leading boundary <br> (preserve user-typed spaces)
                for (;;) {
                    const fc = p.firstChild;
                    if (!fc) break;
                    if (fc.nodeType === Node.ELEMENT_NODE && fc.nodeName === 'BR') { p.removeChild(fc); continue; }
                    break;
                }
                // Trim trailing boundary <br> (preserve user-typed spaces)
                for (;;) {
                    const lc = p.lastChild;
                    if (!lc) break;
                    if (lc.nodeType === Node.ELEMENT_NODE && lc.nodeName === 'BR') { p.removeChild(lc); continue; }
                    break;
                }
            }
        }

        function normalizeBlockWrappedInlineFormat(html, tagName) {
            var tagPattern = tagName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            var wrappedBlocksRe = new RegExp('<' + tagPattern + '\\b[^>]*>\\s*((?:<p\\b[^>]*>[\\s\\S]*?<\\/p>\\s*)+)<\\/' + tagPattern + '>', 'gi');
            var changed = false;
            var out = String(html || '').replace(wrappedBlocksRe, function (_match, blocksHtml) {
                changed = true;
                return blocksHtml.replace(/<p\b([^>]*)>([\s\S]*?)<\/p>/gi, function (_p, attrs, inner) {
                    var trimmed = String(inner || '').trim();
                    if (!trimmed) return '';
                    var alreadyWrappedRe = new RegExp('^<' + tagPattern + '\\b[^>]*>[\\s\\S]*<\\/' + tagPattern + '>$', 'i');
                    if (alreadyWrappedRe.test(trimmed)) {
                        return '<p' + attrs + '>' + inner + '</p>';
                    }
                    return '<p' + attrs + '><' + tagName + '>' + inner + '</' + tagName + '></p>';
                });
            });
            if (!changed) return out;

            // Remove the empty paragraphs that contentEditable creates at the
            // selection boundaries when it wraps block elements in <em>/<strong>.
            var emptyNormalP = '[\\t ]*<p\\b[^>]*\\bclass\\s*=\\s*["\'][^"\']*\\btext_obisnuit2?\\b[^"\']*["\'][^>]*>\\s*(?:<br\\s*\\/?>)?\\s*<\\/p>[\\t ]*';
            var firstWrapped = '(<p\\b[^>]*>\\s*<' + tagPattern + '\\b[^>]*>)';
            var lastWrapped = '(<\\/' + tagPattern + '>\\s*<\\/p>)';
            out = out.replace(new RegExp('(^|\\n)' + emptyNormalP + '\\s*' + firstWrapped, 'gi'), '$1$2');
            out = out.replace(new RegExp(lastWrapped + '\\s*' + emptyNormalP + '(?=\\n|$)', 'gi'), '$1');
            return out;
        }

        // Fix invalid markup produced when a block paragraph gets wrapped in a span
        // instead of having its class changed: <span class="text_obisnuit2"><p class="text_obisnuit">…</p></span>
        // → <p class="text_obisnuit2">…</p>
        function normalizeSpanWrappedParagraphClass(html) {
            return String(html || '').replace(
                /<span\b[^>]*\bclass\s*=\s*["']([^"']+)["'][^>]*>\s*<p\b([^>]*)>([\s\S]*?)<\/p>\s*<\/span>/gi,
                function (match, spanClass, pAttrs, inner) {
                    var mainClass = String(spanClass || '').trim().split(/\s+/)[0];
                    if (!mainClass) return match;
                    if (typeof cssClasses !== 'undefined' && cssClasses.length && cssClasses.indexOf(mainClass) === -1) {
                        return match;
                    }
                    var newAttrs = String(pAttrs || '');
                    if (/\bclass\s*=/i.test(newAttrs)) {
                        newAttrs = newAttrs.replace(/\bclass\s*=\s*["'][^"']*["']/i, 'class="' + mainClass + '"');
                    } else {
                        newAttrs = ' class="' + mainClass + '"' + newAttrs;
                    }
                    return '<p' + newAttrs + '>' + inner + '</p>';
                }
            );
        }

        function removeOrphanClosingSpansFromParagraphs(html) {
            return String(html || '').replace(
                /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2?\b[^"']*["'][^>]*>)([\s\S]*?)(<\/p>)/gi,
                function (_match, pOpen, inner, pClose) {
                    let depth = 0;
                    inner = String(inner || '').replace(/<\/?span\b[^>]*>/gi, function (tag) {
                        if (/^<\s*span\b/i.test(tag)) {
                            depth++;
                            return tag;
                        }
                        if (depth > 0) {
                            depth--;
                            return tag;
                        }
                        return '';
                    });
                    return pOpen + inner + pClose;
                }
            );
        }

        function isPasteWhitespaceNormalStyle(styleValue) {
            var cleaned = String(styleValue || '')
                .replace(/\/\*[\s\S]*?\*\//g, '')
                .replace(/\s+/g, ' ')
                .replace(/\s*:\s*/g, ':')
                .replace(/\s*;\s*/g, ';')
                .replace(/;$/g, '')
                .trim()
                .toLowerCase();
            return cleaned === 'white-space:normal';
        }

        function removePasteWhitespaceNormalSpansFromHtml(html) {
            var out = String(html || '');
            var before;
            do {
                before = out;
                out = out.replace(/<span\b([^>]*)>([\s\S]*?)<\/span>/gi, function (match, attrs, inner) {
                    attrs = String(attrs || '');
                    var styleMatch = /\bstyle\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
                    if (!styleMatch) return match;
                    var styleValue = styleMatch[1] || styleMatch[2] || styleMatch[3] || '';
                    var restAttrs = attrs.replace(/\s*\bstyle\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/i, '').trim();
                    if (restAttrs || !isPasteWhitespaceNormalStyle(styleValue)) return match;
                    return inner;
                });
            } while (out !== before);
            return out;
        }

        function removePasteWhitespaceNormalSpansFromDom(root) {
            if (!root || !root.querySelectorAll) return false;
            var changed = false;
            Array.prototype.slice.call(root.querySelectorAll('span[style]')).forEach(function (span) {
                var attrs = Array.prototype.slice.call(span.attributes || []);
                var nonStyleAttrs = attrs.filter(function (attr) {
                    return String(attr.name || '').toLowerCase() !== 'style';
                });
                if (nonStyleAttrs.length || !isPasteWhitespaceNormalStyle(span.getAttribute('style'))) return;
                var parent = span.parentNode;
                if (!parent) return;
                while (span.firstChild) parent.insertBefore(span.firstChild, span);
                parent.removeChild(span);
                parent.normalize();
                changed = true;
            });
            return changed;
        }

        function normalizeFullTextObisnuit2SpanParagraphs(html) {
            html = removeOrphanClosingSpansFromParagraphs(html);
            return String(html || '').replace(
                /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit\b[^"']*["'][^>]*>)\s*<span\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2\b[^"']*["'][^>]*>([\s\S]*?)<\/span>\s*(<\/p>)/gi,
                function (_match, pOpen, inner, pClose) {
                    return pOpen + inner + pClose;
                }
            );
        }

        function normalizeTextParagraphInlineFormatting(html) {
            var out = String(html || '').replace(
                /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2?\b[^"']*["'][^>]*>)([\s\S]*?)(<\/p>)/gi,
                function (_match, pOpen, inner, pClose) {
                    var depths = {};
                    inner = String(inner || '').replace(/<i\s*>/gi, '<em>').replace(/<\/i>/gi, '</em>');
                    inner = inner.replace(/<\/?(em|strong|u)\b[^>]*>/gi, function (tag, name) {
                        name = String(name || '').toLowerCase();
                        depths[name] = depths[name] || 0;
                        if (new RegExp('^<\\s*' + name + '\\b', 'i').test(tag)) {
                            depths[name]++;
                            return tag;
                        }
                        if (depths[name] > 0) {
                            depths[name]--;
                            return tag;
                        }
                        return '';
                    });
                    var before;
                    do {
                        before = inner;
                        inner = inner
                            .replace(/<(em|strong|u)\b[^>]*>\s*<\/\1>/gi, '')
                            .replace(/<em>\s*<em>/gi, '<em>')
                            .replace(/<\/em>\s*<\/em>/gi, '</em>');
                    } while (inner !== before);
                    return pOpen + inner + pClose;
                }
            );
            return out.replace(
                /^[\t ]*<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2?\b[^"']*["'][^>]*>\s*(?:<(?:em|i|strong|b|u)\b[^>]*>\s*<\/(?:em|i|strong|b|u)>\s*)+<\/p>\s*\r?\n?/gmi,
                ''
            );
        }

        function joinSasaParagraphClosingTags(html) {
            return String(html || '').replace(
                /(<!--\s*SASA-1\s*-->)([\s\S]*?)(<!--\s*SASA-2\s*-->)/gi,
                function (_zoneMatch, marker1, zoneBody, marker2) {
                    zoneBody = zoneBody.replace(
                        /(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2?\b[^"']*["'][^>]*>)([\s\S]*?)(<\/p>)/gi,
                        function (_pMatch, pOpen, inner, pClose) {
                            inner = inner.replace(
                                /[\t ]*(?:\r?\n[\t ]*)+(?=(?:<\/(?:em|i|strong|b|u)>[\t ]*)*$)/i,
                                ''
                            );
                            return pOpen + inner + pClose;
                        }
                    );
                    return marker1 + zoneBody + marker2;
                }
            );
        }

        // ── Stil AI lipit (ChatGPT / Gemini) ──
        // Textul copiat din AI vine adesea ca
        //   <p class="text_obisnuit"><span style="font-family: …; font-size: 14px; font-weight: bold;">…</span></p>
        // Span-urile care au DOAR atributul style, aflate într-un <p>, sunt desfăcute:
        //  - bold pe tot paragraful  → <p class="text_obisnuit2">text</p>
        //  - bold doar pe o bucată   → <span class="text_obisnuit2">bucata</span>
        //  - italic / underline      → <em> / <u>
        //  - restul stilului (font, mărime, culoare…) se aruncă.
        function isAiStyledSpan(el) {
            if (!el || el.nodeName !== 'SPAN') return false;
            const attrs = el.attributes;
            return !!(attrs && attrs.length === 1 && String(attrs[0].name).toLowerCase() === 'style');
        }

        function paragraphTextIsAllInside(p, test) {
            const doc = p.ownerDocument;
            const walker = doc.createTreeWalker(p, NodeFilter.SHOW_TEXT, null);
            let n, any = false;
            while ((n = walker.nextNode())) {
                if (!/\S/.test(n.nodeValue.replace(/ /g, ' '))) continue;
                any = true;
                let a = n.parentNode, ok = false;
                while (a && a !== p) {
                    if (a.nodeType === 1 && test(a)) { ok = true; break; }
                    a = a.parentNode;
                }
                if (!ok) return false;
            }
            return any;
        }

        function canSwapParagraphToObisnuit2(p) {
            const cls = (p.getAttribute('class') || '').trim();
            return !cls || /^text_obisnuit2?$/.test(cls);
        }

        // În paragrafele de text (text_obisnuit / text_obisnuit2) formatarea e doar prin taguri curate:
        // <em>, <strong>, <u>… fără style (Chrome adaugă singur style="font-weight: normal;" pe <em>
        // când scrii/lipești peste text italic într-un paragraf bold).
        const FORMAT_WITH_STYLE = 'em[style],i[style],strong[style],b[style],u[style]';
        function stripStyleFromFormattingTags(p) {
            if (!p.classList || !(p.classList.contains('text_obisnuit') || p.classList.contains('text_obisnuit2'))) return false;
            const tags = p.querySelectorAll(FORMAT_WITH_STYLE);
            tags.forEach(el => el.removeAttribute('style'));
            return tags.length > 0;
        }

        function cleanAiStyledSpansInParagraph(p) {
            if (!p || !p.querySelectorAll) return false;
            const styledFormatting = stripStyleFromFormattingTags(p);
            const spans = Array.prototype.slice.call(p.querySelectorAll('span[style]')).filter(isAiStyledSpan);
            if (!spans.length) return styledFormatting;
            const doc = p.ownerDocument;
            const boldRe = /font-weight\s*:\s*(?:bold|bolder|[6-9]00)\b/i;
            const isBoldSpan = function (el) {
                return el.nodeName === 'SPAN' && spans.indexOf(el) !== -1 && boldRe.test(el.getAttribute('style') || '');
            };
            const wholeBold = canSwapParagraphToObisnuit2(p) && paragraphTextIsAllInside(p, isBoldSpan);
            const alreadyBold = wholeBold || (p.classList && p.classList.contains('text_obisnuit2'));
            // Interiorul întâi, ca să nu mutăm noduri dintr-un span deja scos.
            for (let i = spans.length - 1; i >= 0; i--) {
                const s = spans[i];
                const st = s.getAttribute('style') || '';
                const wrappers = [];
                if (!alreadyBold && boldRe.test(st)) {
                    const b = doc.createElement('span');
                    b.className = 'text_obisnuit2';
                    wrappers.push(b);
                }
                if (/font-style\s*:\s*(?:italic|oblique)/i.test(st) && !s.closest('em, i')) wrappers.push(doc.createElement('em'));
                if (/text-decoration[\w-]*\s*:[^;]*underline/i.test(st) && !s.closest('u')) wrappers.push(doc.createElement('u'));
                const parent = s.parentNode;
                if (!parent) continue;
                let target = parent, outer = null;
                if (wrappers.length) {
                    outer = wrappers[0];
                    for (let w = 1; w < wrappers.length; w++) wrappers[w - 1].appendChild(wrappers[w]);
                    target = wrappers[wrappers.length - 1];
                    parent.insertBefore(outer, s);
                }
                while (s.firstChild) {
                    if (outer) target.appendChild(s.firstChild);
                    else parent.insertBefore(s.firstChild, s);
                }
                parent.removeChild(s);
            }
            if (wholeBold) p.className = 'text_obisnuit2';
            p.normalize();
            return true;
        }

        function cleanAiStyledSpansInRoot(root) {
            if (!root || !root.querySelectorAll) return false;
            let changed = false;
            Array.prototype.slice.call(root.querySelectorAll('p')).forEach(function (p) {
                if (p.querySelector('span[style],' + FORMAT_WITH_STYLE) && cleanAiStyledSpansInParagraph(p)) changed = true;
            });
            return changed;
        }

        // Varianta pe text HTML (cod/salvare): întoarce lista de înlocuiri pe paragraf,
        // ca restul fișierului să rămână neatins (indentare, entități etc.).
        function computeAiStyledSpanEdits(html) {
            html = String(html || '');
            const edits = [];
            const styledRe = /<(?:span|em|i|strong|b|u)\b[^>]*\bstyle\s*=/i;
            if (!styledRe.test(html)) return edits;
            const re = /<p\b[^>]*>[\s\S]*?<\/p>/gi;
            let m;
            while ((m = re.exec(html)) !== null) {
                if (!styledRe.test(m[0])) continue;
                const tpl = document.createElement('template');
                tpl.innerHTML = m[0];
                const p = tpl.content.firstElementChild;
                if (!p || p.nodeName !== 'P') continue;
                const oldClass = p.getAttribute('class');
                if (!cleanAiStyledSpansInParagraph(p)) continue;
                const pOpen = /^<p\b[^>]*>/i.exec(m[0])[0];
                let newOpen = pOpen;
                const newClass = p.getAttribute('class');
                if (newClass !== oldClass) {
                    newOpen = /\bclass\s*=/i.test(pOpen)
                        ? pOpen.replace(/\bclass\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/i, 'class="' + newClass + '"')
                        : pOpen.replace(/^<p\b/i, '<p class="' + newClass + '"');
                }
                edits.push({ from: m.index, to: m.index + m[0].length, text: newOpen + p.innerHTML + '</p>' });
            }
            return edits;
        }

        function cleanAiStyledSpansInHtml(html) {
            let out = String(html || '');
            const edits = computeAiStyledSpanEdits(out);
            for (let i = edits.length - 1; i >= 0; i--) {
                out = out.slice(0, edits[i].from) + edits[i].text + out.slice(edits[i].to);
            }
            return out;
        }

        // La deschiderea unui fișier: rescrie în cod paragrafele cu stil AI.
        // Întoarce câte paragrafe a reparat (0 = nimic de făcut).
        // Marcajele portocalii ale căutării (Find) din Design nu au voie să ajungă în cod.
        const FIND_MARK_RE = /<mark\b[^>]*\bdata-fr-highlight\b[^>]*>([\s\S]*?)<\/mark>/gi;
        function stripFindMarksFromHtml(html) {
            return String(html || '').replace(FIND_MARK_RE, '$1');
        }
        function computeFindMarkEdits(html) {
            const edits = [];
            const re = new RegExp(FIND_MARK_RE.source, 'gi');
            let m;
            while ((m = re.exec(html)) !== null) {
                edits.push({ from: m.index, to: m.index + m[0].length, text: m[1] });
            }
            return edits;
        }

        function applyEditsToEditor(edits) {
            if (!edits.length) return;
            const prevSync = isSyncFromDesign, prevRestore = _isRestoringTab;
            isSyncFromDesign = true;
            _isRestoringTab = true;
            try {
                editor.operation(() => {
                    for (let i = edits.length - 1; i >= 0; i--) {
                        editor.replaceRange(edits[i].text, editor.posFromIndex(edits[i].from), editor.posFromIndex(edits[i].to), '+aiStyleCleanup');
                    }
                });
            } finally {
                isSyncFromDesign = prevSync;
                _isRestoringTab = prevRestore;
            }
        }

        function cleanAiStyleInOpenedTab(tab, path) {
            if (!editor) return 0;
            if (path && !/\.html?$/i.test(path)) return 0;
            const markEdits = computeFindMarkEdits(editor.getValue());
            applyEditsToEditor(markEdits);
            const edits = computeAiStyledSpanEdits(editor.getValue());
            applyEditsToEditor(edits);
            const total = markEdits.length + edits.length;
            if (total && tab) tab.editorContent = editor.getValue();
            return total;
        }

        function markTabDirtyAfterAiCleanup(tab, count) {
            if (!count || !tab) return;
            tab.isDirty = true;
            isDirty = true;
            toast('Am curățat ' + count + ' loc(uri): stil AI (span style) / marcaje de căutare rămase în cod. Salvează ca să rămână.');
        }

        // ── Butoanele N / B la nivel de paragraf ──
        function getDesignCaretParagraph() {
            const iframe = document.getElementById('preview');
            const win = iframe && iframe.contentWindow;
            const sel = win && win.getSelection();
            if (!sel || !sel.rangeCount) return null;
            let node = sel.getRangeAt(0).startContainer;
            if (node && node.nodeType !== 1) node = node.parentNode;
            const p = node && node.closest ? node.closest('p,h1,h2,h3,h4,h5,h6') : null;
            return p && p.ownerDocument.body && p.ownerDocument.body.contains(p) ? p : null;
        }

        // true dacă nu e text selectat parțial (doar cursor, sau tot paragraful selectat)
        function designSelectionIsWholeParagraph(p) {
            const iframe = document.getElementById('preview');
            const sel = iframe && iframe.contentWindow && iframe.contentWindow.getSelection();
            if (!sel || !sel.rangeCount) return false;
            const range = sel.getRangeAt(0);
            if (range.collapsed) return true;
            const norm = function (s) { return String(s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim(); };
            return norm(range.toString()) === norm(p.textContent);
        }

        function placeCaretAtEnd(el) {
            const doc = el.ownerDocument;
            const win = doc.defaultView;
            const sel = win && win.getSelection();
            if (!sel) return;
            const r = doc.createRange();
            r.selectNodeContents(el);
            r.collapse(false);
            sel.removeAllRanges();
            sel.addRange(r);
        }

        // Scoate toate tagurile din paragraf, păstrând doar textul, link-urile și <br>.
        function stripParagraphToPlain(p, keepEmU) {
            const doc = p.ownerDocument;
            const keep = keepEmU ? /^(?:A|BR|EM|U)$/ : /^(?:A|BR)$/;
            Array.prototype.slice.call(p.querySelectorAll('*')).reverse().forEach(function (el) {
                if (keep.test(el.nodeName)) {
                    if (el.nodeName !== 'A' && el.nodeName !== 'BR') {
                        Array.prototype.slice.call(el.attributes).forEach(function (a) { el.removeAttribute(a.name); });
                    }
                    return;
                }
                const parent = el.parentNode;
                if (!parent) return;
                while (el.firstChild) parent.insertBefore(el.firstChild, el);
                parent.removeChild(el);
            });
            if (keepEmU) {
                Array.prototype.slice.call(p.querySelectorAll('i')).forEach(function (i) {
                    const em = doc.createElement('em');
                    while (i.firstChild) em.appendChild(i.firstChild);
                    i.parentNode.replaceChild(em, i);
                });
            }
            p.normalize();
        }

        function setDesignParagraphStyle(p, cls) {
            designPushCurrentState();
            if (p.tagName !== 'P') {
                const paragraph = p.ownerDocument.createElement('p');
                while (p.firstChild) paragraph.appendChild(p.firstChild);
                p.replaceWith(paragraph); p = paragraph;
            }
            Array.prototype.slice.call(p.attributes).forEach(function (a) {
                if (a.name !== 'class') p.removeAttribute(a.name);
            });
            // N = paragraf complet curat; B = bold pe tot paragraful, dar păstrează italic/underline
            stripParagraphToPlain(p, cls === 'text_obisnuit2');
            p.className = cls;
            placeCaretAtEnd(p);
            syncFromDesign();
            lastDesignSnapshot = getDesignBodyHtml();
            if (typeof updatePropertiesPanelFromSelection === 'function') {
                try { updatePropertiesPanelFromSelection(); } catch (e) { }
            }
            refreshParagraphStyleButtons();
        }

        function applyNormalParagraphStyle() {
            const p = getDesignCaretParagraph();
            if (!p) { toast('Dă click într-un paragraf din Design.'); return; }
            setDesignParagraphStyle(p, 'text_obisnuit');
        }

        // B: text_obisnuit → text_obisnuit2, apoi la al doilea click înapoi la text_obisnuit.
        // Întoarce false dacă e selectată doar o bucată de text (atunci rămâne bold-ul vechi, pe selecție).
        function toggleBoldParagraphStyle() {
            const p = getDesignCaretParagraph();
            if (!p || !designSelectionIsWholeParagraph(p)) return false;
            const isBold = p.tagName === 'P' && p.classList.contains('text_obisnuit2');
            setDesignParagraphStyle(p, isBold ? 'text_obisnuit' : 'text_obisnuit2');
            return true;
        }

        function refreshParagraphStyleButtons() {
            const p = getDesignCaretParagraph();
            const isBold = !!(p && p.classList.contains('text_obisnuit2'));
            const isNormal = !!(p && p.classList.contains('text_obisnuit'));
            const top = document.getElementById('btnClassObisnuit2');
            if (top) top.classList.toggle('active', isBold);
            const nBtn = document.getElementById('btnClassNormal');
            if (nBtn) nBtn.classList.toggle('active', isNormal);
            const propB = document.getElementById('propBold');
            if (propB && isBold) propB.style.background = 'rgba(59,130,246,0.3)';
        }

        function designSelectionHasCssClass(el, className) {
            if (!el || !className) return false;
            var node = el;
            while (node && node.nodeType === 1 && node.tagName !== 'BODY') {
                if (node.classList && node.classList.contains(className)) return true;
                node = node.parentElement;
            }
            return false;
        }

        // In design mode, keep trailing spaces visible in editable article paragraphs.
        // This avoids the "space exists in code but not visible in design" confusion.
        function ensureDesignWhitespaceEditingStyle(doc) {
            if (!doc || !doc.head) return;
            if (doc.getElementById('designWhitespaceEditingStyle')) return;
            const st = doc.createElement('style');
            st.id = 'designWhitespaceEditingStyle';
            st.textContent =
                'body[contenteditable=\"true\"] p.text_obisnuit,' +
                'body[contenteditable=\"true\"] p.text_obisnuit2 {' +
                ' white-space: break-spaces !important;' +
                '}' +
                // CSS-ul site-ului (ro) are `.text_obisnuit span.text_obisnuit2 { white-space: nowrap }`:
                // un bold lung ar ieși din ramă în Design. Aici îl lăsăm să se rupă pe rânduri.
                'body[contenteditable=\"true\"] p span.text_obisnuit2 {' +
                ' white-space: inherit !important;' +
                '}';
            doc.head.appendChild(st);
        }

        /** Extrage <!-- JavaScript --> + toate scripturile din body (referință imutabilă per tab). */
        function extractProtectedBodyScriptTail(html) {
            const bodyMatch = /<body[^>]*>([\s\S]*)<\/body>/i.exec(String(html || ''));
            if (!bodyMatch) return null;
            const inner = bodyMatch[1];
            const jsMarker = /<!--\s*JavaScript\s*-->/i;
            const idx = inner.search(jsMarker);
            if (idx !== -1) {
                const tail = inner.slice(idx).trimEnd();
                return /<script\b/i.test(tail) ? tail : null;
            }
            const blocks = inner.match(/<script\b[^>]*>[\s\S]*?<\/script>/gi);
            if (!blocks || !blocks.length) return null;
            return blocks.join('\n    ');
        }

        function applyProtectedScriptsToFullHtml(html, protectedTail) {
            if (!protectedTail) return html;
            const bodyRe = /<body([^>]*)>[\s\S]*<\/body>/i;
            const bodyMatch = bodyRe.exec(String(html || ''));
            if (!bodyMatch) return html;
            const bodyInner = bodyMatch[0].replace(/^<body[^>]*>/i, '').replace(/<\/body>$/i, '');
            if (/<script\b/i.test(bodyInner)) return html;
            const mergedInner = restoreProtectedBodyScripts(bodyInner, bodyInner, protectedTail);
            if (mergedInner === bodyInner) return html;
            return html.slice(0, bodyMatch.index) + '<body' + bodyMatch[1] + '>' + mergedInner + '</body>' +
                html.slice(bodyMatch.index + bodyMatch[0].length);
        }

        /** Păstrează la sync blocul <!-- JavaScript --> + scripturi din body (preview-ul le elimină). */
        function restoreProtectedBodyScripts(originalBodyInner, designBodyInner, protectedTail) {
            if (!designBodyInner) return designBodyInner;
            if (/<script\b/i.test(designBodyInner)) return designBodyInner;

            let tail = protectedTail || null;
            if (!tail && originalBodyInner && /<script\b/i.test(originalBodyInner)) {
                const jsMarker = /<!--\s*JavaScript\s*-->/i;
                const tailStart = originalBodyInner.search(jsMarker);
                if (tailStart !== -1) {
                    tail = originalBodyInner.slice(tailStart).trimEnd();
                } else {
                    const blocks = originalBodyInner.match(/<script\b[^>]*>[\s\S]*?<\/script>/gi) || [];
                    if (blocks.length) tail = blocks.join('\n    ');
                }
            }
            if (!tail) return designBodyInner;

            let core = designBodyInner;
            const jsMarker = /<!--\s*JavaScript\s*-->/i;
            const designJsIdx = core.search(jsMarker);
            if (designJsIdx !== -1) {
                core = core.slice(0, designJsIdx).trimEnd();
            } else {
                core = core.replace(/(?:\s*<!--(?:(?!-->)[\s\S])*-->\s*)+$/i, '').trimEnd();
            }
            return core + '\n    ' + tail + '\n';
        }

        function syncFromDesign(force) {
            if (isSyncFromCode && !force) return;
            const iframe = document.getElementById('preview');
            const doc = iframe.contentDocument;
            if (!doc || !doc.body || !editor) return;
            const full = editor.getValue();
            const bodyRe = /<body([^>]*)>[\s\S]*<\/body>/i;
            const bodyMatch = bodyRe.exec(full);
            if (!bodyMatch) return;
            // Preview-ul PHP (action=preview) poate sanitiza <body> față de sursa din editor
            // (fără on*, <i>→<em>, etc.). Dacă utilizatorul nu a modificat deloc design-ul,
            // innerHTML-ul din iframe rămâne identic cu snapshot-ul inițial — în acest caz
            // nu împingem body-ul înapoi în cod (ar șterge atribute din sursă și ar marca
            // tab-ul ca dirty fără edit real — steaua falsă la schimb de tab / flush).
            if (!isApplyingUndoRedo && designCleanBodyHtml !== null) {
                var _pristine = getDesignBodyHtml();
                if (_pristine !== null && _pristine === designCleanBodyHtml) {
                    return;
                }
            }
            // Remove CROP highlight from DOM before reading so it never persists to code
            clearSasaDesignHighlight(doc);
            cleanupParagraphBoundaryBrArtifacts(doc);
            removePasteWhitespaceNormalSpansFromDom(doc.body);
            cleanAiStyledSpansInRoot(doc.body);
            // Replace &nbsp; with regular space in SASA region and h1.den_articol
            var rawInner = cleanNbspInHtml(doc.body.innerHTML);
            rawInner = removePasteWhitespaceNormalSpansFromHtml(rawInner);
            // Remove data-orig-class helper attribute so it never persists to saved code
            rawInner = rawInner.replace(/\s*data-orig-class="[^"]*"/gi, '');
            // Marcajele Find din Design rămân doar în Design, nu intră în cod
            rawInner = stripFindMarksFromHtml(rawInner);
            // Safety net: fold accidental orphan text back into the emptied block
            // tag next to it ("<p ...></p>text" / "<h1 ...></h1>text" become
            // "<p ...>text</p>" / "<h1 ...>text</h1>"). This shape appears when a
            // paste/edit destroys a block's contents and drops the text after it.
            rawInner = rawInner.replace(
                /<((p|h[1-6])\b[^>]*)>\s*<\/\2>([^<]+)(?=<|$)/gi,
                function (match, openTag, tagName, orphanText) {
                    if (!orphanText.trim()) return match;
                    return '<' + openTag + '>' + orphanText + '</' + tagName + '>';
                }
            );
            rawInner = normalizeBlockWrappedInlineFormat(rawInner, 'em');
            rawInner = normalizeBlockWrappedInlineFormat(rawInner, 'strong');
            rawInner = normalizeBlockWrappedInlineFormat(rawInner, 'u');
            rawInner = normalizeSpanWrappedParagraphClass(rawInner);
            rawInner = removeOrphanClosingSpansFromParagraphs(rawInner);
            rawInner = normalizeTextParagraphInlineFormatting(rawInner);
            // Note: space collapsing is handled per-node in collapseSpacesInDesignDOM()
            // to avoid destroying indentation in the code editor.
            // Ensure line breaks between block-level elements (Design outputs them on one line)
            rawInner = rawInner.replace(/(<\/(?:p|div|h[1-6]|ul|ol|li|table|tr|td|th|thead|tbody|blockquote|section|article|header|footer|nav|aside|figure|figcaption|hr|br|pre|dl|dt|dd)>)(<)/gi, '$1\n$2');
            // După <p …> nu lăsăm textul pe rândul următor (Design/browser pot insera \n la început de paragraf)
            rawInner = rawInner.replace(/(<p\b[^>]*>)\s+/gi, '$1');
            rawInner = rawInner.replace(
                /(^|\n)[ \t]*(<p\b[^>]*\bclass\s*=\s*["'][^"']*\btext_obisnuit2?\b[^"']*["'][^>]*>)/gi,
                '$1\t\t$2'
            );
            // Preserve original tag names (i vs em, b vs strong) from the code editor
            // so that browser normalisation does not silently rename them.
            var oldBodyInner = bodyMatch[0].replace(/^<body[^>]*>/i, '').replace(/<\/body>$/i, '');
            var protectedTail = null;
            if (activeTabId) {
                for (var _ti = 0; _ti < tabs.length; _ti++) {
                    if (tabs[_ti].id === activeTabId) {
                        protectedTail = tabs[_ti].protectedBodyScriptTail;
                        break;
                    }
                }
            }
            rawInner = restoreProtectedBodyScripts(oldBodyInner, rawInner, protectedTail);
            rawInner = preserveEquivTags(oldBodyInner, rawInner);
            const newBody = '<body' + bodyMatch[1] + '>' + rawInner + '</body>';
            // Only update code if the body actually changed (avoids false dirty on select/copy)
            if (newBody === bodyMatch[0]) {
                // Re-apply CROP highlight (we cleared it above for clean reading)
                if (cropHighlightActive) highlightSasaInDesign('crop');
                return;
            }
            var candidateFull = full.slice(0, bodyMatch.index) + newBody + full.slice(bodyMatch.index + bodyMatch[0].length);
            if (normalizeHtmlForSyncCompare(candidateFull) === normalizeHtmlForSyncCompare(full)) {
                if (cropHighlightActive) highlightSasaInDesign('crop');
                return;
            }
            isSyncFromDesign = true;
            const from = editor.posFromIndex(bodyMatch.index);
            const to = editor.posFromIndex(bodyMatch.index + bodyMatch[0].length);
            editor.replaceRange(newBody, from, to);
            isSyncFromDesign = false;
            // Recalculate dirty state by comparing to originalContent
            // (so that undoing all changes correctly clears the dirty star)
            if (activeTabId) {
                var _t = null;
                for (var _i = 0; _i < tabs.length; _i++) { if (tabs[_i].id === activeTabId) { _t = tabs[_i]; break; } }
                if (_t) {
                    var nowDirty = (normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(_t.originalContent));
                    _t.isDirty = nowDirty;
                    isDirty = nowDirty;
                    var _el = document.querySelector('.editor-tab[data-tab-id="' + activeTabId + '"]');
                    if (_el) { if (nowDirty) _el.classList.add('dirty'); else _el.classList.remove('dirty'); }
                } else {
                    isDirty = true;
                }
            } else {
                isDirty = true;
            }
            syncSelectionToCodeFromDesign();
            // Re-apply CROP highlight visually (it was just stripped for clean sync)
            if (cropHighlightActive) highlightSasaInDesign('crop');
        }

        function makeDesignEditable() {
            const iframe = document.getElementById('preview');
            const doc = iframe.contentDocument;
            if (!doc || !doc.body || !isCurrentFileHtml()) return;
            doc.body.contentEditable = 'true';
            ensureDesignWhitespaceEditingStyle(doc);
            // Track that design panel was last focused (for Find scope in split mode)
            doc.addEventListener('mousedown', () => {
                _frDesignWasLastFocused = true;
                // A click inside Design starts a genuinely new selection. Toolbar
                // clicks happen in the parent document and must keep the last range.
                lastDesignSelectionRange = null;
            });
            // Block text drag-and-drop in design panel (prevents accidental moves)
            doc.addEventListener('dragstart', function (e) { e.preventDefault(); });
            doc.addEventListener('drop', function (e) { e.preventDefault(); });

            // If the code editor has unsaved changes that differ from the physical file we just
            // loaded into the iframe (e.g., restoring a dirty tab on refresh), apply them now!
            // This prevents losing edits when reopening a dirty tab or rebuilding the preview.
            if (isDirty) {
                applyCodeToDesignPanel();
            } else {
                var _hasDesignHistory = (designUndoStack && designUndoStack.length > 0) ||
                    (designRedoStack && designRedoStack.length > 0);
                var _hasCodeHistory = false;
                try {
                    var _hsz = editor && editor.getDoc && editor.getDoc().historySize
                        ? editor.getDoc().historySize()
                        : null;
                    _hasCodeHistory = !!(_hsz && (_hsz.undo > 0 || _hsz.redo > 0));
                } catch (eHist) { _hasCodeHistory = false; }
                if (_hasDesignHistory || _hasCodeHistory) {
                    lastDesignSnapshot = getDesignBodyHtml();
                    designCleanBodyHtml = designCleanBodyHtml || lastDesignSnapshot;
                    designCleanCode = designCleanCode || (editor ? editor.getValue() : null);
                } else {
                    // Initialize the custom undo/redo stack for this freshly-loaded clean page.
                    designResetUndoStack();
                }
            }

            // Chromium on Windows can fire a spurious 'input' event immediately after
            // a clipboard copy (Ctrl+C) on contentEditable elements, even though no
            // content was actually modified. Suppress any 'input' that arrives within
            // 150ms of a 'copy' event so it never triggers a false dirty state.
            let _suppressInputAfterCopy = false;
            // Track when a Ctrl/Meta combo keydown happens. On keyup, the user may
            // have already released Ctrl, making e.ctrlKey false. Without this
            // tracking, the keyup handler would erroneously trigger syncFromDesign
            // for non-modifying shortcuts (Ctrl+C, Ctrl+A, etc.), which then detects
            // browser HTML normalization differences as real content changes.
            let _lastCtrlComboTime = 0;
            doc.addEventListener('keydown', (e) => {
                if (e.ctrlKey || e.metaKey) _lastCtrlComboTime = Date.now();
                // Intercept Ctrl+F / Ctrl+H in Design panel to open app's Find & Replace
                if ((e.ctrlKey || e.metaKey) && (e.key === 'f' || e.key === 'F') && !e.shiftKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    window.parent.toggleFindReplace ? window.parent.toggleFindReplace() : toggleFindReplace();
                }
                if ((e.ctrlKey || e.metaKey) && (e.key === 'h' || e.key === 'H')) {
                    e.preventDefault();
                    e.stopPropagation();
                    window.parent.toggleFindReplace ? window.parent.toggleFindReplace() : toggleFindReplace();
                }
                // F3 / Shift+F3 — Find Next / Find Prev from design panel
                if (e.key === 'F3') {
                    const dlg = document.getElementById('findReplaceDialog');
                    if (dlg && dlg.classList.contains('visible')) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (e.shiftKey) findPrev(); else findNext();
                        return;
                    }
                }
                // Escape — close Find & Replace from design panel
                if (e.key === 'Escape') {
                    const dlg = document.getElementById('findReplaceDialog');
                    if (dlg && dlg.classList.contains('visible')) {
                        closeFindReplace();
                    }
                }
            });
            doc.addEventListener('copy', () => {
                _suppressInputAfterCopy = true;
                setTimeout(() => { _suppressInputAfterCopy = false; }, 150);
            });
            function splitPlainTextIntoPasteParagraphs(text) {
                return String(text || '')
                    .replace(/\r\n/g, '\n')
                    .replace(/\r/g, '\n')
                    .split(/\n[ \t\u00a0]*\n+/)
                    .map(function (part) {
                        return part.replace(/[ \t\u00a0]*\n[ \t\u00a0]*/g, ' ')
                            .replace(/ {2,}/g, ' ')
                            .trim();
                    })
                    .filter(function (part) { return part.length > 0; });
            }

            function closestPasteParagraph(node) {
                while (node && node !== doc.body) {
                    if (node.nodeType === Node.ELEMENT_NODE && node.tagName === 'P') return node;
                    node = node.parentNode;
                }
                return null;
            }

            function closestPasteBlock(node) {
                while (node && node !== doc.body) {
                    if (node.nodeType === Node.ELEMENT_NODE && /^(?:P|H[1-6])$/.test(node.tagName)) return node;
                    node = node.parentNode;
                }
                return null;
            }

            function normalizePasteCompareText(value) {
                return String(value || '')
                    .replace(/\u00a0/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();
            }

            // Block tags (<p>/<h1>-<h6>) that the selection wraps COMPLETELY.
            // Happens when the selection is anchored in the whitespace between
            // tags (double/triple-click can stretch the selection past the
            // element edges). deleteContents() would then destroy the tag and
            // leave the pasted text orphaned between blocks: <p ...></p>text.
            function blocksFullyInsideRange(range) {
                let root = range.commonAncestorContainer;
                if (root && root.nodeType !== Node.ELEMENT_NODE) root = root.parentNode;
                if (!root || !root.querySelectorAll) return [];
                const found = [];
                const blocks = root.querySelectorAll('p, h1, h2, h3, h4, h5, h6');
                for (let i = 0; i < blocks.length; i++) {
                    const blockRange = doc.createRange();
                    blockRange.selectNode(blocks[i]);
                    if (range.compareBoundaryPoints(Range.START_TO_START, blockRange) <= 0 &&
                        range.compareBoundaryPoints(Range.END_TO_END, blockRange) >= 0) {
                        found.push(blocks[i]);
                    }
                }
                return found;
            }

            function isEmptyPasteBlock(el) {
                return !!(el && /^(?:P|H[1-6])$/.test(el.nodeName) &&
                    !normalizePasteCompareText(el.textContent) &&
                    !el.querySelector('img, hr, input, iframe, video, svg, canvas'));
            }

            function rangeIntersectsPasteNode(range, node) {
                if (!range || !node) return false;
                try {
                    return range.intersectsNode(node);
                } catch (e) {
                    try {
                        const nodeRange = doc.createRange();
                        nodeRange.selectNode(node);
                        return range.compareBoundaryPoints(Range.START_TO_END, nodeRange) > 0 &&
                            range.compareBoundaryPoints(Range.END_TO_START, nodeRange) < 0;
                    } catch (_) {
                        return false;
                    }
                }
            }

            function pasteBoundaryBlock(range, atStart) {
                let container = atStart ? range.startContainer : range.endContainer;
                const offset = atStart ? range.startOffset : range.endOffset;
                if (container && container.nodeType === Node.ELEMENT_NODE) {
                    let child = null;
                    if (atStart) {
                        child = container.childNodes[offset] || container.childNodes[offset - 1] || null;
                    } else {
                        child = container.childNodes[offset - 1] || container.childNodes[offset] || null;
                    }
                    if (child) {
                        if (child.nodeType === Node.TEXT_NODE) return closestPasteBlock(child);
                        if (child.nodeType === Node.ELEMENT_NODE) {
                            if (/^(?:P|H[1-6])$/.test(child.nodeName)) return child;
                            return child.closest ? child.closest('p,h1,h2,h3,h4,h5,h6') : null;
                        }
                    }
                }
                return closestPasteBlock(container);
            }

            function pasteIntoWholeSelectedBlockText(range, text, sel) {
                const selectedText = normalizePasteCompareText(range.toString());
                if (!selectedText) return false;
                const candidates = [];
                function addCandidate(block) {
                    if (!block || !/^(?:P|H[1-6])$/.test(block.nodeName)) return;
                    if (candidates.indexOf(block) === -1) candidates.push(block);
                }
                addCandidate(closestPasteBlock(range.startContainer));
                addCandidate(closestPasteBlock(range.endContainer));
                addCandidate(pasteBoundaryBlock(range, true));
                addCandidate(pasteBoundaryBlock(range, false));

                let target = null;
                for (let i = 0; i < candidates.length; i++) {
                    if (normalizePasteCompareText(candidates[i].textContent) === selectedText) {
                        target = candidates[i];
                        break;
                    }
                }
                if (!target) {
                    let root = range.commonAncestorContainer;
                    if (root && root.nodeType !== Node.ELEMENT_NODE) root = root.parentNode;
                    if (!root || !root.querySelectorAll) root = doc.body;
                    const blocks = root.querySelectorAll('p, h1, h2, h3, h4, h5, h6');
                    for (let i = 0; i < blocks.length; i++) {
                        if (!rangeIntersectsPasteNode(range, blocks[i])) continue;
                        if (normalizePasteCompareText(blocks[i].textContent) === selectedText) {
                            target = blocks[i];
                            break;
                        }
                    }
                }
                if (!target) return false;

                target.textContent = text;
                target.normalize();
                let caretNode = target.lastChild;
                if (!caretNode || caretNode.nodeType !== Node.TEXT_NODE) {
                    caretNode = doc.createTextNode('');
                    target.appendChild(caretNode);
                }
                const newRange = doc.createRange();
                newRange.setStart(caretNode, caretNode.nodeValue.length);
                newRange.setEnd(caretNode, caretNode.nodeValue.length);
                sel.removeAllRanges();
                sel.addRange(newRange);
                return true;
            }

            // Paste over a fully-wrapped block: put the text INSIDE the existing
            // tag (keeping the tag name, class and all attributes) instead of
            // letting deleteContents destroy the tag.
            function pasteIntoSwallowedBlock(range, text, sel) {
                const swallowed = blocksFullyInsideRange(range);
                if (!swallowed.length) return false;
                let target = null;
                for (let i = 0; i < swallowed.length; i++) {
                    if (normalizePasteCompareText(swallowed[i].textContent)) { target = swallowed[i]; break; }
                }
                if (!target) target = swallowed[0];
                target.textContent = text;
                // Other blocks fully inside the selection were selected for
                // replacement too — remove them so the paste doesn't duplicate.
                for (let i = 0; i < swallowed.length; i++) {
                    if (swallowed[i] !== target && swallowed[i].parentNode) {
                        swallowed[i].parentNode.removeChild(swallowed[i]);
                    }
                }
                const caretNode = target.firstChild;
                const newRange = doc.createRange();
                newRange.setStart(caretNode, caretNode.nodeValue.length);
                newRange.setEnd(caretNode, caretNode.nodeValue.length);
                sel.removeAllRanges();
                sel.addRange(newRange);
                return true;
            }

            function insertPlainTextParagraphsAtSelection(range, paragraphs) {
                if (!paragraphs || paragraphs.length < 2) return false;
                return insertParagraphBlocksAtSelection(range, paragraphs.map(function (txt) {
                    return { cls: 'text_obisnuit', text: txt };
                }));
            }

            // Paste de Markdown: un singur paragraf in mijlocul unui text existent se
            // insereaza inline (<em>/<span>); altfel paragrafele inlocuiesc blocul selectat.
            function insertMarkdownAtSelection(range, sel, blocks, rawText) {
                if (!blocks.length) return false;
                if (blocks.length === 1) {
                    const p = closestPasteParagraph(range.startContainer);
                    const sameP = p && p === closestPasteParagraph(range.endContainer);
                    const pText = sameP ? normalizePasteCompareText(p.textContent) : '';
                    const coversP = sameP && (!pText || normalizePasteCompareText(range.toString()) === pText);
                    if (sameP && !coversP) {
                        const tpl = doc.createElement('template');
                        const lead = /^[ \t ]/.test(rawText || '') ? ' ' : '';
                        const trail = /[ \t ]$/.test(rawText || '') ? ' ' : '';
                        tpl.innerHTML = lead + (blocks[0].cls === 'text_obisnuit2'
                            ? '<span class="text_obisnuit2">' + blocks[0].html + '</span>'
                            : blocks[0].html) + trail;
                        const lastNode = tpl.content.lastChild;
                        range.deleteContents();
                        range.insertNode(tpl.content);
                        if (lastNode) {
                            const r = doc.createRange();
                            r.setStartAfter(lastNode);
                            r.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(r);
                        }
                        return true;
                    }
                }
                return insertParagraphBlocksAtSelection(range, blocks);
            }

            // blocks: [{ cls, text }] sau [{ cls, html }]
            function insertParagraphBlocksAtSelection(range, blocks) {
                let firstP = closestPasteParagraph(range.startContainer);
                let lastP = closestPasteParagraph(range.endContainer) || firstP;
                if (!firstP) {
                    const swallowed = blocksFullyInsideRange(range).filter(function (b) { return b.tagName === 'P'; });
                    if (swallowed.length) {
                        firstP = swallowed[0];
                        lastP = swallowed[swallowed.length - 1];
                    }
                }
                if (firstP && lastP && firstP.parentNode !== lastP.parentNode) lastP = firstP;
                const frag = doc.createDocumentFragment();
                let lastInserted = null;
                blocks.forEach(function (b) {
                    const p = doc.createElement('p');
                    p.className = b.cls || 'text_obisnuit';
                    if (b.html != null) p.innerHTML = b.html;
                    else p.textContent = b.text;
                    lastInserted = p;
                    frag.appendChild(p);
                });

                if (firstP && firstP.parentNode) {
                    const parent = firstP.parentNode;
                    parent.insertBefore(frag, firstP);
                    let cur = firstP;
                    while (cur) {
                        const next = cur.nextSibling;
                        parent.removeChild(cur);
                        if (cur === lastP) break;
                        cur = next;
                    }
                } else {
                    range.deleteContents();
                    range.insertNode(frag);
                }

                if (lastInserted) {
                    const newRange = doc.createRange();
                    newRange.selectNodeContents(lastInserted);
                    newRange.collapse(false);
                    const sel2 = iframe.contentWindow && iframe.contentWindow.getSelection();
                    if (sel2) {
                        sel2.removeAllRanges();
                        sel2.addRange(newRange);
                    }
                }
                return true;
            }

            function htmlClipboardToPlainText(html) {
                if (!html) return '';
                const tmp = doc.createElement('div');
                tmp.innerHTML = html;
                return tmp.innerText || tmp.textContent || '';
            }

            function finishPlainTextPaste() {
                removePasteWhitespaceNormalSpansFromDom(doc.body);
                cleanAiStyledSpansInRoot(doc.body);
                cleanupParagraphBoundaryBrArtifacts(doc);
                clearTimeout(designInputDebounceTimer);
                designInputDebounceTimer = setTimeout(syncFromDesign, 80);
            }

            doc.addEventListener('paste', (e) => {
                // Force copy-paste to insert as plain text so we don't bring in
                // inline styles, spans, or classes from external sources (e.g. Google Translate).
                // We use direct text-node manipulation instead of execCommand('insertText')
                // because execCommand can destroy parent DOM structure (tags, classes,
                // links) when replacing the entire content of an element.
                e.preventDefault();
                e.stopPropagation();
                if (e.stopImmediatePropagation) e.stopImmediatePropagation();
                const clipboard = e.clipboardData || window.clipboardData;
                let text = clipboard ? clipboard.getData('text/plain') : '';
                if (!text && clipboard) text = htmlClipboardToPlainText(clipboard.getData('text/html'));
                if (!text) return;
                // Collapse multiple consecutive spaces into one
                text = text.replace(/ {2,}/g, ' ');
                designSaveSnapshot();
                const win = iframe.contentWindow;
                const sel = win && win.getSelection();
                if (!sel || sel.rangeCount === 0) return;
                const range = sel.getRangeAt(0);
                if (looksLikeMarkdown(text) &&
                    insertMarkdownAtSelection(range, sel, markdownToParagraphBlocks(text), text)) {
                    finishPlainTextPaste();
                    return;
                }
                const pasteParagraphs = splitPlainTextIntoPasteParagraphs(text);
                if (insertPlainTextParagraphsAtSelection(range, pasteParagraphs)) {
                    finishPlainTextPaste();
                    return;
                }
                if (pasteIntoWholeSelectedBlockText(range, text, sel)) {
                    finishPlainTextPaste();
                    return;
                }

                // Case 1: Selection within a single text node — directly modify nodeValue.
                // This is the most common case (e.g., selecting "Servus Litterae" inside
                // <a class="linkMare">Servus Litterae</a>) and guarantees all parent
                // elements (tags, classes, href) are fully preserved.
                if (range.startContainer === range.endContainer &&
                    range.startContainer.nodeType === Node.TEXT_NODE) {
                    const node = range.startContainer;
                    const before = node.nodeValue.substring(0, range.startOffset);
                    const after = node.nodeValue.substring(range.endOffset);
                    node.nodeValue = before + text + after;
                    // Position caret after inserted text
                    const newOffset = before.length + text.length;
                    const newRange = doc.createRange();
                    newRange.setStart(node, newOffset);
                    newRange.setEnd(node, newOffset);
                    sel.removeAllRanges();
                    sel.addRange(newRange);
                }
                // Case 1.5: the selection wraps one or more whole block tags
                // (<p>/<h1>-<h6>) — double/triple-click often anchors the
                // selection in the whitespace around the tag. Replace the text
                // INSIDE the tag so its name/class/attributes survive; letting
                // this fall through to deleteContents would destroy the tag and
                // leave "<p class=...></p>orphan text" in the code.
                else if (pasteIntoSwallowedBlock(range, text, sel)) {
                    // handled — nothing else to do
                }
                // Case 2: Element-level or cross-node selection — use deleteContents
                // + insertNode. deleteContents preserves parent structure (just empties
                // selected content), unlike execCommand which restructures the DOM.
                else {
                    // Collect all <p> elements touched by the selection BEFORE deleting,
                    // so we can clean up empty shells afterwards.
                    const touchedPs = [];
                    (function collectTouchedParagraphs() {
                        const container = range.commonAncestorContainer;
                        const root = (container.nodeType === Node.ELEMENT_NODE) ? container : container.parentNode;
                        if (!root) return;
                        const allPs = root.querySelectorAll ? root.querySelectorAll('p') : [];
                        for (let i = 0; i < allPs.length; i++) {
                            if (sel.containsNode(allPs[i], true)) touchedPs.push(allPs[i]);
                        }
                    })();

                    range.deleteContents();
                    const textNode = doc.createTextNode(text);
                    range.insertNode(textNode);

                    // If text ended up outside a <p>/<h*> block (direct child of body
                    // or of a structural container div), it would serialize as orphan
                    // text between tags. Refill the adjacent block that deleteContents
                    // just emptied (keeps its tag + class), or wrap the text in
                    // <p class="text_obisnuit"> and remove empty <p> remnants.
                    const parent = textNode.parentNode;
                    const isOrphan = parent && !closestPasteBlock(textNode) && (
                        parent === doc.body ||
                        /^(?:DIV|SECTION|ARTICLE|MAIN|ASIDE|HEADER|FOOTER)$/.test(parent.nodeName)
                    );
                    if (isOrphan) {
                        let wrapper = null;
                        if (isEmptyPasteBlock(textNode.previousElementSibling)) {
                            wrapper = textNode.previousElementSibling;
                        } else if (isEmptyPasteBlock(textNode.nextElementSibling)) {
                            wrapper = textNode.nextElementSibling;
                        }
                        if (wrapper) {
                            wrapper.textContent = '';
                            wrapper.appendChild(textNode);
                        } else {
                            wrapper = doc.createElement('p');
                            wrapper.className = 'text_obisnuit';
                            parent.insertBefore(wrapper, textNode);
                            wrapper.appendChild(textNode);
                        }
                        // Remove empty <p> siblings left by deleteContents
                        for (let i = touchedPs.length - 1; i >= 0; i--) {
                            const p = touchedPs[i];
                            if (p !== wrapper && p.parentNode &&
                                (!p.textContent || !p.textContent.trim())) {
                                p.parentNode.removeChild(p);
                            }
                        }
                        // Also sweep any remaining adjacent empty <p> elements
                        let sib = wrapper.previousElementSibling;
                        while (sib && sib.nodeName === 'P' &&
                               (!sib.textContent || !sib.textContent.trim())) {
                            const prev = sib.previousElementSibling;
                            sib.parentNode.removeChild(sib);
                            sib = prev;
                        }
                        sib = wrapper.nextElementSibling;
                        while (sib && sib.nodeName === 'P' &&
                               (!sib.textContent || !sib.textContent.trim())) {
                            const nxt = sib.nextElementSibling;
                            sib.parentNode.removeChild(sib);
                            sib = nxt;
                        }
                        const newRange = doc.createRange();
                        newRange.setStartAfter(textNode);
                        newRange.setEndAfter(textNode);
                        sel.removeAllRanges();
                        sel.addRange(newRange);
                    } else {
                        const newRange = doc.createRange();
                        newRange.setStartAfter(textNode);
                        newRange.setEndAfter(textNode);
                        sel.removeAllRanges();
                        sel.addRange(newRange);
                    }
                }
                finishPlainTextPaste();
            }, true);
            doc.body.addEventListener('input', () => {
                if (isApplyingUndoRedo) return;
                if (_suppressInputAfterCopy) return;
                // Clear design-click highlight when user edits in design
                if (_imgClickMark) { _imgClickMark.clear(); _imgClickMark = null; }
                // Collapse multiple spaces in design DOM text nodes (real-time cleanup)
                collapseSpacesInDesignDOM(doc);
                cleanupParagraphBoundaryBrArtifacts(doc);
                clearTimeout(designInputDebounceTimer);
                designInputDebounceTimer = setTimeout(syncFromDesign, 80);
            });
            doc.body.addEventListener('keyup', (e) => {
                if (isApplyingUndoRedo) return;
                // Suppress keyup events from Ctrl/Meta combos (Ctrl+C, Ctrl+A, etc.).
                // The user may release Ctrl before the letter key, so e.ctrlKey can be
                // false on keyup. We use a 300ms window from the last Ctrl keydown.
                // Content-modifying combos (Ctrl+V, Ctrl+X, Ctrl+B) already fire the
                // 'input' event above, so the keyup safety-net is not needed for them.
                if (e.ctrlKey || e.metaKey) return;
                if (Date.now() - _lastCtrlComboTime < 300) return;
                if (e.key === 'PrintScreen' || e.key === 'Escape' ||
                    e.key === 'Tab' || e.key === 'CapsLock' ||
                    e.key === 'NumLock' || e.key === 'ScrollLock' || e.key === 'Pause' ||
                    e.key === 'Insert' || /^F\d+$/.test(e.key) ||
                    e.key === 'ArrowLeft' || e.key === 'ArrowRight' ||
                    e.key === 'ArrowUp' || e.key === 'ArrowDown' ||
                    e.key === 'Home' || e.key === 'End' ||
                    e.key === 'PageUp' || e.key === 'PageDown' ||
                    e.key === 'Shift' || e.key === 'Control' ||
                    e.key === 'Alt' || e.key === 'Meta') return;
                clearTimeout(designInputDebounceTimer);
                designInputDebounceTimer = setTimeout(syncFromDesign, 80);
            });
            // Debounce selectionchange so we read the FINAL selection, not intermediate
            // states during a drag. 60ms is enough for the selection to settle.
            let _selChangeTimer = null;
            doc.addEventListener('selectionchange', () => {
                clearTimeout(_selChangeTimer);
                _selChangeTimer = setTimeout(() => {
                    rememberDesignSelectionRange(iframe.contentWindow, doc);
                    if (!isSelectionFromCode && !(window._frNavigatingUntil > Date.now())) updatePropertiesPanelFromSelection();
                }, 60);
            });
            doc.addEventListener('mouseup', () => {
                rememberDesignSelectionRange(iframe.contentWindow, doc);
                updatePropertiesPanelFromSelection();
            });
            doc.addEventListener('keyup', () => {
                rememberDesignSelectionRange(iframe.contentWindow, doc);
                updatePropertiesPanelFromSelection();
            });
            // ── Intercept mousedown on images inside anchors so we can
            //    select the <img> before the browser's default behaviour. ──
            doc.addEventListener('mousedown', e => {
                const target = e.target;
                if (!target || target.tagName !== 'IMG') return;
                const anchor = target.closest ? target.closest('a') : null;
                if (!anchor) return;
                // Prevent the browser's default mousedown on the anchor (which
                // would place the caret in the surrounding text, not on the image).
                e.preventDefault();
                e.stopPropagation();
                // Steag din secțiunea FLAGS: copiază doar numele paginii din link
                // (ex. https://neculaifantanaru.com/en/the-master-of-the-world.html → the-master-of-the-world.html)
                if (e.button === 0 && /flag_lang_/i.test(target.getAttribute('src') || '')) {
                    const href = (anchor.getAttribute('href') || '').split('#')[0].split('?')[0];
                    const page = href.replace(/\/+$/, '').split('/').pop();
                    if (page) copyFlagPageName(page, (target.getAttribute('title') || target.getAttribute('alt') || '').trim());
                }
                // Manually select the <img> element
                const iframeWin = document.getElementById('preview').contentWindow;
                try {
                    const r = doc.createRange();
                    r.selectNode(target);
                    const s = iframeWin.getSelection();
                    s.removeAllRanges();
                    s.addRange(r);
                } catch (_) {}
                // Sync to code editor immediately
                if (typeof syncClickedElementToCode === 'function') syncClickedElementToCode(target);
                // Delay properties update slightly so the selection settles
                setTimeout(updatePropertiesPanelFromSelection, 10);
            }, true);
            // Prevent link navigation on click; handle non-anchor clicks
            doc.addEventListener('click', e => {
                const target = e.target;
                if (!target || target === doc.body) return;
                const anchor = target.closest ? target.closest('a') : (target.tagName === 'A' ? target : null);
                if (anchor) {
                    e.preventDefault();
                    e.stopPropagation();
                    // Images inside anchors are fully handled by the mousedown handler;
                    // for text links, sync the clicked element to code here.
                    if (target.tagName !== 'IMG') {
                        // If the user has drag-selected text inside the link, let the
                        // selection-based sync handle it — it highlights only the text
                        // portion in the code, not the surrounding <a> tags and URL.
                        const _iframeWin = document.getElementById('preview').contentWindow;
                        const _curSel = _iframeWin && _iframeWin.getSelection();
                        if (_curSel && !_curSel.isCollapsed) return;
                        if (typeof syncClickedElementToCode === 'function') syncClickedElementToCode(target);
                    }
                    return;
                }
                // If the user has drag-selected text, don't override the selection
                // with a cursor-only sync. The selectionchange/mouseup handlers already
                // highlighted the selected text in the code editor.
                const iframeWin = document.getElementById('preview').contentWindow;
                const curSel = iframeWin && iframeWin.getSelection();
                if (curSel && !curSel.isCollapsed) return;
                // Sync any clicked element to its position in the source code
                if (typeof syncClickedElementToCode === 'function') syncClickedElementToCode(target);
            }, true);
            doc.addEventListener('keydown', e => {
                // ── SASA selection intercept for DESIGN panel ──
                // When SASA is active and user types/deletes in design, the visual
                // highlight is NOT a real browser selection so contentEditable can't
                // handle it. We intercept the key, perform the edit in the CODE
                // editor, then sync back to design.
                if (sasaSelectionActive) {
                    const isPrintable = e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey;
                    const isDelete = (e.key === 'Delete' || e.key === 'Backspace');
                    const isPaste = (e.ctrlKey || e.metaKey) && (e.key === 'v' || e.key === 'V');
                    if (isPrintable || isDelete || isPaste) {
                        e.preventDefault();
                        e.stopPropagation();
                        const doSasaEdit = (rawText) => {
                            const range = getSasaRange();
                            if (!range) { deactivateSasa(); return; }
                            // Strip SASA visual highlights from DOM BEFORE saving snapshot
                            clearSasaDesignHighlight(doc);
                            // Save the current design state to undo stack BEFORE the SASA edit
                            designSaveSnapshot();
                            // Wrap typed/pasted text in <p class="text_obisnuit"><em>…</em></p>
                            const insertText = rawText.length > 0 ? wrapTextForSasa(rawText) : '';
                            deactivateSasa();
                            isSyncFromDesign = true;
                            editor.replaceRange(insertText, range.from, range.to);
                            isSyncFromDesign = false;
                            applyCodeToDesignPanel();
                            // Position the CODE cursor between SASA markers
                            // (for when user switches to code/split later).
                            positionCursorBetweenSasa();
                            if (viewMode === 'design') {
                                // Position the DESIGN caret inside the last <em>
                                // between SASA markers so subsequent typing stays
                                // inside the formatted paragraph.
                                positionDesignCaretInSasaEm();
                                doc.body.focus();
                            } else {
                                editor.focus();
                            }
                            // Block any syncFromDesign triggered by the keyup debounce
                            isSyncFromCode = true;
                            setTimeout(() => { isSyncFromCode = false; }, 200);
                        };
                        if (isPaste) {
                            (navigator.clipboard && navigator.clipboard.readText
                                ? navigator.clipboard.readText()
                                : Promise.resolve('')
                            ).then(clipText => doSasaEdit(clipText || ''))
                                .catch(() => deactivateSasa());
                        } else {
                            doSasaEdit(isPrintable ? e.key : '');
                        }
                        return;
                    }
                }
                // ── Enter key → insert <p class="text_obisnuit"> instead of <br> ──
                if (e.key === 'Enter' && !e.ctrlKey && !e.metaKey && !e.shiftKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    designSaveSnapshot();
                    const win = iframe.contentWindow;
                    const sel = win && win.getSelection();
                    if (sel && sel.rangeCount > 0) {
                        const range = sel.getRangeAt(0);
                        range.deleteContents();
                        // Create new <p class="text_obisnuit"> with a zero-width space
                        // so the caret can be placed inside it
                        const newP = doc.createElement('p');
                        newP.className = 'text_obisnuit';
                        newP.appendChild(doc.createElement('br'));
                        // Insert the new paragraph after the current block
                        // Find the closest block-level parent
                        let block = range.startContainer;
                        if (block.nodeType === Node.TEXT_NODE) block = block.parentNode;
                        while (block && block !== doc.body &&
                            !/^(P|DIV|H[1-6]|BLOCKQUOTE|LI|SECTION|ARTICLE|HEADER|FOOTER|MAIN|TABLE|UL|OL|PRE|FIGURE|FIGCAPTION|NAV|ASIDE|DETAILS|SUMMARY|FORM|FIELDSET|ADDRESS|HGROUP|SEARCH|DL|DT|DD)$/i.test(block.tagName)) {
                            block = block.parentNode;
                        }
                        if (block && block !== doc.body) {
                            // Split: move content after cursor into the new paragraph
                            const afterRange = doc.createRange();
                            afterRange.setStart(range.startContainer, range.startOffset);
                            afterRange.setEnd(block, block.childNodes.length);
                            const afterContents = afterRange.extractContents();
                            // Check if afterContents has real content
                            const hasContent = afterContents.textContent.trim().length > 0 ||
                                afterContents.querySelector('img, br, hr, input, svg, video, audio, iframe, canvas, embed, object');
                            if (hasContent) {
                                // Move trailing content into the new <p>
                                newP.innerHTML = '';
                                newP.appendChild(afterContents);
                                // If the new p ends up empty after extraction, add <br>
                                if (!newP.textContent.trim() && !newP.querySelector('img, br, hr')) {
                                    newP.appendChild(doc.createElement('br'));
                                }
                            }
                            // If original block is now empty, add <br> placeholder
                            if (!block.textContent.trim() && !block.querySelector('img, br, hr')) {
                                block.appendChild(doc.createElement('br'));
                            }
                            block.parentNode.insertBefore(newP, block.nextSibling);
                        } else {
                            // Fallback: just insert at cursor position
                            range.insertNode(newP);
                        }
                        // Place cursor at start of the new paragraph
                        const newRange = doc.createRange();
                        newRange.setStart(newP, 0);
                        newRange.collapse(true);
                        sel.removeAllRanges();
                        sel.addRange(newRange);
                        // Scroll the new paragraph into view
                        newP.scrollIntoView({ block: 'nearest' });
                        cleanupParagraphBoundaryBrArtifacts(doc);
                    }
                    clearTimeout(designInputDebounceTimer);
                    designInputDebounceTimer = setTimeout(syncFromDesign, 80);
                    return;
                }
                // Diacritice românești
                let _diac = null;
                if (e.ctrlKey && !e.altKey && !e.metaKey) {
                    if (!e.shiftKey && e.key === 'a') _diac = 'ă';
                    else if (!e.shiftKey && e.key === 'i') _diac = 'î';
                    else if (e.shiftKey && e.key === 'S') _diac = 'ș';
                } else if (e.altKey && !e.ctrlKey && !e.metaKey) {
                    if (!e.shiftKey && e.key === 't') _diac = 'ț';
                    else if (e.shiftKey && e.key === 'T') _diac = 'Ț';
                    else if (!e.shiftKey && e.key === 's') _diac = 'Ș';
                    else if (!e.shiftKey && e.key === 'i') _diac = 'Î';
                    else if (!e.shiftKey && e.key === 'a') _diac = 'â';
                }
                if (_diac) {
                    e.preventDefault();
                    e.stopPropagation();
                    doc.execCommand('insertText', false, _diac);
                    return;
                }
                if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (window.parent && typeof window.parent.saveFile === 'function') {
                        window.parent.saveFile();
                    }
                } else if ((e.ctrlKey || e.metaKey) && (e.key === 'z' || e.key === 'Z') && !e.shiftKey) {
                    // Route Ctrl+Z through the parent's CodeMirror-based undo so that
                    // property-panel changes (font size, color) — which only add to the
                    // CodeMirror history, not the browser's native undo stack — are
                    // undone correctly too.
                    e.preventDefault();
                    if (window.parent && typeof window.parent.doUndoFromDesign === 'function') {
                        window.parent.doUndoFromDesign();
                    }
                } else if ((e.ctrlKey || e.metaKey) &&
                    (e.key === 'y' || e.key === 'Y' ||
                        (e.shiftKey && (e.key === 'z' || e.key === 'Z')))) {
                    e.preventDefault();
                    if (window.parent && typeof window.parent.doRedoFromDesign === 'function') {
                        window.parent.doRedoFromDesign();
                    }
                }
            }, true);
            // Re-apply CROP highlight after iframe reload (if active)
            if (cropHighlightActive) highlightSasaInDesign('crop');
            // Populate class list and apply CSS styling to combo options
            // (safe here because iframe is stable and fully loaded)
            refreshClassListFromCode();
            styleClassOptions();
        }

        function cancelPreviewUpdateForUndoRedo() {
            clearTimeout(previewDebounceTimer);
            previewDebounceTimer = null;
            skipPreviewUpdateUntil = Date.now() + 700;
        }

        // Flush any pending design-to-code sync immediately
        function flushPendingDesignSync(force) {
            if (designInputDebounceTimer) {
                clearTimeout(designInputDebounceTimer);
                designInputDebounceTimer = null;
            }
            syncFromDesign(!!force);
        }

        // Apply current CodeMirror code back to the design panel body (fast, no iframe reload)
        function applyCodeToDesignPanel() {
            clearTimeout(designInputDebounceTimer);
            designInputDebounceTimer = null;
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body) return;
            const src = editor.getValue();
            const bodyMatch = /<body[^>]*>([\s\S]*)<\/body>/i.exec(src);
            if (!bodyMatch) return;
            isApplyingUndoRedo = true;
            isSyncFromCode = true;
            doc.body.innerHTML = bodyMatch[1];
            isSyncFromCode = false;
            isApplyingUndoRedo = false;
            // Re-apply CROP highlight if active (innerHTML rebuild destroys styles)
            if (cropHighlightActive) highlightSasaInDesign('crop');
        }

        function doUndoFromDesign() {
            if (!editor) return;
            // In Code view (sau pentru fisiere non-HTML), folosim undo-ul nativ al editorului de cod.
            if (!isCurrentFileHtml() || viewMode === 'code') {
                try { editor.undo(); } catch (e) { }
                return;
            }
            const iframe = document.getElementById('preview');
            if (!iframe || !iframe.contentDocument || !iframe.contentDocument.body) return;
            // Flush any pending design→code sync so CodeMirror is in sync
            flushPendingDesignSync();
            // Capture the very latest state (in case typing hasn't been snapshot-ted yet)
            designSaveSnapshot();
            if (designUndoStack.length === 0) {
                if (designRedoStack.length > 0) {
                    recalcActiveTabDirtyFromEditor();
                    return;
                }
                doCodeHistoryUndoRedoFromDesign('undo');
                return;
            }
            cancelPreviewUpdateForUndoRedo();
            // Push current state to redo (with current scroll position)
            const current = getDesignBodyHtml();
            if (current !== null) designRedoStack.push({ html: current, scrollY: getDesignScrollY() });
            // Pop previous state (object with html + scrollY)
            const prevEntry = designUndoStack.pop();
            const prev = prevEntry.html;
            const restoreScrollY = prevEntry.scrollY;
            // Apply to iframe
            const win = iframe.contentWindow;
            isApplyingUndoRedo = true;
            isSyncFromCode = true;
            iframe.contentDocument.body.innerHTML = prev;
            // Scroll to the position where this state was originally saved
            if (win) {
                win.scrollTo(0, restoreScrollY);
                // Retry after layout settles (images/CSS may shift content)
                setTimeout(() => { try { win.scrollTo(0, restoreScrollY); } catch(e){} }, 50);
            }
            isSyncFromCode = false;
            isApplyingUndoRedo = false;
            // Snapshot the EXACT normalized browser state so the 500ms timer doesn't falsely detect changes
            lastDesignSnapshot = getDesignBodyHtml();
            // Sync the reverted body back to the code editor.
            // If the undo stack is now empty, we're back at the initial state.
            // Restore the exact original code (designCleanCode) instead of using
            // syncFromDesign, because the browser serializes innerHTML differently
            // from the original source, which would make the dirty check fail.
            if (designUndoStack.length === 0 && designCleanCode !== null) {
                // We've undone ALL design changes — restore exact original code.
                // Use setValue for guaranteed exact restoration (replaceRange can have
                // subtle trailing-newline issues that prevent content from matching).
                isSyncFromDesign = true;
                _isRestoringTab = true;
                editor.setValue(designCleanCode);
                _isRestoringTab = false;
                isSyncFromDesign = false;
                recalcActiveTabDirtyFromEditor();
            } else {
                syncFromDesign();
                // Check if body matches the initial browser-serialized state
                // (handles cases where the stack didn't fully empty but content is back to original)
                if (designCleanBodyHtml !== null && designCleanCode !== null) {
                    const currentBody = getDesignBodyHtml();
                    if (currentBody === designCleanBodyHtml) {
                        isSyncFromDesign = true;
                        _isRestoringTab = true;
                        editor.setValue(designCleanCode);
                        _isRestoringTab = false;
                        isSyncFromDesign = false;
                        recalcActiveTabDirtyFromEditor();
                    }
                }
            }
            // Re-apply CROP highlight after undo (innerHTML rebuild destroys styles)
            if (cropHighlightActive) highlightSasaInDesign('crop');
            // Sync code editor scroll to match the design panel position
            syncCodeScrollToDesignScroll(restoreScrollY);
            focusDesignPanel(iframe);
        }

        function doRedoFromDesign() {
            if (!editor) return;
            // In Code view (sau pentru fisiere non-HTML), folosim redo-ul nativ al editorului de cod.
            if (!isCurrentFileHtml() || viewMode === 'code') {
                try { editor.redo(); } catch (e) { }
                return;
            }
            const iframe = document.getElementById('preview');
            if (!iframe || !iframe.contentDocument || !iframe.contentDocument.body) return;
            flushPendingDesignSync();
            if (designRedoStack.length === 0) {
                doCodeHistoryUndoRedoFromDesign('redo');
                return;
            }
            cancelPreviewUpdateForUndoRedo();
            // Push current state to undo (with current scroll position)
            const current = getDesignBodyHtml();
            if (current !== null) {
                designUndoStack.push({ html: current, scrollY: getDesignScrollY() });
                if (designUndoStack.length > 1000) designUndoStack.shift();
            }
            // Pop next state from redo (object with html + scrollY)
            const nextEntry = designRedoStack.pop();
            const next = nextEntry.html;
            const restoreScrollY = nextEntry.scrollY;
            // Apply to iframe
            const win = iframe.contentWindow;
            isApplyingUndoRedo = true;
            isSyncFromCode = true;
            iframe.contentDocument.body.innerHTML = next;
            // Scroll to the position where this state was originally saved
            if (win) {
                win.scrollTo(0, restoreScrollY);
                setTimeout(() => { try { win.scrollTo(0, restoreScrollY); } catch(e){} }, 50);
            }
            isSyncFromCode = false;
            isApplyingUndoRedo = false;
            // Snapshot the EXACT normalized browser state so the 500ms timer doesn't falsely detect changes
            lastDesignSnapshot = getDesignBodyHtml();
            // Sync the redo-applied body back to the code editor
            syncFromDesign();
            // Force dirty state recalculation and tab update after redo
            if (activeTabId) {
                var _t = null;
                for (var _i = 0; _i < tabs.length; _i++) { if (tabs[_i].id === activeTabId) { _t = tabs[_i]; break; } }
                if (_t) {
                    var nowDirty = (normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(_t.originalContent));
                    // Also check against initial browser-serialized body
                    if (nowDirty && designCleanBodyHtml !== null && designCleanCode !== null) {
                        const currentBody = getDesignBodyHtml();
                        if (currentBody === designCleanBodyHtml) {
                            isSyncFromDesign = true;
                            _isRestoringTab = true;
                            editor.setValue(designCleanCode);
                            _isRestoringTab = false;
                            isSyncFromDesign = false;
                            nowDirty = (normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(_t.originalContent));
                        }
                    }
                    _t.isDirty = nowDirty;
                    isDirty = nowDirty;
                    renderTabs();
                }
            }
            // Re-apply CROP highlight after redo (innerHTML rebuild destroys styles)
            if (cropHighlightActive) highlightSasaInDesign('crop');
            // Sync code editor scroll to match the design panel position
            syncCodeScrollToDesignScroll(restoreScrollY);
            focusDesignPanel(iframe);
        }

        function focusDesignPanel(iframe) {
            try {
                if (editor && editor.getWrapperElement) {
                    editor.getWrapperElement().blur();
                }
                if (iframe && iframe.contentWindow) {
                    iframe.contentWindow.focus();
                    const doc = iframe.contentDocument;
                    if (doc && doc.body) {
                        doc.body.focus();
                    }
                }
            } catch (e) { }
        }

        function refocusDesignAfterUndoRedo(iframe) {
            focusDesignPanel(iframe);
            setTimeout(function () { focusDesignPanel(iframe); }, 0);
            setTimeout(function () { focusDesignPanel(iframe); }, 50);
            setTimeout(function () { focusDesignPanel(iframe); }, 150);
            setTimeout(function () { focusDesignPanel(iframe); }, 300);
        }

        function applyUndoRedoToDesign(savedCodeScroll, savedIframeScroll) {
            const iframe = document.getElementById('preview');
            const doc = iframe && iframe.contentDocument;
            if (!doc || !doc.body || !editor || !isCurrentFileHtml()) return;
            const win = iframe.contentWindow;
            const scrollX = savedIframeScroll ? savedIframeScroll.x : (win.scrollX || 0);
            const scrollY = savedIframeScroll ? savedIframeScroll.y : (win.scrollY || 0);
            const full = editor.getValue();
            const bodyRe = /<body\b[^>]*>([\s\S]*?)<\/body>/i;
            const m = bodyRe.exec(full);
            if (!m) return;
            isApplyingUndoRedo = true;
            clearTimeout(designInputDebounceTimer);
            designInputDebounceTimer = null;
            isSyncFromCode = true;
            doc.body.innerHTML = m[1];
            win.scrollTo(scrollX, scrollY);
            if (savedCodeScroll) {
                editor.scrollTo(savedCodeScroll.left, savedCodeScroll.top);
            }
            isSyncFromCode = false;
            isApplyingUndoRedo = false;
        }

        function recalcActiveTabDirtyFromEditor() {
            if (!activeTabId || !editor) return;
            var _t = null;
            for (var _i = 0; _i < tabs.length; _i++) {
                if (tabs[_i].id === activeTabId) { _t = tabs[_i]; break; }
            }
            if (!_t) return;
            var nowDirty = (normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(_t.originalContent));
            _t.editorContent = editor.getValue();
            _t.isDirty = nowDirty;
            _t.undoHistory = editor.getDoc().getHistory();
            isDirty = nowDirty;
            renderTabs();
        }

        function doCodeHistoryUndoRedoFromDesign(kind) {
            if (!editor) return false;
            var hsz = null;
            try {
                hsz = editor.getDoc() && editor.getDoc().historySize ? editor.getDoc().historySize() : null;
            } catch (eHist) { hsz = null; }
            if (!hsz || (kind === 'undo' && hsz.undo <= 0) || (kind === 'redo' && hsz.redo <= 0)) return false;

            const iframe = document.getElementById('preview');
            const savedCodeScroll = editor.getScrollInfo ? editor.getScrollInfo() : null;
            const savedIframeScroll = iframe && iframe.contentWindow
                ? { x: iframe.contentWindow.scrollX || 0, y: iframe.contentWindow.scrollY || 0 }
                : null;
            cancelPreviewUpdateForUndoRedo();
            isApplyingUndoRedo = true;
            try {
                if (kind === 'undo') editor.undo();
                else editor.redo();
            } catch (e) {
                isApplyingUndoRedo = false;
                return false;
            }
            isApplyingUndoRedo = false;
            applyUndoRedoToDesign(savedCodeScroll, savedIframeScroll);
            recalcActiveTabDirtyFromEditor();
            lastDesignSnapshot = getDesignBodyHtml();
            return true;
        }

        // Called by the injected DOMContentLoaded script in the preview iframe,
        // so makeDesignEditable runs as soon as the DOM is parsed — not after
        // all external CSS/fonts finish loading (which can take 30+ seconds).
        window.__previewDOMReady = null;
        var _previewRequestSeq = 0;

        // When set, updatePreview will restore this scroll position after reload.
        var _pendingPreviewScroll = null;

        function updatePreview() {
            const iframe = document.getElementById('preview');
            const previewRequestId = ++_previewRequestSeq;
            const requestedFile = currentFile;
            const requestedTabId = activeTabId;

            // Files with a known path on disk → use PHP preview.
            // PHP strips scripts/loaders, rebuilds clean HTML, and serves it
            // as a normal HTTP response so relative CSS/images resolve correctly
            // (blob: URLs have issues with "preferred" stylesheets and encoded paths).
            if (currentFile) {
                let done = false;
                const previewToken = String(previewRequestId);
                const scrollToRestore = _pendingPreviewScroll;
                _pendingPreviewScroll = null;
                const doEdit = (loadedUrl) => {
                    if (done || previewRequestId !== _previewRequestSeq ||
                        requestedTabId !== activeTabId || requestedFile !== currentFile) return;
                    let actualUrl = (typeof loadedUrl === 'string') ? loadedUrl : '';
                    if (!actualUrl) {
                        try { actualUrl = iframe.contentWindow.location.href || ''; } catch (e) { actualUrl = ''; }
                    }
                    // A previous tab may finish DOMContentLoaded after this callback was
                    // replaced. Ignore it unless the loaded document belongs to this request.
                    if (actualUrl && actualUrl.indexOf('previewToken=' + previewToken) === -1) return;
                    done = true;
                    if (isCurrentFileHtml()) makeDesignEditable();
                    // Dacă un tab de browser este deschis, ne asigurăm că iframe-ul lui rămâne pe URL-ul curent din tab
                    const frame = document.getElementById('browserFrame');
                    if (frame) {
                        for (var i = 0; i < tabs.length; i++) {
                            if (tabs[i].id === activeTabId && tabs[i].type === 'browser' && tabs[i].browserUrl) {
                                frame.src = buildProxyUrl(tabs[i].browserUrl);
                                break;
                            }
                        }
                    }
                    if (scrollToRestore && iframe.contentWindow) {
                        iframe.contentWindow.scrollTo(scrollToRestore.x, scrollToRestore.y);
                        // Retry after a short delay in case layout shifts from late-loading CSS
                        setTimeout(() => {
                            if (iframe.contentWindow) iframe.contentWindow.scrollTo(scrollToRestore.x, scrollToRestore.y);
                        }, 50);
                    }
                };
                window.__previewDOMReady = doEdit;
                iframe.onload = function () {
                    let loadedUrl = '';
                    try { loadedUrl = iframe.contentWindow.location.href || ''; } catch (e) { loadedUrl = ''; }
                    doEdit(loadedUrl);
                };
                iframe.src = '?action=preview&file=' + encodeURIComponent(currentFile) +
                    '&t=' + Date.now() + '&previewToken=' + previewToken;
                return;
            }

            // No currentFile (e.g. drag & drop without path match) → blob approach
            if (!editor) return;
            let content = editor.getValue();

            // ── Strip ALL JavaScript from the entire content ──
            content = content.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
            content = content.replace(/<script\b[^>]*\/>/gi, '');
            content = content.replace(/<noscript\b[^>]*>[\s\S]*?<\/noscript>/gi, '');

            // ── Collect stylesheets ──
            // Stil de rezerva pentru pagini fara CSS-ul site-ului (ex. pagina goala):
            // paragraful bold sa se vada bold. Pus primul, ca CSS-ul site-ului sa aiba prioritate.
            let allStyles = '<style type="text/css" id="editor-fallback">'
                + '.text_obisnuit2{font-weight:bold}'
                + 'html,body{min-height:100%}body{min-height:calc(100vh - 20px)}'
                + '</style>\n';
            const linkRe = /<link\b[^>]*\brel=["\']?stylesheet["\']?[^>]*\/?>/gi;
            let lm;
            while ((lm = linkRe.exec(content)) !== null) {
                let tag = lm[0];
                tag = tag.replace(/\s+on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*)/gi, '');
                tag = tag.replace(/\bmedia\s*=\s*["']?\s*print\s*["']?/i, 'media="all"');
                tag = tag.replace(/\s+title\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*)/gi, '');
                allStyles += tag + '\n';
            }
            const styleRe = /<style\b[^>]*>([\s\S]*?)<\/style>/gi;
            let sm;
            while ((sm = styleRe.exec(content)) !== null) {
                if (sm[1].trim()) allStyles += '<style type="text/css">' + sm[1] + '</style>\n';
            }

            // ── Override CSS — force ALL elements visible, hide loaders ──
            const editorOverride = '<style type="text/css" id="editor-override">'
                + 'html,body{visibility:visible!important;opacity:1!important}'
                + 'body{display:block!important}'
                + 'body *{visibility:visible!important;opacity:1!important;'
                + 'animation:none!important;transition:none!important}'
                + 'img{cursor:default!important}'
                + 'a img{cursor:pointer!important}'
                + '#preloader,.preloader,#loader,.loader,#loader-fade,'
                + '.loading-overlay,.page-loader,.loading-screen,'
                + '#loading-overlay,#page-loading,.site-loader,'
                + '.loader-container,.spinner,#spinner,'
                + '[class*="preload"],[id*="preload"],'
                + '[class*="page-load"],[id*="page-load"]'
                + '{display:none!important}'
                + '</style>\n';

            // ── Extract and sanitise body content ──
            const bodyOpenMatch = /<body\b[^>]*>/i.exec(content);
            if (bodyOpenMatch) {
                const bodyTagEnd = bodyOpenMatch.index + bodyOpenMatch[0].length;
                const lastBodyClose = content.toLowerCase().lastIndexOf('</body>');
                const bodyEnd = (lastBodyClose !== -1 && lastBodyClose >= bodyTagEnd)
                    ? lastBodyClose : content.length;
                let bodyInner = content.substring(bodyTagEnd, bodyEnd);
                bodyInner = bodyInner.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '');
                bodyInner = bodyInner.replace(/\s+on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*)/gi, '');
                bodyInner = bodyInner.replace(/\bhref\s*=\s*["']?\s*javascript\s*:[^"'>\s]*/gi, 'href="#"');
                let bodyTag = bodyOpenMatch[0].replace(/\s+on\w+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*)/gi, '');
                content = '<!DOCTYPE html><html><head>' + allStyles + editorOverride + '</head>'
                    + bodyTag + bodyInner + '</body></html>';
            }

            const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const scrollToRestore2 = _pendingPreviewScroll;
            _pendingPreviewScroll = null;
            iframe.onload = () => {
                makeDesignEditable();
                if (scrollToRestore2 && iframe.contentWindow) {
                    iframe.contentWindow.scrollTo(scrollToRestore2.x, scrollToRestore2.y);
                }
                URL.revokeObjectURL(url);
            };
            iframe.src = url;
        }

        function hideOverlay() {
            const ov = document.getElementById('startOverlay');
            if (ov) ov.style.display = 'none';
        }

        // ── Butonul „Trimite E-mail”: confirmare → monitor_index.py in fundal → fereastra cu ce a afisat scriptul ──
        function showEmailConsole(title, text, color) {
            let dlg = document.getElementById('emailConsoleDialog');
            if (!dlg) {
                dlg = document.createElement('div');
                dlg.id = 'emailConsoleDialog';
                dlg.style.cssText = 'position:fixed;inset:0;z-index:100002;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55)';
                dlg.innerHTML =
                    '<div style="width:min(860px,calc(100% - 32px));max-height:85vh;display:flex;flex-direction:column;background:#1e1e1e;border:1px solid #444;border-radius:10px;box-shadow:0 20px 60px rgba(0,0,0,.6)">' +
                    '<div style="display:flex;align-items:center;gap:10px;padding:12px 16px;border-bottom:1px solid #333">' +
                    '<b class="ec-title" style="flex:1;color:#eee;font-size:17px"></b>' +
                    '<button class="btn btn-ghost ec-close">Închide</button></div>' +
                    '<pre class="ec-body" style="margin:0;padding:16px 18px;overflow:auto;white-space:pre-wrap;word-break:break-word;' +
                    'font:15px/1.5 Consolas,\'Courier New\',monospace"></pre></div>';
                document.body.appendChild(dlg);
                const close = function () { if (!dlg.dataset.busy) dlg.style.display = 'none'; };
                dlg.querySelector('.ec-close').onclick = close;
                dlg.addEventListener('click', function (e) { if (e.target === dlg) close(); });
            }
            dlg.style.display = 'flex';
            dlg.querySelector('.ec-title').textContent = title;
            const body = dlg.querySelector('.ec-body');
            body.style.color = color || '#38bdf8';
            body.textContent = text;
            return dlg;
        }
        // fereastra proprie de confirmare (in locul confirm()-ului din Chrome) → Promise<true|false>
        function confirmEmailDialog(info) {
            return new Promise(function (resolve) {
                const old = document.getElementById('emailConfirmDialog');
                if (old) old.remove();
                const esc = function (s) { return String(s || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
                const dlg = document.createElement('div');
                dlg.id = 'emailConfirmDialog';
                dlg.style.cssText = 'position:fixed;inset:0;z-index:100003;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);backdrop-filter:blur(2px)';
                dlg.innerHTML =
                    '<div style="width:min(520px,calc(100% - 32px));background:#1f2330;border:1px solid #3a4152;border-radius:14px;box-shadow:0 24px 70px rgba(0,0,0,.6);font-family:Segoe UI,Arial,sans-serif;overflow:hidden">' +
                    '<div style="display:flex;align-items:center;gap:12px;padding:18px 22px 6px">' +
                    '<span style="display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;background:rgba(34,197,94,.15);font-size:20px">✉️</span>' +
                    '<b style="color:#f1f5f9;font-size:19px">Trimit articolul pe email?</b></div>' +
                    '<div style="padding:8px 22px 4px;color:#94a3b8;font-size:14px">Ultimul articol din <code style="color:#cbd5e1">ro/index.html</code>:</div>' +
                    '<div style="margin:10px 22px 4px;padding:14px 16px;background:#161a24;border:1px solid #2f3646;border-left:4px solid #22c55e;border-radius:8px">' +
                    (info.title ? '<div style="color:#f8fafc;font-size:17px;font-weight:600;margin-bottom:6px">' + esc(info.title) + '</div>' : '') +
                    '<a href="' + esc(info.link) + '" target="_blank" rel="noopener" style="color:#38bdf8;font-size:14px;word-break:break-all;text-decoration:none">' + esc(info.link) + '</a></div>' +
                    '<div style="display:flex;justify-content:flex-end;gap:10px;padding:18px 22px 20px">' +
                    '<button type="button" class="ecf-cancel" style="padding:9px 20px;border-radius:8px;border:1px solid #475066;background:transparent;color:#e2e8f0;font-size:15px;cursor:pointer">Anulează</button>' +
                    '<button type="button" class="ecf-ok" style="padding:9px 22px;border-radius:8px;border:0;background:#16a34a;color:#fff;font-size:15px;font-weight:600;cursor:pointer">Trimite e-mail</button>' +
                    '</div></div>';
                document.body.appendChild(dlg);
                const done = function (val) {
                    document.removeEventListener('keydown', onKey, true);
                    dlg.remove();
                    resolve(val);
                };
                const onKey = function (e) {
                    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(false); }
                    else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); done(true); }
                };
                document.addEventListener('keydown', onKey, true);
                dlg.querySelector('.ecf-ok').onclick = function () { done(true); };
                dlg.querySelector('.ecf-cancel').onclick = function () { done(false); };
                dlg.addEventListener('click', function (e) { if (e.target === dlg) done(false); });
                const ok = dlg.querySelector('.ecf-ok');
                ok.onmouseenter = function () { ok.style.background = '#15803d'; };
                ok.onmouseleave = function () { ok.style.background = '#16a34a'; };
                ok.focus();
            });
        }
        async function sendLatestArticleEmail() {
            const btn = document.getElementById('btnSendArticleEmail');
            if (btn && btn.disabled) return;
            const post = async function (extra) {
                const body = new URLSearchParams(extra || {});
                const res = await fetch('?action=sendArticleEmail', { method: 'POST', body: body });
                return res.json();
            };
            let info;
            try { info = await post({ check: '1' }); }
            catch (e) { showErrorPopup('Nu pot contacta serverul: ' + e.message); return; }
            if (!info.ok) { showErrorPopup(info.error || 'Eroare necunoscută.'); return; }
            if (!info.link) {
                showErrorPopup('Nu am găsit niciun articol la începutul listei din ro/index.html.\nNu trimit nimic.');
                return;
            }
            if (!await confirmEmailDialog(info)) return;
            if (btn) { btn.disabled = true; btn.style.opacity = '.6'; }
            const dlg = showEmailConsole('Trimite E-mail', 'Se trimite emailul în fundal...\n\n' + info.link, '#facc15');
            dlg.dataset.busy = '1';
            try {
                const r = await post({});
                delete dlg.dataset.busy;
                if (!r.ok) {
                    showEmailConsole('Trimite E-mail — eroare', r.error || 'Eroare necunoscută.', '#f87171');
                    return;
                }
                let text = String(r.output || '').replace(/^\s+/, '').replace(/\s+$/, '');
                if (r.errors && r.errors.trim()) text += '\n\n--- erori ---\n' + r.errors.trim();
                if (r.timedOut) text += '\n\n✗ Scriptul a durat prea mult și a fost oprit.';
                text += '\n>>>';
                showEmailConsole(r.sent ? 'Email trimis ✓' : 'Emailul NU a fost confirmat ✗', text, r.sent ? '#38bdf8' : '#f87171');
            } catch (e) {
                delete dlg.dataset.busy;
                showEmailConsole('Trimite E-mail — eroare', 'Eroare: ' + e.message, '#f87171');
            } finally {
                if (btn) { btn.disabled = false; btn.style.opacity = ''; }
            }
        }

        // ── Butonul „Translate”: gaseste articolele din ro/ netraduse → confirmare → TRADUCE TOT - automat.py in fundal
        //    → fereastra cu jurnalul scriptului, actualizat in timp real, pana la final ──
        function confirmTranslateDialog(files) {
            return new Promise(function (resolve) {
                const old = document.getElementById('translateConfirmDialog');
                if (old) old.remove();
                const esc = function (s) { return String(s || '').replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
                const dlg = document.createElement('div');
                dlg.id = 'translateConfirmDialog';
                dlg.style.cssText = 'position:fixed;inset:0;z-index:100003;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.55);backdrop-filter:blur(2px)';
                dlg.innerHTML =
                    '<div style="width:min(560px,calc(100% - 32px));background:#1f2330;border:1px solid #3a4152;border-radius:14px;box-shadow:0 24px 70px rgba(0,0,0,.6);font-family:Segoe UI,Arial,sans-serif;overflow:hidden">' +
                    '<div style="display:flex;align-items:center;gap:12px;padding:18px 22px 6px">' +
                    '<span style="display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:50%;background:rgba(8,145,178,.18);font-size:20px">🌐</span>' +
                    '<b style="color:#f1f5f9;font-size:19px">Traduc ' + files.length + (files.length === 1 ? ' articol' : ' articole') + ' în engleză?</b></div>' +
                    '<div style="padding:8px 22px 4px;color:#94a3b8;font-size:14px">Articole din <code style="color:#cbd5e1">ro/</code> netraduse în <code style="color:#cbd5e1">en/</code>:</div>' +
                    '<div style="margin:10px 22px 4px;padding:12px 16px;max-height:240px;overflow:auto;background:#161a24;border:1px solid #2f3646;border-left:4px solid #0891b2;border-radius:8px;color:#e2e8f0;font:14px/1.7 Consolas,monospace">' +
                    files.map(function (f) { return esc(f); }).join('<br>') + '</div>' +
                    '<div style="padding:10px 22px 0;color:#94a3b8;font-size:13px">Backup, traducere, Pasul 0–5, apoi fișierele ajung în <code style="color:#cbd5e1">c:\\Folder1\\fisiere_html</code> (golit înainte de Pasul 5).</div>' +
                    '<div style="display:flex;justify-content:flex-end;gap:10px;padding:18px 22px 20px">' +
                    '<button type="button" class="tcf-cancel" style="padding:9px 20px;border-radius:8px;border:1px solid #475066;background:transparent;color:#e2e8f0;font-size:15px;cursor:pointer">Anulează</button>' +
                    '<button type="button" class="tcf-ok" style="padding:9px 22px;border-radius:8px;border:0;background:#0891b2;color:#fff;font-size:15px;font-weight:600;cursor:pointer">Traduce</button>' +
                    '</div></div>';
                document.body.appendChild(dlg);
                const done = function (val) {
                    document.removeEventListener('keydown', onKey, true);
                    dlg.remove();
                    resolve(val);
                };
                const onKey = function (e) {
                    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); done(false); }
                    else if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); done(true); }
                };
                document.addEventListener('keydown', onKey, true);
                dlg.querySelector('.tcf-ok').onclick = function () { done(true); };
                dlg.querySelector('.tcf-cancel').onclick = function () { done(false); };
                dlg.addEventListener('click', function (e) { if (e.target === dlg) done(false); });
                dlg.querySelector('.tcf-ok').focus();
            });
        }
        let _translatePollTimer = null;
        function pollTranslateLog() {
            const btn = document.getElementById('btnTranslateSite');
            if (_translatePollTimer) clearTimeout(_translatePollTimer);
            const tick = async function () {
                let r;
                try { r = await (await fetch('?action=translateSiteStatus', { cache: 'no-store' })).json(); }
                catch (e) { _translatePollTimer = setTimeout(tick, 3000); return; }
                const text = String(r.log || '').replace(/\[\[SFARSIT cod=-?\d+\]\]\s*$/, '').replace(/\s+$/, '');
                const dlg = document.getElementById('emailConsoleDialog');
                const visible = dlg && dlg.style.display !== 'none' && /^Translate/.test(dlg.querySelector('.ec-title').textContent);
                if (r.done) {
                    _translatePollTimer = null;
                    if (btn) { btn.disabled = false; btn.style.opacity = ''; }
                    showEmailConsole(r.success ? 'Translate — gata ✓ (design nou + publicat în ro/en și pe FTP)' : 'Translate — oprit ✗',
                        text + '\n>>>', r.success ? '#38bdf8' : '#f87171');
                } else {
                    if (visible) {
                        const body = dlg.querySelector('.ec-body');
                        const atEnd = body.scrollTop + body.clientHeight >= body.scrollHeight - 30;
                        dlg.querySelector('.ec-title').textContent = 'Translate — rulează…';
                        body.textContent = text || 'Pornesc scriptul...';
                        if (atEnd) body.scrollTop = body.scrollHeight;
                    }
                    _translatePollTimer = setTimeout(tick, 1500);
                }
            };
            tick();
        }
        let categoryPairSyncPromise = null;
        let rssGenerating = false;
        async function generateRssFeeds(button) {
            if (rssGenerating) return;
            rssGenerating = true;
            button.disabled = true;
            showEmailConsole('RSS — se generează…', 'Generez fluxurile EN și RO în Principal 2022…', '#facc15');
            try {
                const r = await (await fetch('?action=generateRSS', {method:'POST'})).json();
                showEmailConsole(r.ok ? 'RSS — gata' : 'RSS — eroare', r.log || r.error, r.ok ? '#4ade80' : '#f87171');
            } catch (e) { showEmailConsole('RSS — eroare', e.message, '#f87171'); }
            finally { button.disabled = false; rssGenerating = false; }
        }
        // Recuperările/corectările făcute automat rămân în fereastră până apeși „Am înțeles”
        // (raportul de pe server se suprascrie la rularea următoare și altfel nu le-ai mai vedea).
        function pendingCategoryChanges(newChanges) {
            let pending = [];
            try { pending = JSON.parse(localStorage.getItem('categoryPairPendingChanges') || '[]'); } catch (_) { pending = []; }
            const seen = new Set(pending.map(c => JSON.stringify(c)));
            for (const change of newChanges || []) {
                const key = JSON.stringify(change);
                if (!seen.has(key)) { pending.push(change); seen.add(key); }
            }
            localStorage.setItem('categoryPairPendingChanges', JSON.stringify(pending));
            return pending;
        }
        // Cardul unei propuneri RO–EN, pe tipuri: „Categorie greșită”, „Categorie și dată greșite”,
        // „Dată greșită”. Ce e acum greșit e pe roșu, ce se pune la OK (luat din RO) pe verde.
        function categoryProposalDetails(p, card) {
            const kinds = {
                'categorie': { title: 'Categorie greșită', color: '#f59e0b', bg: '#2a2112' },
                'categorie+data': { title: 'Categorie și dată greșite', color: '#f87171', bg: '#2b1618' },
                'data': { title: 'Dată greșită', color: '#60a5fa', bg: '#132235' }
            };
            const k = kinds[p.kind] || kinds.categorie;
            card.style.borderColor = k.color;
            card.style.background = k.bg;
            const wrap = document.createElement('div');
            wrap.style.margin = '0 0 12px';
            const el = (tag, css, text) => { const n = document.createElement(tag); if (css) n.style.cssText = css; if (text != null) n.textContent = text; return n; };
            wrap.appendChild(el('div', 'font:700 17px system-ui;color:' + k.color + ';margin-bottom:6px', k.title));
            wrap.appendChild(el('div', 'color:#cbd5e1;font-size:14px;margin-bottom:10px', 'en/' + p.article + '  ↔  ro/' + p.ro_article + ' (categoria RO: ' + p.ro_category + ')'));
            const row = (label, wrong, right) => {
                const r = el('div', 'display:grid;grid-template-columns:110px 1fr;gap:4px 10px;align-items:baseline;margin:6px 0');
                r.appendChild(el('span', 'color:#94a3b8;font-size:13px;text-transform:uppercase;letter-spacing:.04em', label));
                const vals = el('div');
                vals.appendChild(el('div', 'color:#fca5a5;font:14px ui-monospace,Consolas,monospace', '✗ ' + wrong));
                vals.appendChild(el('div', 'color:#86efac;font:14px ui-monospace,Consolas,monospace', '✓ ' + right));
                r.appendChild(vals);
                wrap.appendChild(r);
            };
            if (p.kind !== 'data') {
                const listed = (p.category_listed || []);
                const now = [];
                if (p.category_line && p.category_line !== p.category_correct) now.push('linkul din articol: ' + p.category_line);
                if (!(listed.length === 1 && listed[0] === p.category_correct)) now.push('blocul este în: ' + (listed.join(', ') || 'nicio categorie'));
                row('Categorie', now.join('; ') || p.category_line, 'en/' + p.category_correct + ' (din ro/' + p.ro_category + ')');
            }
            if (p.date_correct) row('Dată', p.date_current || '(lipsă)', p.date_correct + ' (din ro/' + p.ro_article + ', în engleză)');
            const fix = p.kind === 'data'
                ? 'La „OK, aplică”: pun data din RO, în engleză, în articol, în blocul din categorie și în index.'
                : 'La „OK, aplică”: corectez linkul de categorie din articol, pun blocul doar în categoria corectă'
                  + (p.date_correct ? ' și preiau data din RO (articol, bloc din categorie, index).' : '.');
            wrap.appendChild(el('div', 'color:#e2e8f0;font-size:14px;margin-top:8px', fix));
            return wrap;
        }
        // force: la pornire și după „OK, aplică” fereastra se arată din nou cât timp problema nu e rezolvată.
        async function repairCategoryPairFlag(correction, button, status) {
            const sitePath = 'e:/Carte/BB/17 - Site Leadership/Principal/' + correction.path;
            const openTab = tabs.find(t => normPathLoose(t.filePath) === normPathLoose(sitePath));
            if (openTab && openTab.isDirty) {
                showEmailConsole('Reparare amanata', 'Fisierul ' + correction.path + ' are modificari nesalvate. Salveaza-l, apoi apasa din nou Repară.', '#f87171');
                return;
            }
            button.disabled = true;
            button.textContent = 'Se repara...';
            try {
                const body = new URLSearchParams({ file: correction.path, flagLang: correction.lang, flagTarget: correction.correct });
                const response = await fetch('?action=repairArticleIdentity', { method: 'POST', body });
                const result = await response.json();
                if (!response.ok || !result.ok) throw new Error(result.error || ('HTTP ' + response.status));
                button.textContent = 'Reparat';
                button.style.background = '#166534';
                status.textContent = result.changed
                    ? 'Canonicalul si steagul ' + correction.lang.toUpperCase() + ' au fost aliniate cu numele corect.'
                    : 'Canonicalul si steagul ' + correction.lang.toUpperCase() + ' erau deja corecte.';
                status.style.color = '#86efac';
                await dateSyncRefreshTab(openTab ? openTab.filePath : sitePath);
                if (categoryPairSyncPromise) {
                    try { await categoryPairSyncPromise; } catch (_) { }
                    await new Promise(resolve => setTimeout(resolve, 0));
                }
                try { await syncCategoryPairs([], true); }
                catch (e) {
                    status.textContent += ' Reverificarea automata nu a raspuns: ' + e.message;
                    status.style.color = '#fcd18b';
                }
            } catch (e) {
                button.disabled = false;
                button.textContent = 'Repară';
                status.textContent = 'Nu s-a putut repara: ' + e.message;
                status.style.color = '#fca5a5';
            }
        }

        function presentCategoryPairReport(result, force) {
            if (postponeValidation('category-pairs', () => syncCategoryPairs([], force))) return;
            const changes = pendingCategoryChanges(result.changes), issues = result.issues || [], proposals = result.proposals || [];
            if (!changes.length && !issues.length && !proposals.length) {
                localStorage.removeItem('categoryPairLastReport');
                const oldReport = document.getElementById('categoryPairReport');
                if (oldReport) oldReport.remove();
                return;
            }
            const signature = JSON.stringify(['clear-flags-v4', changes, issues, proposals]);
            if (!force && localStorage.getItem('categoryPairLastReport') === signature) return;
            localStorage.setItem('categoryPairLastReport', signature);
            let dialog = document.getElementById('categoryPairReport');
            if (dialog) dialog.remove();
            dialog = document.createElement('dialog'); dialog.id = 'categoryPairReport';
            dialog.style.cssText = 'margin:auto;inset:0;max-width:820px;width:90%;max-height:80vh;overflow:auto;background:#202532;color:#fff;border:1px solid #536480;border-radius:14px;padding:24px;font:15px/1.6 system-ui';
            const title = document.createElement('h2'); title.textContent = 'Verificare categorii și corespondențe RO–EN'; dialog.appendChild(title);
            for (const change of changes) {
                const p = document.createElement('p');
                                if (change.recovered) { p.textContent = 'Recuperat: ' + change.articles.join(', ') + ' — linkul și blocul lipseau din categoria ' + change.file + ' și au fost adăugate la loc (după dată).'; p.style.color = '#86efac'; }
                                else p.textContent = 'Actualizat: ' + change.file + ' — adăugate: ' + change.articles.join(', ');
                                dialog.appendChild(p);
            }
            for (const proposal of proposals) {
                const card = document.createElement('div');
                card.style.cssText = 'margin:14px 0;padding:16px;border:1px solid #b45309;border-radius:10px;background:#2a2112;overflow-wrap:anywhere';
                const text = proposal.kind ? categoryProposalDetails(proposal, card) : document.createElement('p');
                if (!proposal.kind) { text.style.margin = '0 0 12px'; text.textContent = proposal.message; }
                const ok = document.createElement('button'); ok.textContent = 'OK, aplică';
                ok.style.cssText = 'padding:8px 20px;border:1px solid #86efac;border-radius:8px;background:#166534;color:#fff;font:600 15px system-ui;cursor:pointer';
                // dacă fereastra se redesenează cât timp se aplică, cardul rămâne „în lucru”
                if (categoryPairApplying.has(proposal.id)) { ok.disabled = true; ok.textContent = 'Se aplică…'; ok.style.opacity = '.7'; }
                ok.onclick = async () => {
                    categoryPairApplying.add(proposal.id);
                    ok.disabled = true; ok.style.opacity = '.7';
                    ok.textContent = categoryPairSyncPromise ? 'Aștept verificarea în curs…' : 'Se aplică…';
                    try { await syncCategoryPairs([proposal.id]); }
                    catch (e) { ok.disabled = false; ok.style.opacity = ''; ok.textContent = 'OK, aplică'; showEmailConsole('Corectare categorie — eroare', e.message, '#f87171'); }
                    finally { categoryPairApplying.delete(proposal.id); }
                };
                card.append(text, ok); dialog.appendChild(card);
            }
            const corrections = new Map();
            for (const issue of issues) {
                const canonical = issue.match(/^CANONICAL (RO|EN) diferit: (ro|en)\/([^ ]+) -> (.*?); trebuie sa indice (.+)$/);
                if (!canonical) continue;
                const lang = canonical[2].toLowerCase();
                const path = lang + '/' + canonical[3];
                corrections.set('canonical:' + path, {
                    lang, path, wrong: canonical[4], correct: canonical[3], canonicalOnly: true
                });
            }
            for (const issue of issues) {
                const m = issue.match(/^FLAGS (RO|EN) diferite: (ro|en)\/([^ ]+) → ([^;]+); (ro|en)\/([^ ]+) → (.+)$/);
                if (!m) continue;
                const lang = m[1].toLowerCase();
                const pair = { [m[2]]: m[3], [m[5]]: m[6] };
                if (!pair.ro || !pair.en) continue;
                for (const side of [{folder:m[2],file:m[3],value:m[4]}, {folder:m[5],file:m[6],value:m[7]}]) {
                    if (side.value === pair[lang]) continue;
                    const key = side.folder + '/' + side.file + ':' + lang;
                    corrections.set(key, {lang, pair, path: side.folder + '/' + side.file, wrong: side.value, correct: pair[lang]});
                }
            }
            const displayed = [...corrections.values()];
            for (const correction of displayed) {
                const card = document.createElement('div');
                card.style.cssText = 'margin:14px 0;padding:16px;border:1px solid #475569;border-radius:10px;background:#151c29;overflow-wrap:anywhere';
                const pair = document.createElement('p');
                pair.style.cssText = 'margin:0 0 8px;color:#93c5fd';
                pair.textContent = correction.canonicalOnly
                    ? 'Articol: ' + correction.path
                    : 'Pereche: ro/' + correction.pair.ro + ' ↔ en/' + correction.pair.en;
                const instruction = document.createElement('p'); instruction.style.margin = '0 0 8px';
                instruction.textContent = 'In fisierul ' + correction.path + ', canonicalul si steagul ' + correction.lang.toUpperCase() + ' trebuie sa indice:';
                const wrong = document.createElement('strong'); wrong.style.color = '#fca5a5'; wrong.textContent = correction.wrong;
                const right = document.createElement('strong'); right.style.color = '#86efac'; right.textContent = correction.correct;
                card.append(pair, instruction, wrong, document.createTextNode(' → '), right);
                const repairRow = document.createElement('div');
                repairRow.style.cssText = 'display:flex;align-items:center;gap:12px;margin-top:12px;flex-wrap:wrap';
                const repairButton = document.createElement('button');
                repairButton.type = 'button';
                repairButton.textContent = 'Repară';
                repairButton.style.cssText = 'padding:6px 16px;border:1px solid #86efac;border-radius:7px;background:#166534;color:#fff;font:600 14px system-ui;cursor:pointer';
                const repairStatus = document.createElement('span');
                repairStatus.style.cssText = 'font-size:13px;color:#cbd5e1';
                repairButton.onclick = () => repairCategoryPairFlag(correction, repairButton, repairStatus);
                repairRow.append(repairButton, repairStatus);
                card.appendChild(repairRow);
                dialog.appendChild(card);
            }
            for (const issue of issues) {
                // Hide redundant explanations already covered by an explicit replacement.
                const covered = displayed.some(c => issue.includes(c.path) && issue.includes(c.wrong));
                if (covered) continue;
                const p = document.createElement('p'); p.textContent = issue; p.style.color = '#fcd18b'; dialog.appendChild(p);
            }
            // × în colț (în locul butonului „Am înțeles”): închide fereastra și uită mesajele informative
            const close = document.createElement('button');
            close.type = 'button';
            close.title = 'Închide';
            close.setAttribute('aria-label', 'Închide');
            close.innerHTML = '<i class="fas fa-xmark"></i>';
            close.style.cssText = 'position:absolute;top:14px;right:14px;width:34px;height:34px;border:0;border-radius:50%;background:#2c3447;color:#cbd5e1;font-size:16px;cursor:pointer';
            close.onmouseenter = () => { close.style.background = '#ef4444'; close.style.color = '#fff'; };
            close.onmouseleave = () => { close.style.background = '#2c3447'; close.style.color = '#cbd5e1'; };
            close.onclick = () => { localStorage.removeItem('categoryPairPendingChanges'); dialog.close(); dialog.remove(); };
            dialog.appendChild(close);
            title.style.cssText = 'cursor:move;touch-action:none;user-select:none;margin-top:0;padding:8px 44px 8px 0';
            title.onpointerdown = event => {
                if (event.button !== 0) return;
                const rect = dialog.getBoundingClientRect(), x = event.clientX, y = event.clientY;
                dialog.style.margin = '0'; dialog.style.position = 'fixed'; dialog.style.left = rect.left + 'px'; dialog.style.top = rect.top + 'px';
                title.setPointerCapture(event.pointerId);
                title.onpointermove = e => { dialog.style.left = Math.max(0, Math.min(innerWidth - 80, rect.left + e.clientX - x)) + 'px'; dialog.style.top = Math.max(0, Math.min(innerHeight - 50, rect.top + e.clientY - y)) + 'px'; };
                title.onpointerup = title.onpointercancel = () => { title.onpointermove = null; };
            };
            document.body.appendChild(dialog); dialog.showModal();
        }
        let lastCategoryPairRun = 0;
        window.lastCategoryPairStamp = null;   // amprenta site-ului la ultima verificare RO–EN
        window.lastCategoryPairResult = null;  // ultimul raport (propunerile RO–EN au prioritate față de datele duplicate)
        async function getSiteStamp() {
            try {
                const r = await (await fetch('?action=siteStamp', { cache: 'no-store' })).json();
                return r && r.ok ? r.stamp : null;
            } catch (_) { return null; }
        }
        const categoryPairApplying = new Set(); // propunerile la care s-a apăsat OK și încă se aplică
        async function syncCategoryPairs(applyIds, force) {
            const applying = !!(applyIds && applyIds.length);
            if (categoryPairSyncPromise) {
                // O verificare simplă rulează deja: o verificare nouă nu mai e necesară, dar un OK
                // (aplicare) trebuie trimis după ea, altfel s-ar pierde.
                if (!applying) return categoryPairSyncPromise;
                try { await categoryPairSyncPromise; } catch (_) { }
                if (categoryPairSyncPromise) return syncCategoryPairs(applyIds, force);
            }
            window.categoryPairSyncRunning = true;
            let completed = false; // true doar dacă verificarea chiar a rulat (nu „ocupat”, nu eroare)
            categoryPairSyncPromise = (async () => {
                const stampAtStart = await getSiteStamp();
                const exclude = tabs.filter(t => t.isDirty || (t.id === activeTabId && editor && normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(t.originalContent))).map(t => t.filePath).filter(Boolean);
                let result, tries = 0;
                do {
                    // la aplicare, serverul așteaptă singur lacătul (până la 3 min); verificările simple renunță
                    const requestBody = new URLSearchParams({ exclude: JSON.stringify(exclude), apply: JSON.stringify(applyIds || []) });
                    let requestError = null;
                    for (let attempt = 0; attempt < 3; attempt++) {
                        try {
                            const response = await fetch('?action=categoryPairSync', { method: 'POST', body: requestBody });
                            if (!response.ok) throw new Error('Serverul a raspuns cu HTTP ' + response.status + '.');
                            result = await response.json();
                            requestError = null;
                            break;
                        } catch (e) {
                            requestError = e;
                            if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1200 * (attempt + 1)));
                        }
                    }
                    if (requestError) throw new Error('Nu am primit raspunsul verificarii RO-EN dupa 3 incercari. ' + requestError.message);
                    if (result.busy) {
                        if (!applying) return result; // altă verificare rulează deja; raportul ei e suficient
                        if (++tries >= 3) throw new Error('Serverul este ocupat cu altă verificare. Încearcă din nou peste un minut.');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                    }
                } while (result.busy);
                lastCategoryPairRun = Date.now();
                if (!result.ok) throw new Error(result.error || 'Verificarea RO–EN a eșuat');
                // după o aplicare, fișierele s-au schimbat chiar acum: iau amprenta de după
                window.lastCategoryPairStamp = applying ? await getSiteStamp() : stampAtStart;
                window.lastCategoryPairResult = result;
                completed = true;
                if (applying) {
                    // Ce am aplicat dispare din fereastră (cardul); nu-l mai arăt ca „Recuperat”.
                    const left = (result.proposals || []).map(p => p.id);
                    const done = applyIds.filter(id => !left.includes(id));
                    if (done.length) toast('Aplicat: ' + done.map(id => id.replace(/^(ro|en)\//, '$1/').replace(/->.*$/, '')).join(', '));
                    result = Object.assign({}, result, { changes: [] });
                }
                presentCategoryPairReport(result, force || applying);
                for (const change of result.changes || []) {
                    const tab = findTabByPath(change.file);
                    if (!tab || tab.isDirty) continue;
                    if (tab.id === activeTabId && editor && normalizeHtmlForSyncCompare(editor.getValue()) !== normalizeHtmlForSyncCompare(tab.originalContent)) continue;
                    const fresh = await (await fetch('?action=load&file=' + encodeURIComponent(change.file), { cache: 'no-store' })).json();
                    if (fresh.ok && !tab.isDirty) {
                        tab.editorContent = tab.originalContent = fresh.content;
                        tab.originalContentNorm = normalizeHtmlForCompare(fresh.content);
                        if (tab.id === activeTabId && editor) { isSyncFromDesign = true; try { editor.setValue(fresh.content); } finally { isSyncFromDesign = false; } updatePreview(); }
                    }
                }
                return result;
            })();
            try { return await categoryPairSyncPromise; }
            finally {
                categoryPairSyncPromise = null;
                window.categoryPairSyncRunning = false;
                // apoi verificarea datelor duplicate, fără articolele pe care RO–EN le repară deja
                if (completed && typeof runFullDateDuplicateCheck === 'function' && !tabs.some(t => t.filePath && t.type !== 'browser')) {
                    setTimeout(() => runFullDateDuplicateCheck(false).catch(console.error), 0);
                }
            }
        }
        window.addEventListener('load', () => {
            fetch('?action=categoryPairSync&report=1', { cache: 'no-store' }).then(r => r.json()).then(r => presentCategoryPairReport(r, true)).catch(console.error);
            syncCategoryPairs([], true).catch(e => showEmailConsole('Sincronizare RO–EN — eroare', e.message, '#f87171'));
        });
        async function checkIdleCategoryPairs() {
            if (tabs.some(t => t.type !== 'browser' && (t.filePath || t.fileName))) return;
            if (categoryPairSyncPromise || _translatePollTimer || rssGenerating || document.hidden) return;
            // cât timp fereastra cu propuneri e deschisă, nu o redesenez pe sub mâna utilizatorului
            if (document.getElementById('categoryPairReport')) return;
            // Verificarea completă durează ~25 s, deci nu o pornesc orbește: doar dacă s-a schimbat
            // vreun fișier din Principal/ro sau /en (amprenta) sau, oricum, o dată la 10 minute.
            const stamp = await getSiteStamp();
            if (stamp && stamp === window.lastCategoryPairStamp && Date.now() - lastCategoryPairRun < 600000) return;
            if (categoryPairSyncPromise) return;
            syncCategoryPairs().catch(console.error);
        }
        setInterval(checkIdleCategoryPairs, 10000);
        window.addEventListener('focus', checkIdleCategoryPairs);

        async function translateUntranslatedArticles() {
            const btn = document.getElementById('btnTranslateSite');
            if (_translatePollTimer) { showEmailConsole('Translate — rulează…', 'Se încarcă jurnalul...', '#facc15'); return; }
            if (btn && btn.disabled) return;
            if (btn) { btn.disabled = true; btn.style.opacity = '.6'; }
            const enable = function () { if (btn) { btn.disabled = false; btn.style.opacity = ''; } };
            showEmailConsole('Translate', 'Sincronizez categoriile RO–EN înainte de traducere…', '#facc15');
            try { await syncCategoryPairs(); } catch (e) { enable(); showEmailConsole('Translate — eroare de sincronizare', e.message, '#f87171'); return; }
            showEmailConsole('Translate', 'Caut articolele din ro/ care nu sunt traduse în en/...', '#facc15');
            const initialPanel = document.getElementById('emailConsoleDialog');
            if (initialPanel) {
                const loader = document.createElement('progress');
                loader.style.cssText = 'width:95%;height:16px;margin:12px 2.5%';
                initialPanel.appendChild(loader);
            }
            let info;
            try {
                let cursor = 0;
                const started = Date.now();
                do {
                    const response = await fetch('?action=translateSiteCheck&cursor=' + cursor, { cache: 'no-store' });
                    const body = await response.text();
                    try { info = JSON.parse(body); }
                    catch (_) { throw new Error('Serverul a trimis un răspuns invalid (HTTP ' + response.status + '). Verifică jurnalul PHP; scanarea poate fi reluată.'); }
                    if (!info.ok) break;
                    cursor = info.next;
                    const percent = info.total ? Math.round(cursor * 100 / info.total) : 100;
                    const remaining = cursor ? Math.ceil((Date.now() - started) / 1000 * (info.total - cursor) / cursor) : null;
                    showEmailConsole('Translate — verificare ' + percent + '%',
                        'Verificate: ' + cursor + ' / ' + info.total + '\nDeja traduse: ' + info.translated +
                        '\nTimp rămas estimat: ' + (remaining === null ? 'se calculează…' : remaining + ' secunde'), '#facc15');
                    const panel = document.getElementById('emailConsoleDialog');
                    if (panel) {
                        let bar = panel.querySelector('progress');
                        if (!bar) { bar = document.createElement('progress'); bar.style.cssText = 'width:95%;height:16px;margin:12px 2.5%'; panel.appendChild(bar); }
                        bar.max = info.total || 1; bar.value = cursor;
                    }
                } while (!info.done);
            }
            catch (e) { enable(); showEmailConsole('Translate — eroare', 'Nu pot contacta serverul: ' + e.message, '#f87171'); return; }
            if (!info.ok) { enable(); showEmailConsole('Translate — eroare', info.error || 'Eroare necunoscută.', '#f87171'); return; }
            if (info.running) { showEmailConsole('Translate — rulează…', 'Traducerea rulează deja.', '#facc15'); pollTranslateLog(); return; }
            if (!info.files || !info.files.length) {
                enable();
                showEmailConsole('Translate', 'Toate articolele din ro/ sunt deja traduse în en/.\nNu am nimic de făcut.', '#4ade80');
                return;
            }
            const dlg0 = document.getElementById('emailConsoleDialog');
            if (dlg0) dlg0.style.display = 'none';
            if (!info.resume && !await confirmTranslateDialog(info.files)) { enable(); return; }
            let r;
            try {
                r = await (await fetch('?action=translateSiteStart', { method: 'POST', body: new URLSearchParams({}) })).json();
            } catch (e) { enable(); showEmailConsole('Translate — eroare', 'Eroare: ' + e.message, '#f87171'); return; }
            if (!r.ok && !r.running) { enable(); showEmailConsole('Translate — eroare', r.error || 'Eroare necunoscută.', '#f87171'); return; }
            showEmailConsole('Translate — rulează…', 'Pornesc scriptul...\n(poți închide fereastra; traducerea merge mai departe)', '#facc15');
            pollTranslateLog();
        }

        // „Continua la editor” fara niciun fisier deschis: pregateste o pagina goala editabila
        // (altfel zona Design ramane un document alb in care nu se poate scrie/lipi).
        var BLANK_EDITOR_PAGE = '<!DOCTYPE html>\n<html lang="ro">\n<head>\n<meta charset="utf-8">\n<title></title>\n</head>\n<body>\n<p class="text_obisnuit"><br></p>\n</body>\n</html>\n';
        function continueToEditor() {
            hideOverlay();
            if (currentFile || tabs.some(function (t) { return t.type !== 'browser'; })) return;
            if (!editor) return;
            if (!editor.getValue().trim()) {
                isSyncFromDesign = true;
                editor.setValue(BLANK_EDITOR_PAGE);
                isSyncFromDesign = false;
                editor.getDoc().clearHistory();
                isDirty = false;
            }
            setViewMode('design');
            updatePreview();
        }

        function showOverlay() {
            const ov = document.getElementById('startOverlay');
            if (ov) {
                ov.style.display = 'flex';
                renderRecentFiles();
            }
            // Înapoi la meniu fără niciun fișier deschis → lista cu toate datele duplicate
            // (runFullDateDuplicateCheck nu arată nimic dacă e încă vreun HTML deschis)
            if (typeof runFullDateDuplicateCheck === 'function') {
                setTimeout(() => { runFullDateDuplicateCheck(false).catch(() => { }); }, 400);
            }
        }

        function getDesignSelection() {
            const iframe = document.getElementById('preview');
            const win = iframe.contentWindow;
            const doc = iframe.contentDocument;
            if (!win || !doc) return null;
            const sel = win.getSelection();
            if (!sel || sel.rangeCount === 0) return null;
            // Check if exactly one element node is selected (e.g. an <img> via selectNode)
            const range = sel.getRangeAt(0);
            if (range && range.startContainer === range.endContainer
                && range.startContainer.nodeType === 1
                && range.endOffset - range.startOffset === 1) {
                const child = range.startContainer.childNodes[range.startOffset];
                if (child && child.nodeType === 1 && child.tagName === 'IMG') return child;
            }
            let node = sel.anchorNode;
            if (!node) return null;
            if (node.nodeType === Node.TEXT_NODE) node = node.parentElement;
            if (!node || !node.closest) return node;
            return node.closest('img, p, span, div, td, th, li, h1, h2, h3, h4, h5, h6, a, strong, em');
        }

        function getDesignSelectionRange() {
            const iframe = document.getElementById('preview');
            const win = iframe.contentWindow;
            const doc = iframe.contentDocument;
            if (!win || !doc) return null;
            const sel = win.getSelection();
            if (!sel || sel.rangeCount === 0) {
                return restoreLastDesignSelectionRange(win, doc);
            }
            const range = sel.getRangeAt(0);
            if (range && !range.collapsed) {
                rememberDesignSelectionRange(win, doc);
                return { win, doc, sel, range };
            }
            const restored = restoreLastDesignSelectionRange(win, doc);
            if (restored) return restored;
            return { win, doc, sel, range };
        }

        function isUsableDesignRange(range, doc) {
            try {
                return !!(range && doc && doc.body && !range.collapsed &&
                    range.startContainer && range.endContainer &&
                    range.startContainer.isConnected && range.endContainer.isConnected &&
                    doc.body.contains(range.startContainer) && doc.body.contains(range.endContainer));
            } catch (e) {
                return false;
            }
        }

        function rememberDesignSelectionRange(win, doc) {
            try {
                const sel = win && win.getSelection ? win.getSelection() : null;
                if (!sel || sel.rangeCount === 0) return;
                const range = sel.getRangeAt(0);
                if (!range || range.collapsed) return;
                lastDesignSelectionRange = { doc: doc, range: range.cloneRange(), text: sel.toString() };
            } catch (e) {
                lastDesignSelectionRange = null;
            }
        }

        function restoreLastDesignSelectionRange(win, doc) {
            if (!lastDesignSelectionRange || lastDesignSelectionRange.doc !== doc) return null;
            const saved = lastDesignSelectionRange.range;
            if (!isUsableDesignRange(saved, doc)) {
                lastDesignSelectionRange = null;
                return null;
            }
            try {
                const sel = win.getSelection();
                const range = saved.cloneRange();
                sel.removeAllRanges();
                sel.addRange(range);
                return { win, doc, sel, range };
            } catch (e) {
                lastDesignSelectionRange = null;
                return null;
            }
        }

        function getDesignSelectionText() {
            const iframe = document.getElementById('preview');
            const win = iframe.contentWindow;
            const doc = iframe.contentDocument;
            if (!win || !doc) return '';
            const sel = win.getSelection();
            if (!sel || sel.rangeCount === 0) return '';
            let text = sel.toString().trim();
            if (text) return text;
            const node = sel.anchorNode && sel.anchorNode.nodeType === Node.TEXT_NODE ? sel.anchorNode : null;
            if (!node) return '';
            const value = node.nodeValue || '';
            const offset = sel.anchorOffset || 0;
            const left = value.slice(0, offset).split(/\s+/).pop() || '';
            const right = value.slice(offset).split(/\s+/)[0] || '';
            text = (left + right).trim();
            return text;
        }

        // Calculate the text-only offset of the selection's start within the body
        function getDesignSelectionTextOffset() {
            const iframe = document.getElementById('preview');
            const win = iframe.contentWindow;
            const doc = iframe.contentDocument;
            if (!win || !doc || !doc.body) return -1;
            const sel = win.getSelection();
            if (!sel || sel.rangeCount === 0) return -1;
            const range = sel.getRangeAt(0);
            // Create a range from body start to selection start
            const preRange = doc.createRange();
            preRange.setStart(doc.body, 0);
            preRange.setEnd(range.startContainer, range.startOffset);
            // Get the text content before the selection
            const textBefore = preRange.toString();
            return textBefore.length;
        }

        function syncSelectionToCodeFromDesign() {
            if (!editor) return;
            const text = getDesignSelectionText();
            if (!text) return;
            const src = editor.getValue();
            const bodyRe = /<body[^>]*>([\s\S]*)<\/body>/i;
            const bodyMatch = bodyRe.exec(src);
            let bodyHTML, bodyStartIdx;
            if (bodyMatch) {
                bodyHTML = bodyMatch[1];
                const openTagLen = bodyMatch[0].length - bodyMatch[1].length - 7; // 7 = '</body>'.length
                bodyStartIdx = bodyMatch.index + openTagLen;
            } else {
                bodyHTML = src;
                bodyStartIdx = 0;
            }
            const needle = text.toLowerCase();

            // ── Build a tag-stripped plain-text of bodyHTML with position map ──
            // posMap[i] = { start, end } — source indices of the i-th plain char.
            // This lets us search for the needle in pure text and then map back
            // to the source code, correctly handling selections that span across
            // HTML tags (e.g. <span class="A">word</span> other text).
            const posMap = [];
            let plainBuf = '';
            let _inTag = false;
            for (let i = 0; i < bodyHTML.length; i++) {
                if (bodyHTML[i] === '<') { _inTag = true; continue; }
                if (bodyHTML[i] === '>') { _inTag = false; continue; }
                if (!_inTag) {
                    let srcEnd = i;
                    if (bodyHTML[i] === '&') {
                        const entityEnd = bodyHTML.indexOf(';', i);
                        if (entityEnd !== -1 && entityEnd - i < 10) {
                            srcEnd = entityEnd;
                            const tmp = document.createElement('span');
                            tmp.innerHTML = bodyHTML.substring(i, entityEnd + 1);
                            plainBuf += (tmp.textContent || tmp.innerText || '?');
                            posMap.push({ start: i, end: entityEnd });
                            i = entityEnd;
                            continue;
                        }
                    }
                    plainBuf += bodyHTML[i];
                    posMap.push({ start: i, end: srcEnd });
                }
            }
            const plainLower = plainBuf.toLowerCase();

            // ── Find all occurrences of needle in the plain text ──
            const matches = [];
            let sFrom = 0;
            while (true) {
                const idx = plainLower.indexOf(needle, sFrom);
                if (idx === -1) break;
                matches.push(idx);
                sFrom = idx + 1;
            }
            if (matches.length === 0) return;

            // ── Pick the best match using designTextOffset for disambiguation ──
            const designTextOffset = getDesignSelectionTextOffset();
            let bestIdx = matches[0];
            if (matches.length > 1 && designTextOffset >= 0) {
                let bestDist = Math.abs(matches[0] - designTextOffset);
                for (let m = 1; m < matches.length; m++) {
                    const dist = Math.abs(matches[m] - designTextOffset);
                    if (dist < bestDist) { bestDist = dist; bestIdx = matches[m]; }
                }
            }

            // ── Map back to source positions and highlight ──
            if (bestIdx + needle.length - 1 < posMap.length) {
                const fStart = posMap[bestIdx].start;
                const fEnd = posMap[bestIdx + needle.length - 1].end;
                highlightSelectionInCode(bodyStartIdx + fStart, fEnd - fStart + 1);
            }
        }

        // Move the CodeMirror selection to [globalIdx, globalIdx+len] and apply
        // a yellow markText so the selected design text is clearly visible in the code.
        function highlightSelectionInCode(globalIdx, len) {
            const from = editor.posFromIndex(globalIdx);
            const to = editor.posFromIndex(globalIdx + len);
            // Clear any previous selection highlight mark
            if (syncSelectionMark) { syncSelectionMark.clear(); syncSelectionMark = null; }
            isSelectionFromDesign = true;
            editor.setSelection(from, to);
            editor.scrollIntoView({ from, to }, 100);
            isSelectionFromDesign = false;
            // Yellow markText — stays until the next selection or a click in the code editor
            syncSelectionMark = editor.markText(from, to, { className: 'cm-selection-highlight' });
        }

        // Scan forward from position j in html, skipping past the end of the current tag
        // (properly handling quoted attribute values that may contain '>').
        // Returns the index of '>' that closes the tag, or -1.
        function findTagClose(html, j) {
            while (j < html.length) {
                const ch = html[j];
                if (ch === '>') return j;
                if (ch === '"') { j++; while (j < html.length && html[j] !== '"') j++; }
                else if (ch === "'") { j++; while (j < html.length && html[j] !== "'") j++; }
                j++;
            }
            return -1;
        }

        // Walk source HTML to find the (childIdx)-th element child starting at offset.
        // Returns the position of the '<' that opens that element, or -1.
        function findChildOpenInSource(html, offset, childIdx) {
            const VOID = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
            let depth = 0;
            let elemCount = 0;
            let i = offset;
            while (i < html.length) {
                const lt = html.indexOf('<', i);
                if (lt === -1) break;
                i = lt;
                const c1 = html[i + 1];

                // HTML comment: <!-- ... --> — must end with -->, NOT just first >
                if (c1 === '!' && html[i + 2] === '-' && html[i + 3] === '-') {
                    const end = html.indexOf('-->', i + 4);
                    i = end === -1 ? html.length : end + 3;
                    continue;
                }
                // DOCTYPE, CDATA, processing instruction — skip to next >
                if (c1 === '!' || c1 === '?') {
                    const end = html.indexOf('>', i + 1);
                    i = end === -1 ? html.length : end + 1;
                    continue;
                }

                const isClose = c1 === '/';
                const nameStart = isClose ? i + 2 : i + 1;

                // Parse tag name using char codes — avoids slow slice().match()
                let nameEnd = nameStart;
                while (nameEnd < html.length) {
                    const cc = html.charCodeAt(nameEnd);
                    if (!((cc >= 65 && cc <= 90) || (cc >= 97 && cc <= 122) ||
                        (cc >= 48 && cc <= 57) || cc === 45)) break; // A-Z a-z 0-9 -
                    nameEnd++;
                }
                if (nameEnd === nameStart) { i++; continue; }
                const currTag = html.slice(nameStart, nameEnd).toLowerCase();

                // Find real end of tag, respecting quoted attribute values
                const gt = findTagClose(html, nameEnd);
                if (gt === -1) break;
                const isSelfClose = html[gt - 1] === '/';
                const isVoid = VOID.has(currTag);
                const tagEnd = gt + 1;

                if (!isClose) {
                    if (depth === 0) {
                        if (elemCount === childIdx) return i;
                        elemCount++;
                    }
                    if (!isVoid && !isSelfClose) depth++;
                } else {
                    if (depth > 0) depth--;
                }
                i = tagEnd;
            }
            return -1;
        }

        // Walk a path array through bodyHTML using findChildOpenInSource.
        // Returns the source offset of the final element, or -1.
        function walkPathInSource(bodyHTML, path) {
            let offset = 0;
            for (let step = 0; step < path.length; step++) {
                const pos = findChildOpenInSource(bodyHTML, offset, path[step]);
                if (pos === -1) return -1;
                if (step === path.length - 1) return pos;
                // Move past the opening tag into element content, respecting quoted attrs
                const gt = findTagClose(bodyHTML, pos + 1);
                if (gt === -1) return -1;
                offset = gt + 1;
            }
            return -1;
        }

        // Find the position of a clicked DOM element in the HTML source body.
        // Returns character offset within bodyHTML, or -1.
        function findElementPositionInSource(el, bodyHTML) {
            const iframe = document.getElementById('preview');
            const doc = iframe.contentDocument;
            if (!doc || !doc.body) return -1;
            // Elements browsers auto-insert inside <table> (not in original HTML)
            const AUTO_WRAP = new Set(['tbody', 'thead', 'tfoot']);
            // Build path from body to element: array of child-element-indices at each level
            const buildPath = (skipAutoWrap) => {
                const path = [];
                let node = el;
                while (node && node.parentElement && node !== doc.body) {
                    const parent = node.parentElement;
                    const pTag = (parent.tagName || '').toLowerCase();
                    if (skipAutoWrap && AUTO_WRAP.has(pTag) && parent.attributes.length === 0) {
                        // Auto-inserted wrapper: use node's index within wrapper, skip wrapper level
                        let ci = 0;
                        for (let k = 0; k < parent.children.length; k++) {
                            if (parent.children[k] === node) { ci = k; break; }
                        }
                        path.unshift(ci);
                        node = parent.parentElement || parent; // jump up past the auto-wrapper
                        continue;
                    }
                    let ci = 0;
                    for (let k = 0; k < parent.children.length; k++) {
                        if (parent.children[k] === node) { ci = k; break; }
                    }
                    path.unshift(ci);
                    node = parent;
                }
                return path;
            };
            // Try normal path first; if it fails, retry skipping auto-inserted wrappers
            const path = buildPath(false);
            if (!path.length) return -1;
            const result = walkPathInSource(bodyHTML, path);
            if (result !== -1) return result;
            const altPath = buildPath(true);
            if (altPath.length && altPath.join(',') !== path.join(',')) {
                return walkPathInSource(bodyHTML, altPath);
            }
            return -1;
        }

        // Sync the code editor cursor to the position of a DOM element clicked in design panel.
        function syncClickedElementToCode(el) {
            if (!editor || !el) return;
            const iframe = document.getElementById('preview');
            const doc = iframe.contentDocument;
            if (!doc || !doc.body || el === doc.body) return;
            const src = editor.getValue();
            const bodyRe = /<body[^>]*>([\s\S]*)<\/body>/i;
            const bodyMatch = bodyRe.exec(src);
            let bodyHTML, bodyStartIdx;
            if (bodyMatch) {
                bodyHTML = bodyMatch[1];
                // Robust: body content starts after opening <body...> tag
                const openTagLen = bodyMatch[0].length - bodyMatch[1].length - 7; // 7 = '</body>'.length
                bodyStartIdx = bodyMatch.index + openTagLen;
            } else {
                // No <body> tags — search entire source (bare HTML fragment)
                bodyHTML = src;
                bodyStartIdx = 0;
            }
            const tagName = (el.tagName || '').toLowerCase();
            let idx = -1;

            // Strategy 1: match image by src attribute
            if (tagName === 'img') {
                const srcAttr = el.getAttribute('src') || '';
                if (srcAttr) {
                    const esc = srcAttr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    const m = new RegExp('<img\\b[^>]*\\bsrc=["\']?' + esc, 'i').exec(bodyHTML);
                    if (m) idx = m.index;
                    if (idx === -1) {
                        const fname = srcAttr.split('/').pop();
                        if (fname) {
                            const esc2 = fname.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                            const m2 = new RegExp('<img\\b[^>]*' + esc2, 'i').exec(bodyHTML);
                            if (m2) idx = m2.index;
                        }
                    }
                }
            }

            // Strategy 2: match anchor by href attribute
            if (idx === -1 && tagName === 'a') {
                const hrefAttr = el.getAttribute('href') || '';
                if (hrefAttr) {
                    const esc = hrefAttr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    const m = new RegExp('<a\\b[^>]*\\bhref=["\']?' + esc, 'i').exec(bodyHTML);
                    if (m) idx = m.index;
                }
            }

            // Strategy 3: match by id attribute
            if (idx === -1) {
                const idAttr = el.getAttribute ? (el.getAttribute('id') || '') : '';
                if (idAttr) {
                    const esc = idAttr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                    const m = new RegExp('<' + tagName + '\\b[^>]*\\bid=["\']' + esc + '["\']', 'i').exec(bodyHTML);
                    if (m) idx = m.index;
                }
            }

            // Strategy 4: DOM-tree position
            if (idx === -1) {
                idx = findElementPositionInSource(el, bodyHTML);
            }

            // Strategy 5: nearest block-level ancestor (fallback for inline elements)
            if (idx === -1) {
                const BLOCK = new Set(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'td', 'th', 'tr', 'section', 'article', 'blockquote', 'pre', 'figure', 'header', 'footer', 'nav', 'main']);
                let ancestor = el.parentElement;
                while (ancestor && ancestor !== doc.body) {
                    const aTag = (ancestor.tagName || '').toLowerCase();
                    if (BLOCK.has(aTag)) {
                        idx = findElementPositionInSource(ancestor, bodyHTML);
                        if (idx !== -1) break;
                    }
                    ancestor = ancestor.parentElement;
                }
            }

            if (idx !== -1) {
                let highlightStartIdx = bodyStartIdx + idx;
                let highlightEndIdx = highlightStartIdx;
                const srcAfter = src.substring(highlightStartIdx);
                // Determine highlight range: just the specific tag, not the whole line.
                if (tagName === 'img') {
                    // Check if <img> is wrapped in <a> — highlight the <a>…</a> block
                    const parentA = el.parentElement;
                    if (parentA && parentA.tagName === 'A') {
                        const hrefAttr = parentA.getAttribute('href') || '';
                        if (hrefAttr) {
                            const esc = hrefAttr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                            const aMatch = new RegExp('<a\\b[^>]*\\bhref=["\']?' + esc + '[^>]*>[\\s\\S]*?</a>', 'i').exec(src.substring(bodyStartIdx));
                            if (aMatch) {
                                highlightStartIdx = bodyStartIdx + aMatch.index;
                                highlightEndIdx = highlightStartIdx + aMatch[0].length;
                            } else {
                                const imgClose = srcAfter.indexOf('>');
                                highlightEndIdx = highlightStartIdx + (imgClose !== -1 ? imgClose + 1 : 50);
                            }
                        } else {
                            const imgClose = srcAfter.indexOf('>');
                            highlightEndIdx = highlightStartIdx + (imgClose !== -1 ? imgClose + 1 : 50);
                        }
                    } else {
                        const imgClose = srcAfter.indexOf('>');
                        highlightEndIdx = highlightStartIdx + (imgClose !== -1 ? imgClose + 1 : 50);
                    }
                } else {
                    const closeTag = srcAfter.indexOf('>');
                    highlightEndIdx = highlightStartIdx + (closeTag !== -1 ? closeTag + 1 : 50);
                }
                const from = editor.posFromIndex(highlightStartIdx);
                const to = editor.posFromIndex(highlightEndIdx);
                // Clear any previous highlights before setting cursor
                if (syncSelectionMark) { syncSelectionMark.clear(); syncSelectionMark = null; }
                if (_imgClickMark) { _imgClickMark.clear(); _imgClickMark = null; }
                isSelectionFromDesign = true;
                editor.setCursor(from);
                editor.scrollIntoView(from, 100);
                isSelectionFromDesign = false;
                // Highlight the element — stays until user clicks in code or edits in design
                _imgClickMark = editor.markText(from, to, { className: 'cm-sync-highlight' });
            }
        }

        function syncSelectionToDesignFromCode() {
            const iframe = document.getElementById('preview');
            const win = iframe.contentWindow;
            const doc = iframe.contentDocument;
            if (!win || !doc || !doc.body || !editor) return;
            const selText = (editor.getSelection() || editor.getTokenAt(editor.getCursor()).string || '').trim();
            if (!selText) return;

            // Verificam daca pozitia din cod este in interiorul <body>...</body>
            const src = editor.getValue();
            const bodyRe = /<body[^>]*>([\s\S]*)<\/body>/i;
            const bodyMatch = bodyRe.exec(src);
            if (!bodyMatch) return;
            const bodyStart = bodyMatch.index;
            const bodyContentStart = bodyMatch.index + bodyMatch[0].indexOf(bodyMatch[1]);
            const bodyEnd = bodyMatch.index + bodyMatch[0].length;
            const curIndex = editor.indexFromPos(editor.getCursor());
            if (curIndex < bodyStart || curIndex >= bodyEnd) {
                return;
            }

            // Calculate text offset of cursor position within body HTML (skipping tags)
            const bodyHTML = bodyMatch[1];
            const cursorInBody = curIndex - bodyContentStart;
            let textOffset = 0;
            let inTag = false;
            for (let i = 0; i < bodyHTML.length && i < cursorInBody; i++) {
                if (bodyHTML[i] === '<') {
                    inTag = true;
                    continue;
                }
                if (bodyHTML[i] === '>') {
                    inTag = false;
                    continue;
                }
                if (!inTag) {
                    if (bodyHTML[i] === '&') {
                        const entityEnd = bodyHTML.indexOf(';', i);
                        if (entityEnd !== -1 && entityEnd - i < 10) {
                            textOffset++;
                            i = entityEnd;
                            continue;
                        }
                    }
                    textOffset++;
                }
            }

            // Find the text node at this offset in the design panel (case-sensitive match)
            const target = selText;
            const walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, null);
            let currentOffset = 0;
            let tNode;
            let bestNode = null, bestStart = 0;
            while ((tNode = walker.nextNode())) {
                const nodeLen = tNode.nodeValue.length;
                // Check if our target offset falls within or near this text node
                if (currentOffset + nodeLen > textOffset - selText.length || currentOffset >= textOffset - selText.length) {
                    // Search for the needle in this text node (case-sensitive)
                    let searchFrom = 0;
                    // If the target offset is within this node, start searching near that position
                    if (textOffset >= currentOffset && textOffset < currentOffset + nodeLen) {
                        searchFrom = Math.max(0, textOffset - currentOffset - selText.length);
                    }
                    const idx = tNode.nodeValue.indexOf(target, searchFrom);
                    if (idx !== -1) {
                        bestNode = tNode;
                        bestStart = idx;
                        break;
                    }
                }
                currentOffset += nodeLen;
            }

            if (!bestNode) {
                // Fallback: search all text nodes for first case-sensitive match
                const walker2 = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT, {
                    acceptNode(node) {
                        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                        return node.nodeValue.includes(target) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
                    }
                });
                bestNode = walker2.nextNode();
                if (!bestNode) return;
                bestStart = bestNode.nodeValue.indexOf(target);
                if (bestStart === -1) return;
            }

            const range = doc.createRange();
            range.setStart(bestNode, bestStart);
            range.setEnd(bestNode, bestStart + selText.length);
            const sel = win.getSelection();
            sel.removeAllRanges();
            sel.addRange(range);
            if (bestNode.parentElement && bestNode.parentElement.scrollIntoView) {
                bestNode.parentElement.scrollIntoView({ block: 'center' });
            }
        }

        // Starea bold/italic/underline a textului selectat (null dacă e doar cursor).
        function getSelectionTextFormatState() {
            const iframe = document.getElementById('preview');
            const win = iframe && iframe.contentWindow;
            const doc = iframe && iframe.contentDocument;
            const sel = win && win.getSelection();
            if (!sel || !sel.rangeCount) return null;
            const range = sel.getRangeAt(0);
            if (range.collapsed || !range.toString().trim()) return null;
            const nodes = [];
            const root = range.commonAncestorContainer;
            if (root.nodeType === 3) {
                nodes.push(root);
            } else {
                const walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
                let n;
                while ((n = walker.nextNode())) {
                    if (!n.nodeValue || !n.nodeValue.trim()) continue;
                    const tr = doc.createRange();
                    tr.selectNodeContents(n);
                    if (rangesOverlap(range, tr)) nodes.push(n);
                }
            }
            if (!nodes.length) return null;
            const state = { bold: true, italic: true, underline: true };
            nodes.forEach(function (n) {
                const el = n.parentElement;
                if (!el) return;
                const cs = win.getComputedStyle(el);
                if (!(cs.fontWeight === 'bold' || parseInt(cs.fontWeight, 10) >= 600)) state.bold = false;
                if (cs.fontStyle !== 'italic' && cs.fontStyle !== 'oblique') state.italic = false;
                // text-decoration nu se moștenește în computed style → căutăm <u> deasupra
                if (!closestInlineFormatElement(el, 'u') &&
                    (cs.textDecorationLine || '').indexOf('underline') === -1) state.underline = false;
            });
            return state;
        }

        function updatePropertiesPanelFromSelection() {
            const el = getDesignSelection();
            const fontSel = document.getElementById('propFont');
            const sizeSel = document.getElementById('propSize');
            const boldBtn = document.getElementById('propBold');
            const italicBtn = document.getElementById('propItalic');
            const underlineBtn = document.getElementById('propUnderline');
            const colorInp = document.getElementById('propColor');
            const bgInp = document.getElementById('propBg');
            const classSel = document.getElementById('propClass');
            if (!el) return;
            const st = el.style;
            const computed = el.ownerDocument.defaultView.getComputedStyle(el);
            const fontVal = (st.fontFamily || computed.fontFamily || '').split(',')[0].replace(/['"]/g, '').trim();
            const opt = [].find.call(fontSel.options, o => o.value === fontVal || (o.value && o.value.indexOf(fontVal) === 0));
            // Remove any previously-inserted dynamic font option
            var _dynFont = fontSel.querySelector('option[data-dynamic]');
            if (_dynFont) _dynFont.remove();
            if (opt) {
                fontSel.value = opt.value;
            } else if (fontVal) {
                // Computed font doesn't match any preset — add a temporary option
                var _df = document.createElement('option');
                _df.value = fontVal;
                _df.textContent = fontVal;
                _df.setAttribute('data-dynamic', '1');
                fontSel.insertBefore(_df, fontSel.firstChild.nextSibling);
                fontSel.value = fontVal;
            } else {
                fontSel.value = '';
            }
            const px = computed.fontSize ? parseFloat(computed.fontSize) : 0;
            const pxRound = px ? String(Math.round(px)) : '';
            // Remove any previously-inserted dynamic size option
            var _dynSize = sizeSel.querySelector('option[data-dynamic]');
            if (_dynSize) _dynSize.remove();
            if (pxRound && [].some.call(sizeSel.options, o => o.value === pxRound)) {
                sizeSel.value = pxRound;
            } else if (pxRound) {
                // Computed size doesn't match any preset — add a temporary option
                var _ds = document.createElement('option');
                _ds.value = pxRound;
                _ds.textContent = pxRound + 'px';
                _ds.setAttribute('data-dynamic', '1');
                // Insert in correct sorted position
                var _inserted = false;
                for (var _si = 1; _si < sizeSel.options.length; _si++) {
                    if (sizeSel.options[_si].value && parseInt(sizeSel.options[_si].value) > parseInt(pxRound)) {
                        sizeSel.insertBefore(_ds, sizeSel.options[_si]);
                        _inserted = true;
                        break;
                    }
                }
                if (!_inserted) sizeSel.appendChild(_ds);
                sizeSel.value = pxRound;
            } else {
                sizeSel.value = '';
            }
            let isBoldNow = (computed.fontWeight === '700' || computed.fontWeight === 'bold' || parseInt(computed.fontWeight, 10) >= 600);
            let isItalicNow = computed.fontStyle === 'italic';
            let isUnderNow = (computed.textDecorationLine || computed.textDecoration || '').indexOf('underline') !== -1;
            // Text selectat cu mouse-ul: începutul selecției e adesea în <p>, nu în <em>.
            // Butonul e aprins doar dacă TOT textul selectat are formatul.
            const selState = getSelectionTextFormatState();
            if (selState) {
                isBoldNow = selState.bold;
                isItalicNow = selState.italic;
                isUnderNow = selState.underline;
            }
            if (boldBtn) boldBtn.style.background = isBoldNow ? 'rgba(59,130,246,0.3)' : '';
            if (italicBtn) italicBtn.style.background = isItalicNow ? 'rgba(59,130,246,0.3)' : '';
            if (underlineBtn) underlineBtn.style.background = isUnderNow ? 'rgba(59,130,246,0.3)' : '';
            const quickItalicBtn = document.getElementById('btnQuickItalic');
            if (quickItalicBtn) quickItalicBtn.style.background = isItalicNow ? 'rgba(59,130,246,0.3)' : '';
            const quickUnderlineBtn = document.getElementById('btnQuickUnderline');
            if (quickUnderlineBtn) quickUnderlineBtn.style.background = isUnderNow ? 'rgba(59,130,246,0.3)' : '';
            colorInp.value = rgbToHex(computed.color) || '#000000';
            bgInp.value = rgbToHex(computed.backgroundColor) || '#ffffff';
            if (classSel) {
                var cls = '';
                var _ce = el;
                while (_ce && _ce.nodeType === 1 && _ce.tagName !== 'BODY') {
                    var _cn = (_ce.className || '').trim().split(/\s+/)[0] || '';
                    if (_cn && cssClasses.includes(_cn)) { cls = _cn; break; }
                    _ce = _ce.parentElement;
                }
                classSel.value = cls || '';
            }
            // Actualizează și butonul de clasă rapidă din topbar (B lângă Redo)
            const quickClassBtn = document.getElementById('btnClassObisnuit2');
            if (quickClassBtn) {
                quickClassBtn.dataset.className = 'text_obisnuit2';
                const hasClass = designSelectionHasCssClass(el, 'text_obisnuit2');
                quickClassBtn.classList.toggle('active', hasClass);
            }
            const normalClassBtn = document.getElementById('btnClassNormal');
            if (normalClassBtn) {
                const _np = el && el.closest ? el.closest('p') : null;
                normalClassBtn.classList.toggle('active', !!(_np && _np.classList.contains('text_obisnuit')));
            }
            // Link / Target
            var linkInp = document.getElementById('propLink');
            var linkTargetSel = document.getElementById('propLinkTarget');
            if (linkInp && linkTargetSel) {
                var anchorEl = null;
                var _ae = el;
                while (_ae && _ae.nodeType === 1 && _ae.tagName !== 'BODY') {
                    if (_ae.tagName === 'A') { anchorEl = _ae; break; }
                    _ae = _ae.parentElement;
                }
                if (anchorEl) {
                    linkInp.value = anchorEl.getAttribute('href') || '';
                    linkTargetSel.value = anchorEl.getAttribute('target') || '';
                } else {
                    linkInp.value = '';
                    linkTargetSel.value = '';
                }
            }
            if (!isSelectionFromCode) {
                syncSelectionToCodeFromDesign();
            }
        }

        function rgbToHex(rgb) {
            if (!rgb || rgb === 'rgba(0, 0, 0, 0)' || rgb === 'transparent') return '#ffffff';
            const m = rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
            if (!m) return null;
            return '#' + [1, 2, 3].map(i => ('0' + parseInt(m[i], 10).toString(16)).slice(-2)).join('');
        }

        function applyFontProperty(prop, value) {
            // Push the current body state BEFORE the change so undo can revert it.
            // Uses 500ms grouping so dragging the color picker only creates ONE undo entry.
            designPushCurrentState();
            const info = getDesignSelectionRange();
            if (info && !info.range.collapsed) {
                const { doc, sel, range } = info;
                const span = doc.createElement('span');
                const frag = range.extractContents();
                span.appendChild(frag);
                if (prop === 'fontFamily') span.style.fontFamily = value || null;
                else if (prop === 'fontSize') span.style.fontSize = value ? (value + 'px') : null;
                else if (prop === 'color') span.style.color = value || null;
                else if (prop === 'backgroundColor') span.style.backgroundColor = value || null;
                range.insertNode(span);
                sel.removeAllRanges();
                sel.selectAllChildren(span);
            } else {
                const el = getDesignSelection();
                if (!el) return;
                if (prop === 'fontFamily') el.style.fontFamily = value || null;
                else if (prop === 'fontSize') el.style.fontSize = value ? (value + 'px') : null;
                else if (prop === 'color') el.style.color = value || null;
                else if (prop === 'backgroundColor') el.style.backgroundColor = value || null;
            }
            syncFromDesign();
            // Record the post-change state so the next snapshot won't double-push
            lastDesignSnapshot = getDesignBodyHtml();
        }

        function applyLinkProperty() {
            designPushCurrentState();
            var linkVal = document.getElementById('propLink').value.trim();
            var targetVal = document.getElementById('propLinkTarget').value;
            var el = getDesignSelection();
            if (!el) return;
            var iframe = document.getElementById('preview');
            var iDoc = iframe.contentDocument;
            var iWin = iframe.contentWindow;
            // Find existing <a> ancestor
            var anchorEl = null;
            var _ae = el;
            while (_ae && _ae.nodeType === 1 && _ae.tagName !== 'BODY') {
                if (_ae.tagName === 'A') { anchorEl = _ae; break; }
                _ae = _ae.parentElement;
            }
            // Capture ALL computed font styles BEFORE any DOM change
            var _origStyles = {};
            try {
                var _cs = iWin.getComputedStyle(el);
                _origStyles.fontSize   = _cs.fontSize;
                _origStyles.fontStyle  = _cs.fontStyle;
                _origStyles.fontWeight = _cs.fontWeight;
                _origStyles.fontFamily = _cs.fontFamily;
            } catch(e) {}
            if (linkVal) {
                if (anchorEl) {
                    // Update existing anchor
                    anchorEl.setAttribute('href', linkVal);
                    if (targetVal) anchorEl.setAttribute('target', targetVal);
                    else anchorEl.removeAttribute('target');
                } else {
                    var sel = iWin.getSelection();
                    if (sel && sel.rangeCount > 0 && !sel.getRangeAt(0).collapsed) {
                        // Use execCommand('createLink') — browser creates <a> inside
                        // existing DOM structure without breaking parent elements
                        iDoc.execCommand('createLink', false, linkVal);
                        // Find the newly created <a> and apply preserved styles + target
                        var newSel = iWin.getSelection();
                        if (newSel && newSel.rangeCount > 0) {
                            var node = newSel.anchorNode;
                            if (node && node.nodeType === 3) node = node.parentElement;
                            var newAnchor = node && node.closest ? node.closest('a') : null;
                            if (newAnchor) {
                                if (targetVal) newAnchor.setAttribute('target', targetVal);
                                // Force-preserve original font styles on <a> so page
                                // CSS cannot override italic, bold, size, etc.
                                if (_origStyles.fontSize)   newAnchor.style.fontSize   = _origStyles.fontSize;
                                if (_origStyles.fontStyle)  newAnchor.style.fontStyle  = _origStyles.fontStyle;
                                if (_origStyles.fontWeight) newAnchor.style.fontWeight = _origStyles.fontWeight;
                                if (_origStyles.fontFamily) newAnchor.style.fontFamily = _origStyles.fontFamily;
                            }
                        }
                    } else if (el.tagName !== 'BODY') {
                        // No text selected — wrap whole element content
                        var doc = el.ownerDocument;
                        var a = doc.createElement('a');
                        a.setAttribute('href', linkVal);
                        if (targetVal) a.setAttribute('target', targetVal);
                        if (_origStyles.fontSize)   a.style.fontSize   = _origStyles.fontSize;
                        if (_origStyles.fontStyle)  a.style.fontStyle  = _origStyles.fontStyle;
                        if (_origStyles.fontWeight) a.style.fontWeight = _origStyles.fontWeight;
                        if (_origStyles.fontFamily) a.style.fontFamily = _origStyles.fontFamily;
                        while (el.firstChild) a.appendChild(el.firstChild);
                        el.appendChild(a);
                    }
                }
            } else {
                // Link cleared — remove <a> wrapper, keep children
                if (anchorEl) {
                    iDoc.execCommand('unlink', false, null);
                }
            }
            syncFromDesign();
            lastDesignSnapshot = getDesignBodyHtml();
        }

        function getSelectedTextBlocks(doc, range) {
            if (!doc || !doc.body || !range) return [];
            var selector = 'p, div, h1, h2, h3, h4, h5, h6, li, td, th, blockquote';
            var blocks = Array.from(doc.body.querySelectorAll(selector)).filter(function (block) {
                if (!range.intersectsNode(block)) return false;
                return rangeIntersectsNonEmptyText(doc, range, block);
            });
            return blocks.filter(function (block) {
                return !blocks.some(function (other) {
                    return other !== block && block.contains(other);
                });
            });
        }

        // a.compareBoundaryPoints(START_TO_END, b) compară sfârșitul lui a cu începutul lui b;
        // END_TO_START compară începutul lui a cu sfârșitul lui b.
        function rangesOverlap(a, b) {
            return a.compareBoundaryPoints(Range.START_TO_END, b) > 0 &&
                a.compareBoundaryPoints(Range.END_TO_START, b) < 0;
        }

        // Scoate formatul (em/strong/u) DOAR de pe textul din range: tagurile care
        // cuprind și text din afara selecției sunt tăiate în două, nu desfăcute de tot.
        function removeInlineFormatFromRange(doc, sel, range, block, tagName) {
            const selector = inlineFormatSelector(tagName);
            const elOf = n => (n && n.nodeType === 3 ? n.parentElement : n);
            const unwrap = el => {
                const par = el.parentNode;
                if (!par) return;
                while (el.firstChild) par.insertBefore(el.firstChild, el);
                par.removeChild(el);
            };
            const frag = range.extractContents();
            Array.prototype.slice.call(frag.querySelectorAll(selector)).reverse().forEach(unwrap);
            let f = elOf(range.startContainer);
            f = f && f !== block && f.closest ? f.closest(selector) : null;
            while (f && f !== block && block.contains(f)) {
                const after = doc.createRange();
                after.setStart(range.startContainer, range.startOffset);
                after.setEnd(f, f.childNodes.length);
                const afterFrag = after.extractContents();
                const clone = f.cloneNode(false);
                clone.appendChild(afterFrag);
                f.parentNode.insertBefore(clone, f.nextSibling);
                range.setStartAfter(f);
                range.collapse(true);
                const par = f.parentNode;
                if (!f.textContent) f.parentNode.removeChild(f);
                if (!clone.textContent) clone.parentNode.removeChild(clone);
                f = par && par !== block && par.closest ? par.closest(selector) : null;
            }
            const first = frag.firstChild, last = frag.lastChild;
            range.insertNode(frag);
            Array.prototype.slice.call(block.querySelectorAll(selector)).forEach(el => {
                if (!el.textContent) el.parentNode.removeChild(el);
            });
            if (sel && first && last && first.parentNode && last.parentNode) {
                const r = doc.createRange();
                r.setStartBefore(first);
                r.setEndAfter(last);
                sel.removeAllRanges();
                sel.addRange(r);
            }
        }

        // Pune formatul pe range fără să lase taguri dublate (<em><em>…</em></em>).
        function wrapRangeWithFormatClean(doc, range, block, tagName) {
            const selector = inlineFormatSelector(tagName);
            const frag = range.extractContents();
            Array.prototype.slice.call(frag.querySelectorAll(selector)).reverse().forEach(el => {
                const par = el.parentNode;
                while (el.firstChild) par.insertBefore(el.firstChild, el);
                par.removeChild(el);
            });
            const wrapper = doc.createElement(tagName);
            wrapper.appendChild(frag);
            range.insertNode(wrapper);
            Array.prototype.slice.call(block.querySelectorAll(selector)).forEach(el => {
                if (!el.textContent) el.parentNode.removeChild(el);
            });
            return wrapper;
        }

        function rangeIntersectsNonEmptyText(doc, range, root) {
            var walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
            var node;
            while ((node = walker.nextNode())) {
                if (!node.nodeValue || !node.nodeValue.trim()) continue;
                var textRange = doc.createRange();
                textRange.selectNodeContents(node);
                if (rangesOverlap(range, textRange)) return true;
            }
            return false;
        }

        function makeRangeInsideBlock(doc, sourceRange, block) {
            var r = doc.createRange();
            r.selectNodeContents(block);
            if (block === sourceRange.startContainer || block.contains(sourceRange.startContainer)) {
                r.setStart(sourceRange.startContainer, sourceRange.startOffset);
            }
            if (block === sourceRange.endContainer || block.contains(sourceRange.endContainer)) {
                r.setEnd(sourceRange.endContainer, sourceRange.endOffset);
            }
            return r;
        }

        function rangeHasText(range) {
            return !!(range && range.toString && range.toString().trim());
        }

        function normalizeInlineSelectionText(value) {
            return String(value || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
        }

        function selectionCoversWholeBlockText(range, block) {
            if (!range || !block) return false;
            var selectedText = normalizeInlineSelectionText(range.toString());
            var blockText = normalizeInlineSelectionText(block.textContent || '');
            return !!blockText && selectedText === blockText;
        }

        function closestInlineFormattingBlock(node) {
            var selector = 'p,div,h1,h2,h3,h4,h5,h6,li,td,th,blockquote';
            var el = node && node.nodeType === Node.ELEMENT_NODE ? node : (node ? node.parentElement : null);
            return el && el.closest ? el.closest(selector) : null;
        }

        function getCommonInlineFormattingBlock(range) {
            if (!range) return null;
            var startBlock = closestInlineFormattingBlock(range.startContainer);
            var endBlock = closestInlineFormattingBlock(range.endContainer);
            return startBlock && startBlock === endBlock ? startBlock : null;
        }

        function getWholeSelectionInlineFormattingBlock(doc, range) {
            var commonBlock = getCommonInlineFormattingBlock(range);
            if (commonBlock && selectionCoversWholeBlockText(range, commonBlock)) return commonBlock;

            var selectedText = normalizeInlineSelectionText(range && range.toString ? range.toString() : '');
            if (!selectedText || !doc || !doc.body) return null;
            var selector = 'p,div,h1,h2,h3,h4,h5,h6,li,td,th,blockquote';
            var matches = Array.from(doc.body.querySelectorAll(selector)).filter(function (block) {
                return normalizeInlineSelectionText(block.textContent || '') === selectedText;
            });
            matches = matches.filter(function (block) {
                return !matches.some(function (other) {
                    return other !== block && block.contains(other);
                });
            });
            return matches.length === 1 ? matches[0] : null;
        }

        function isEmptyTextParagraph(node) {
            if (!node || node.nodeType !== 1 || node.tagName !== 'P') return false;
            if (!node.classList ||
                (!node.classList.contains('text_obisnuit') && !node.classList.contains('text_obisnuit2'))) {
                return false;
            }
            var clone = node.cloneNode(true);
            clone.querySelectorAll('br').forEach(function (br) { br.remove(); });
            return !normalizeInlineSelectionText(clone.textContent || '');
        }

        function adjacentElementAcrossWhitespace(node, direction) {
            var sibling = node ? node[direction] : null;
            while (sibling && sibling.nodeType === Node.TEXT_NODE &&
                !normalizeInlineSelectionText(sibling.nodeValue || '')) {
                sibling = sibling[direction];
            }
            return sibling && sibling.nodeType === Node.ELEMENT_NODE ? sibling : null;
        }

        function removeAdjacentEmptyTextParagraphs(block) {
            if (!block || !block.parentNode) return;
            var sibling = adjacentElementAcrossWhitespace(block, 'previousSibling');
            while (isEmptyTextParagraph(sibling)) {
                var previous = adjacentElementAcrossWhitespace(sibling, 'previousSibling');
                sibling.remove();
                sibling = previous;
            }
            sibling = adjacentElementAcrossWhitespace(block, 'nextSibling');
            while (isEmptyTextParagraph(sibling)) {
                var next = adjacentElementAcrossWhitespace(sibling, 'nextSibling');
                sibling.remove();
                sibling = next;
            }
        }

        function selectedBlockTextNodesHaveFormat(doc, range, tagName) {
            if (range && range.commonAncestorContainer &&
                range.commonAncestorContainer.nodeType === Node.TEXT_NODE) {
                var rootText = range.commonAncestorContainer.nodeValue || '';
                if (!rootText.trim()) return false;
                return !!closestInlineFormatElement(range.commonAncestorContainer.parentElement, tagName);
            }
            var walker = doc.createTreeWalker(range.commonAncestorContainer, NodeFilter.SHOW_TEXT, {
                acceptNode: function (node) {
                    if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
                    var textRange = doc.createRange();
                    textRange.selectNodeContents(node);
                    return rangesOverlap(range, textRange) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                }
            });
            var found = false;
            var node;
            while ((node = walker.nextNode())) {
                found = true;
                var parent = node.parentElement;
                if (!closestInlineFormatElement(parent, tagName)) return false;
            }
            return found;
        }

        function getInlineFormatTagName(kind) {
            if (kind === 'bold') return 'strong';
            if (kind === 'underline') return 'u';
            return 'em';
        }

        function inlineFormatSelector(tagName) {
            return tagName === 'em' ? 'em,i:not([class])' : tagName;
        }

        function closestInlineFormatElement(node, tagName) {
            var selector = inlineFormatSelector(tagName);
            var el = node && node.nodeType === 1 ? node : (node ? node.parentElement : null);
            while (el && el.nodeType === 1 && el.tagName !== 'BODY') {
                if (el.matches && el.matches(selector)) return el;
                el = el.parentElement;
            }
            return null;
        }

        function queryInlineFormatElements(root, tagName) {
            if (!root || !root.querySelectorAll) return [];
            return Array.from(root.querySelectorAll(inlineFormatSelector(tagName)));
        }

        function unwrapFormatInBlock(block, tagName) {
            queryInlineFormatElements(block, tagName).forEach(function (fmt) {
                var parent = fmt.parentNode;
                while (fmt.firstChild) parent.insertBefore(fmt.firstChild, fmt);
                parent.removeChild(fmt);
            });
            block.normalize();
        }

        function allBlockTextNodesHaveFormat(doc, block, tagName) {
            var walker = doc.createTreeWalker(block, NodeFilter.SHOW_TEXT, null);
            var found = false;
            var node;
            while ((node = walker.nextNode())) {
                if (!normalizeInlineSelectionText(node.nodeValue || '')) continue;
                found = true;
                var format = closestInlineFormatElement(node.parentElement, tagName);
                if (!format || !block.contains(format)) return false;
            }
            return found;
        }

        function toggleWholeBlockInlineFormat(doc, sel, block, tagName) {
            var removeFormat = allBlockTextNodesHaveFormat(doc, block, tagName);

            // A full-paragraph command always starts from one clean representation.
            // Thus a partial inner <u>/<em> cannot survive inside the new outer tag.
            unwrapFormatInBlock(block, tagName);
            if (!removeFormat) {
                var wrapper = doc.createElement(tagName);
                while (block.firstChild) wrapper.appendChild(block.firstChild);
                block.appendChild(wrapper);
            }

            removeAdjacentEmptyTextParagraphs(block);
            sel.removeAllRanges();
            var newRange = doc.createRange();
            newRange.selectNodeContents(block);
            sel.addRange(newRange);
            rememberDesignSelectionRange(doc.defaultView, doc);
        }

        function wrapRangeContentsWithTag(doc, range, tagName) {
            var wrapper = doc.createElement(tagName);
            try {
                range.surroundContents(wrapper);
            } catch (e) {
                var frag = range.extractContents();
                wrapper.appendChild(frag);
                range.insertNode(wrapper);
            }
            return wrapper;
        }

        function toggleInlineFormatAcrossBlocks(doc, sel, range, tagName) {
            var blocks = getSelectedTextBlocks(doc, range);
            if (blocks.length < 2) return false;

            var ranges = [];
            for (var i = 0; i < blocks.length; i++) {
                var blockRange = makeRangeInsideBlock(doc, range, blocks[i]);
                if (rangeHasText(blockRange)) {
                    ranges.push({ block: blocks[i], range: blockRange });
                }
            }
            if (ranges.length < 2) return false;

            var shouldUnwrap = ranges.every(function (item) {
                return selectedBlockTextNodesHaveFormat(doc, item.range, tagName);
            });

            var firstSelected = null;
            var lastSelected = null;
            ranges.forEach(function (item) {
                if (shouldUnwrap) {
                    removeInlineFormatFromRange(doc, null, item.range, item.block, tagName);
                    if (!firstSelected) firstSelected = item.block;
                    lastSelected = item.block;
                    return;
                }
                var wrapper = wrapRangeWithFormatClean(doc, item.range, item.block, tagName);
                if (!firstSelected) firstSelected = wrapper;
                lastSelected = wrapper;
            });

            sel.removeAllRanges();
            if (firstSelected && lastSelected) {
                var newRange = doc.createRange();
                newRange.setStartBefore(firstSelected);
                newRange.setEndAfter(lastSelected);
                sel.addRange(newRange);
            }
            return true;
        }

        function toggleInlineFormat(kind) {
            // Push the current body state BEFORE the change so undo can revert it
            designPushCurrentState();
            const tagName = getInlineFormatTagName(kind);
            const info = getDesignSelectionRange();
            if (info && !info.range.collapsed) {
                const { doc, sel, range } = info;
                if (toggleInlineFormatAcrossBlocks(doc, sel, range, tagName)) {
                    syncFromDesign();
                    lastDesignSnapshot = getDesignBodyHtml();
                    return;
                }
                const wholeSelectionBlock = getWholeSelectionInlineFormattingBlock(doc, range);
                if (wholeSelectionBlock) {
                    toggleWholeBlockInlineFormat(doc, sel, wholeSelectionBlock, tagName);
                    syncFromDesign();
                    lastDesignSnapshot = getDesignBodyHtml();
                    return;
                }
                const selectedBlocks = getSelectedTextBlocks(doc, range);
                if (selectedBlocks.length === 1) {
                    const block = selectedBlocks[0];
                    const blockRange = makeRangeInsideBlock(doc, range, block);
                    if (rangeHasText(blockRange)) {
                        if (selectionCoversWholeBlockText(blockRange, block)) {
                            toggleWholeBlockInlineFormat(doc, sel, block, tagName);
                            syncFromDesign();
                            lastDesignSnapshot = getDesignBodyHtml();
                            return;
                        }
                        if (selectedBlockTextNodesHaveFormat(doc, blockRange, tagName)) {
                            // Selecția e deja italic/bold/underline → scoate formatul doar de pe ea
                            removeInlineFormatFromRange(doc, sel, blockRange, block, tagName);
                        } else {
                            const wrapper = wrapRangeWithFormatClean(doc, blockRange, block, tagName);
                            sel.removeAllRanges();
                            const newRange = doc.createRange();
                            newRange.selectNodeContents(wrapper);
                            sel.addRange(newRange);
                        }
                        syncFromDesign();
                        lastDesignSnapshot = getDesignBodyHtml();
                        return;
                    }
                }
                // Save selected text for re-selection
                const selectedText = range.toString();
                let node = range.commonAncestorContainer;
                if (node.nodeType === 3) node = node.parentElement;
                let fmt = closestInlineFormatElement(node, tagName);
                if (fmt) {
                    // Remove formatting: unwrap the tag but keep selection on original text
                    const parent = fmt.parentNode;
                    // Collect child nodes before unwrapping
                    const childNodes = Array.from(fmt.childNodes);
                    // Get the text content that was selected inside fmt
                    const firstChild = fmt.firstChild;
                    const lastChild = fmt.lastChild;
                    while (fmt.firstChild) parent.insertBefore(fmt.firstChild, fmt);
                    parent.removeChild(fmt);
                    parent.normalize();
                    // Re-select the same text in the parent
                    sel.removeAllRanges();
                    if (selectedText) {
                        const newRange = findTextRangeInNode(doc, parent, selectedText);
                        if (newRange) {
                            sel.addRange(newRange);
                        }
                    }
                } else {
                    const wrapper = doc.createElement(tagName);
                    try {
                        range.surroundContents(wrapper);
                    } catch (e) {
                        const frag = range.extractContents();
                        wrapper.appendChild(frag);
                        range.insertNode(wrapper);
                    }
                    sel.removeAllRanges();
                    const newRange = doc.createRange();
                    newRange.selectNodeContents(wrapper);
                    sel.addRange(newRange);
                }
            } else {
                const el = getDesignSelection();
                if (!el) return;
                const doc = el.ownerDocument;
                const existing = queryInlineFormatElements(el, tagName)[0];
                if (existing) {
                    const parent = existing.parentNode;
                    while (existing.firstChild) parent.insertBefore(existing.firstChild, existing);
                    parent.removeChild(existing);
                } else {
                    const wrapper = doc.createElement(tagName);
                    while (el.firstChild) wrapper.appendChild(el.firstChild);
                    el.appendChild(wrapper);
                }
            }
            syncFromDesign();
            // Record the post-change state so the next snapshot won't double-push
            lastDesignSnapshot = getDesignBodyHtml();
        }

        // Helper: find a text range inside a node that matches the given text
        function findTextRangeInNode(doc, container, searchText) {
            if (!searchText || !container) return null;
            const walker = doc.createTreeWalker(container, NodeFilter.SHOW_TEXT, null);
            let accumulated = '';
            const textNodes = [];
            let tNode;
            while ((tNode = walker.nextNode())) {
                textNodes.push({ node: tNode, start: accumulated.length });
                accumulated += tNode.nodeValue;
            }
            const idx = accumulated.indexOf(searchText);
            if (idx === -1) return null;
            const endIdx = idx + searchText.length;
            let startNode = null, startOffset = 0, endNode = null, endOffset = 0;
            for (let i = 0; i < textNodes.length; i++) {
                const tn = textNodes[i];
                const tnEnd = tn.start + tn.node.nodeValue.length;
                if (!startNode && idx >= tn.start && idx < tnEnd) {
                    startNode = tn.node;
                    startOffset = idx - tn.start;
                }
                if (endIdx > tn.start && endIdx <= tnEnd) {
                    endNode = tn.node;
                    endOffset = endIdx - tn.start;
                    break;
                }
            }
            if (!startNode || !endNode) return null;
            const range = doc.createRange();
            range.setStart(startNode, startOffset);
            range.setEnd(endNode, endOffset);
            return range;
        }

        // Span „de formatare”: are doar class / style (nu e un span cu id, data-* etc.)
        function isFormattingSpan(el) {
            if (!el || el.nodeName !== 'SPAN') return false;
            return Array.prototype.every.call(el.attributes, function (a) {
                return /^(?:class|style|data-orig-class)$/i.test(a.name);
            });
        }

        function unwrapFormattingSpans(root) {
            if (!root || !root.querySelectorAll) return;
            Array.prototype.slice.call(root.querySelectorAll('span')).reverse().forEach(function (s) {
                if (!isFormattingSpan(s)) return;
                const par = s.parentNode;
                if (!par) return;
                while (s.firstChild) par.insertBefore(s.firstChild, s);
                par.removeChild(s);
            });
            if (root.normalize) root.normalize();
        }

        function removeEmptyFormattingSpans(root) {
            Array.prototype.slice.call(root.querySelectorAll('span')).forEach(function (s) {
                if (isFormattingSpan(s) && !s.textContent && !s.querySelector('img, br')) s.parentNode.removeChild(s);
            });
        }

        // Clasa aleasă din listă pe o bucată de text dintr-un paragraf: cuvintele selectate
        // primesc DOAR clasa nouă, indiferent ce span-uri/clase aveau înainte. Span-ul în
        // care se află selecția e tăiat în două (înainte / după), ca să nu rămână imbricat.
        function applyClassToPartialSelection(doc, sel, range, value) {
            const BLOCK_SEL = 'p,div,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,pre';
            const elOf = n => (n && n.nodeType === 3 ? n.parentElement : n);
            const startEl = elOf(range.startContainer);
            const block = startEl && startEl.closest ? startEl.closest(BLOCK_SEL) : null;
            if (!block || !block.contains(range.endContainer)) return false;

            const frag = range.extractContents();
            unwrapFormattingSpans(frag);

            // Taie span-urile de formatare care încă înconjoară punctul de inserare
            let s = elOf(range.startContainer);
            s = s && s !== block ? s.closest('span') : null;
            while (s && s !== block && block.contains(s) && isFormattingSpan(s)) {
                const after = doc.createRange();
                after.setStart(range.startContainer, range.startOffset);
                after.setEnd(s, s.childNodes.length);
                const afterFrag = after.extractContents();
                const clone = s.cloneNode(false);
                clone.appendChild(afterFrag);
                s.parentNode.insertBefore(clone, s.nextSibling);
                range.setStartAfter(s);
                range.collapse(true);
                const next = s.parentNode && s.parentNode !== block && s.parentNode.closest
                    ? s.parentNode.closest('span') : null;
                if (!clone.textContent) clone.parentNode.removeChild(clone);
                s = next;
            }

            // Dacă clasa aleasă e chiar clasa paragrafului, textul rămâne simplu (o moștenește)
            const blockClass = (block.className || '').trim().split(/\s+/)[0];
            let inserted;
            if (value && value !== blockClass) {
                inserted = doc.createElement('span');
                inserted.className = value;
                inserted.appendChild(frag);
                range.insertNode(inserted);
            } else {
                inserted = doc.createElement('span'); // marcaj temporar pentru selecție
                inserted.appendChild(frag);
                range.insertNode(inserted);
            }
            removeEmptyFormattingSpans(block);
            const r = doc.createRange();
            if (inserted.className) {
                r.selectNodeContents(inserted);
            } else {
                const first = inserted.firstChild, last = inserted.lastChild;
                const par = inserted.parentNode;
                while (inserted.firstChild) par.insertBefore(inserted.firstChild, inserted);
                par.removeChild(inserted);
                if (first && last) { r.setStartBefore(first); r.setEndAfter(last); }
            }
            sel.removeAllRanges();
            sel.addRange(r);
            return true;
        }

        // opts.fromDropdown: alegere din lista de clase CSS → aplică (nu comută) și
        // scoate toate span-urile de formatare din bucata selectată.
        // Titlurile H1–H6 devin <p> când primesc clasele de paragraf
        // (<h2>…</h2> + clasa text_obisnuit2 → <p class="text_obisnuit2">…</p>).
        function demoteHeadingForTextClass(block, value) {
            if (!block || !/^H[1-6]$/.test(block.tagName || '')) return block;
            if (value !== 'text_obisnuit' && value !== 'text_obisnuit2') return block;
            const p = block.ownerDocument.createElement('p');
            while (block.firstChild) p.appendChild(block.firstChild);
            block.replaceWith(p);
            return p;
        }

        function applyClassProperty(value, opts) {
            const fromDropdown = !!(opts && opts.fromDropdown);
            // Push the current body state BEFORE the change so undo can revert it
            designPushCurrentState();
            const info = getDesignSelectionRange();
            if (info && !info.range.collapsed) {
                const { doc, sel, range } = info;
                const selectedText = range.toString();
                const normSel = s => String(s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
                let ancestor = range.commonAncestorContainer;
                if (ancestor.nodeType === 3) ancestor = ancestor.parentElement;

                // Case 1: selection covers the entire content of a block element
                // → change the block's class directly instead of wrapping in a span
                const BLOCK_TAGS = new Set(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'td', 'th', 'blockquote', 'pre', 'article', 'section', 'figure', 'header', 'footer', 'main', 'nav']);
                const BLOCK_SEL = 'p,div,h1,h2,h3,h4,h5,h6,li,td,th,blockquote,pre,article,section,figure,header,footer,main,nav';

                // Determine the block element whose full content is selected.
                // Two situations produce a "whole line" selection:
                //   (a) commonAncestorContainer IS the block (selection stays inside it)
                //   (b) the range spans the entire block from its parent level — e.g. a
                //       double/triple-click on a paragraph, where commonAncestorContainer
                //       becomes the parent (body). Without handling (b), the block would be
                //       wrapped in a <span>, producing invalid <span><p>…</p></span>.
                let targetBlock = null;
                if (BLOCK_TAGS.has((ancestor.tagName || '').toLowerCase()) &&
                    normSel(selectedText) === normSel(ancestor.textContent)) {
                    targetBlock = ancestor;
                } else {
                    // Resolve the block sitting at the start of the selection.
                    let startNode = range.startContainer;
                    if (startNode.nodeType === 1 && startNode.childNodes[range.startOffset]) {
                        startNode = startNode.childNodes[range.startOffset];
                    }
                    if (startNode && startNode.nodeType === 3) startNode = startNode.parentElement;
                    let candidate = null;
                    if (startNode && startNode.nodeType === 1) {
                        candidate = (startNode.matches && startNode.matches(BLOCK_SEL))
                            ? startNode
                            : (startNode.closest ? startNode.closest(BLOCK_SEL) : null);
                    }
                    if (candidate && normSel(selectedText) === normSel(candidate.textContent)) {
                        targetBlock = candidate;
                    }
                }

                if (targetBlock && fromDropdown && value) {
                    // Tot paragraful selectat → tot paragraful în clasa aleasă,
                    // fără span-uri cu alte clase/stiluri rămase înăuntru.
                    targetBlock.removeAttribute('data-orig-class');
                    targetBlock = demoteHeadingForTextClass(targetBlock, value);
                    targetBlock.className = value;
                    unwrapFormattingSpans(targetBlock);
                    syncFromDesign();
                    lastDesignSnapshot = getDesignBodyHtml();
                    const newRange = doc.createRange();
                    newRange.selectNodeContents(targetBlock);
                    sel.removeAllRanges();
                    sel.addRange(newRange);
                    rememberDesignSelectionRange(doc.defaultView, doc);
                    return;
                }

                if (targetBlock) {
                    targetBlock = demoteHeadingForTextClass(targetBlock, value);
                    if (value && targetBlock.classList.contains(value)) {
                        // Toggle off: restaurează clasa originală salvată
                        const origClass = targetBlock.getAttribute('data-orig-class');
                        targetBlock.removeAttribute('data-orig-class');
                        // Default to text_obisnuit if no original class was saved
                        targetBlock.className = origClass || 'text_obisnuit';
                    } else if (value) {
                        // Salvează clasa curentă înainte de a aplica text_obisnuit2
                        if (!targetBlock.hasAttribute('data-orig-class')) {
                            targetBlock.setAttribute('data-orig-class', targetBlock.className || '');
                        }
                        targetBlock.className = value;
                        // Unwrap any inner <span> elements that have the same class
                        // (e.g. <span class="text_obisnuit2"> inside <p class="text_obisnuit2">)
                        const redundantSpans = targetBlock.querySelectorAll('span.' + value);
                        redundantSpans.forEach(span => {
                            const parent = span.parentNode;
                            while (span.firstChild) parent.insertBefore(span.firstChild, span);
                            parent.removeChild(span);
                        });
                        targetBlock.normalize();
                    } else {
                        targetBlock.removeAttribute('class');
                        targetBlock.removeAttribute('data-orig-class');
                    }
                    syncFromDesign();
                    lastDesignSnapshot = getDesignBodyHtml();
                    // CSS applies immediately to the live DOM; keep the body and selection intact.
                    const newRange = doc.createRange();
                    newRange.selectNodeContents(targetBlock);
                    sel.removeAllRanges();
                    sel.addRange(newRange);
                    rememberDesignSelectionRange(doc.defaultView, doc);
                    return;
                }

                // Din listă, câteva cuvinte dintr-un paragraf → doar ele primesc clasa nouă
                if (fromDropdown && value && applyClassToPartialSelection(doc, sel, range, value)) {
                    syncFromDesign();
                    lastDesignSnapshot = getDesignBodyHtml();
                    rememberDesignSelectionRange(doc.defaultView, doc);
                    return;
                }

                // Case 2: selection is inside (or is) an existing span → change/remove its class
                let spanEl = ancestor && ancestor.closest ? ancestor.closest('span') : null;
                if (spanEl && spanEl !== doc.body) {
                    if (value && spanEl.classList.contains(value)) {
                        // Toggle off: unwrap span using DOM (no execCommand → no style="" side-effect)
                        const parent = spanEl.parentNode;
                        while (spanEl.firstChild) parent.insertBefore(spanEl.firstChild, spanEl);
                        parent.removeChild(spanEl);
                        parent.normalize();
                        if (selectedText) {
                            const newRange = findTextRangeInNode(doc, parent, selectedText);
                            if (newRange) { sel.removeAllRanges(); sel.addRange(newRange); }
                        }
                    } else if (value) {
                        spanEl.className = value;
                    } else {
                        // Remove class: unwrap span
                        const parent = spanEl.parentNode;
                        while (spanEl.firstChild) parent.insertBefore(spanEl.firstChild, spanEl);
                        parent.removeChild(spanEl);
                        parent.normalize();
                        if (selectedText) {
                            const newRange = findTextRangeInNode(doc, parent, selectedText);
                            if (newRange) { sel.removeAllRanges(); sel.addRange(newRange); }
                        }
                    }
                } else if (value) {
                    // Case 3: no existing span. If the selection fully spans one or more
                    // block elements, set the class on each block instead of wrapping them
                    // in a <span> (which would create invalid markup like <span><p>…</p></span>).
                    const spannedBlocks = [];
                    doc.querySelectorAll(BLOCK_SEL).forEach(b => {
                        const bRange = doc.createRange();
                        bRange.selectNodeContents(b);
                        if (range.compareBoundaryPoints(Range.START_TO_START, bRange) <= 0 &&
                            range.compareBoundaryPoints(Range.END_TO_END, bRange) >= 0) {
                            spannedBlocks.push(b);
                        }
                    });
                    // Ignore ancestor containers that merely wrap the real target blocks
                    const leafBlocks = spannedBlocks.filter(b =>
                        !spannedBlocks.some(other => other !== b && b.contains(other)));
                    if (leafBlocks.length) {
                        leafBlocks.forEach(b => {
                            b = demoteHeadingForTextClass(b, value);
                            if (!b.hasAttribute('data-orig-class')) {
                                b.setAttribute('data-orig-class', b.className || '');
                            }
                            b.className = value;
                            if (fromDropdown) {
                                unwrapFormattingSpans(b);
                            } else {
                                b.querySelectorAll('span.' + value).forEach(span => {
                                    const parent = span.parentNode;
                                    while (span.firstChild) parent.insertBefore(span.firstChild, span);
                                    parent.removeChild(span);
                                });
                            }
                            b.normalize();
                        });
                        syncFromDesign();
                        lastDesignSnapshot = getDesignBodyHtml();
                        rememberDesignSelectionRange(doc.defaultView, doc);
                        return;
                    }
                    // Partial selection within a single block → wrap only the selected words.
                    // Use Range API (not execCommand) to avoid style="" side-effects
                    try {
                        const newSpan = doc.createElement('span');
                        newSpan.className = value;
                        range.surroundContents(newSpan);
                        sel.removeAllRanges();
                        const r = doc.createRange();
                        r.selectNodeContents(newSpan);
                        sel.addRange(r);
                    } catch (e) {
                        // surroundContents fails when selection partially crosses element boundaries;
                        // fall back to extract + insert
                        const newSpan = doc.createElement('span');
                        newSpan.className = value;
                        const frag = range.extractContents();
                        newSpan.appendChild(frag);
                        range.insertNode(newSpan);
                        sel.removeAllRanges();
                        const r = doc.createRange();
                        r.selectNodeContents(newSpan);
                        sel.addRange(r);
                    }
                }
            } else {
                // Case 4: no text selection (cursor only) → change the clicked element's class directly
                let el = getDesignSelection();
                if (!el) return;
                el = demoteHeadingForTextClass(el, value);
                if (value && el.classList.contains(value)) {
                    // Toggle off: restaurează clasa originală salvată
                    const origClass = el.getAttribute('data-orig-class');
                    el.removeAttribute('data-orig-class');
                    if (origClass) {
                        el.className = origClass;
                    } else {
                        el.removeAttribute('class');
                    }
                } else if (value) {
                    // Salvează clasa curentă înainte de a aplica text_obisnuit2
                    if (!el.hasAttribute('data-orig-class')) {
                        el.setAttribute('data-orig-class', el.className || '');
                    }
                    el.className = value;
                } else {
                    el.removeAttribute('class');
                    el.removeAttribute('data-orig-class');
                }
            }
            syncFromDesign();
            // Record the post-change state so the next snapshot won't double-push
            lastDesignSnapshot = getDesignBodyHtml();
        }

        async function openFromPath() {
            const inp = document.getElementById('pathInput');
            let p = (inp.value || '').trim();
            p = p.replace(/^[“']+|[“']+$/g, '').trim();
            if (!p) { dropStatus('Scrie calea catre fisier', '#ef4444'); return; }
            dropStatus('Se deschide...', '#60a5fa');
            try {
                const res = await fetch('?action=load&file=' + encodeURIComponent(p));
                if (!res.ok) { dropStatus('Eroare HTTP ' + res.status, '#ef4444'); return; }
                const txt = await res.text();
                let data;
                try { data = JSON.parse(txt); } catch (e) { dropStatus('Raspuns invalid (nu e JSON)', '#ef4444'); return; }
                if (!data.ok) { dropStatus('Eroare: ' + (data.error || 'necunoscuta'), '#ef4444'); return; }

                // Check if already open
                var existing = findTabByPath(data.file);
                if (existing) {
                    switchToTab(existing.id);
                    hideOverlay();
                    dropStatus('');
                    return;
                }

                saveCurrentTabState();

                var cnt = data.content || '';
                var label = getTabLabel(cnt, data.file);
                var fullT = getTabFullTitle(cnt, data.file);
                var tab = createTabState({
                    filePath: data.file,
                    fileName: shortName(data.file),
                    tabLabel: label,
                    fullTitle: fullT,
                    editorContent: cnt,
                    originalContent: cnt,
                    viewMode: 'design',
                    lastPreviewHadBody: /<body\b/i.test(cnt)
                });
                tabs.push(tab);
                    setTimeout(() => checkArticleIdentity(tab), 0);
                    scheduleIndexOrderCheck();
                activeTabId = tab.id;

                currentFile = data.file;
                addToRecentFiles(currentFile);
                setViewMode('design');
                _isRestoringTab = true;
                isSyncFromDesign = true;
                editor.setValue(data.content || '');
                isSyncFromDesign = false;
                _isRestoringTab = false;
                editor.getDoc().clearHistory();
                const aiFixedPath = cleanAiStyleInOpenedTab(tab, data.file);
                lastPreviewHadBody = tab.lastPreviewHadBody;
                clearTimeout(previewDebounceTimer);
                previewDebounceTimer = null;
                document.querySelectorAll('.file').forEach(f => f.classList.remove('active'));
                updatePreview();
                isDirty = false;
                designUndoStack = [];
                designRedoStack = [];
                lastDesignSnapshot = null;
                markTabDirtyAfterAiCleanup(tab, aiFixedPath);

                setViewMode('design');
                renderTabs();
                hideOverlay();
                dropStatus('');
                refreshTabLinkedCategory(tab);
                try {
                    await reconcileLinkedCategoryTeaserWithArticle(tab, tab.editorContent, { context: 'open', silent: true });
                } catch (eSync) { console.error(eSync); }
            } catch (e) {
                dropStatus('Eroare: ' + e.message, '#ef4444');
            }
        }

        function closeEditor() {
            closeActiveTab();
        }

        const ALLOWED_EXT = ['.html', '.htm', '.css', '.js', '.php'];
        function hasAllowedExt(filename) {
            const n = (filename || '').toLowerCase();
            return ALLOWED_EXT.some(ext => n.endsWith(ext));
        }

        function dropStatus(msg, color) {
            const el = document.getElementById('dropStatus');
            if (!el) return;
            el.style.display = msg ? 'block' : 'none';
            el.style.color = color || '#facc15';
            el.textContent = msg || '';
        }

        // Click pe un steag în Design / Split: numele paginii (fără https://neculaifantanaru.com/…/)
        // ajunge în clipboard
        function copyFlagPageName(page, lang) {
            const done = () => toast('Copiat' + (lang ? ' (' + lang + ')' : '') + ': ' + page);
            const fallback = () => {
                const ta = document.createElement('textarea');
                ta.value = page;
                ta.style.cssText = 'position:fixed;left:-9999px;top:0';
                document.body.appendChild(ta);
                ta.select();
                let ok = false;
                try { ok = document.execCommand('copy'); } catch (e) { }
                ta.remove();
                ok ? done() : toast('Nu am putut copia ' + page);
            };
            try {
                navigator.clipboard.writeText(page).then(done, fallback);
            } catch (e) { fallback(); }
        }

        // Fișier tras în editor care există identic în mai multe foldere: utilizatorul alege
        // de unde l-a deschis (browserul nu dă calea fișierului, doar numele și conținutul).
        function chooseDroppedFilePath(name, paths) {
            return new Promise(resolve => {
                const dlg = document.createElement('dialog');
                dlg.style.cssText = 'margin:auto;inset:0;max-width:760px;width:calc(100% - 48px);padding:22px 26px;border:1px solid #46516d;' +
                    'border-radius:14px;background:#1f2330;color:#f1f3f9;font:15px/1.5 system-ui;box-shadow:0 24px 80px #000a';
                const h = document.createElement('h3');
                h.style.cssText = 'margin:0 0 6px;font-size:19px';
                h.textContent = 'Din ce folder ai deschis ' + name + '?';
                dlg.appendChild(h);
                const p = document.createElement('p');
                p.style.cssText = 'margin:0 0 14px;color:#9aa3b8';
                p.textContent = 'Același fișier, identic, există în mai multe locuri. Alege-l pe cel pe care vrei să-l editezi (acolo se va salva).';
                dlg.appendChild(p);
                const done = v => { dlg.close(); dlg.remove(); resolve(v); };
                paths.forEach(path => {
                    const b = document.createElement('button');
                    const norm = String(path).replace(/\\/g, '/');
                    const isSite = /\/Principal\/(ro|en)\/[^\/]+$/i.test(norm);
                    b.textContent = norm;
                    b.style.cssText = 'display:block;width:100%;text-align:left;margin:6px 0;padding:10px 12px;border-radius:8px;cursor:pointer;' +
                        'font:13px/1.4 ui-monospace,Consolas,monospace;overflow-wrap:anywhere;' +
                        (isSite ? 'background:#16332a;border:1px solid #2f9e74;color:#7ee2b8' : 'background:#262b3a;border:1px solid #46516d;color:#d6dbe8');
                    b.onclick = () => done(path);
                    dlg.appendChild(b);
                });
                const cancel = document.createElement('button');
                cancel.textContent = 'Nu știu — lasă fără cale (Save as)';
                cancel.style.cssText = 'margin-top:10px;padding:8px 16px;border-radius:8px;border:1px solid #5a6480;background:transparent;color:#d6dbe8;cursor:pointer;font:600 14px system-ui';
                cancel.onclick = () => done(null);
                dlg.appendChild(cancel);
                dlg.addEventListener('cancel', e => { e.preventDefault(); done(null); });
                document.body.appendChild(dlg);
                dlg.showModal();
            });
        }

        function handleDropFile(file) {
            if (!file) { dropStatus('Niciun fisier primit', '#ef4444'); return; }
            if (!hasAllowedExt(file.name)) { dropStatus('Doar fisiere HTML, CSS, JS sau PHP', '#ef4444'); return; }
            dropStatus('Se citeste fisierul “' + file.name + '”...', '#60a5fa');
            const reader = new FileReader();
            reader.onload = function () {
                var content = reader.result || '';

                // Save current tab before creating new one
                saveCurrentTabState();

                var label = getTabLabel(content, file.name);
                var fullT = getTabFullTitle(content, file.name);
                var tab = createTabState({
                    filePath: null,
                    fileName: file.name,
                    tabLabel: label,
                    fullTitle: fullT,
                    editorContent: content,
                    originalContent: content,
                    viewMode: 'design',
                    lastPreviewHadBody: /<body\b/i.test(content)
                });
                tabs.push(tab);
                    setTimeout(() => checkArticleIdentity(tab), 0);
                    scheduleIndexOrderCheck();
                activeTabId = tab.id;
                var newTabId = tab.id;

                currentFile = null;
                setViewMode('design');
                _isRestoringTab = true;
                isSyncFromDesign = true;
                editor.setValue(content);
                isSyncFromDesign = false;
                _isRestoringTab = false;
                editor.getDoc().clearHistory();
                const aiFixedDrop = cleanAiStyleInOpenedTab(tab, file.name);
                lastPreviewHadBody = tab.lastPreviewHadBody;
                clearTimeout(previewDebounceTimer);
                previewDebounceTimer = null;
                updatePreview();
                document.querySelectorAll('.file').forEach(f => f.classList.remove('active'));
                isDirty = false;
                designUndoStack = [];
                designRedoStack = [];
                lastDesignSnapshot = null;
                markTabDirtyAfterAiCleanup(tab, aiFixedDrop);

                setViewMode('design');
                renderTabs();
                hideOverlay();
                dropStatus('');

                // Cauta automat calea fisierului pe disc dupa nume
                const extraDirs = getRecentDirs();
                const searchUrl = '?action=search&name=' + encodeURIComponent(file.name)
                    + (extraDirs.length ? '&dirs=' + encodeURIComponent(JSON.stringify(extraDirs)) : '');
                fetch(searchUrl)
                    .then(r => r.json())
                    .then(data => {
                        // Helper to update tab when path resolved
                        function resolveTabPath(resolvedPath) {
                            // Check if another tab already has this path
                            var existingTab = findTabByPath(resolvedPath);
                            if (existingTab && existingTab.id !== newTabId) {
                                // Duplicate — close the new tab and switch to existing
                                closeTab(newTabId);
                                switchToTab(existingTab.id);
                                return;
                            }
                            currentFile = resolvedPath;
                            // Update the tab object
                            for (var ti = 0; ti < tabs.length; ti++) {
                                if (tabs[ti].id === newTabId) {
                                    tabs[ti].filePath = resolvedPath;
                                    const resolvedTab = tabs[ti];
                                    setTimeout(() => checkArticleIdentity(resolvedTab), 0);
                                    tabs[ti].tabLabel = getTabLabel(editor.getValue(), resolvedPath);
                                    tabs[ti].editorContent = editor.getValue();
                                    refreshTabLinkedCategory(tabs[ti]);
                                    break;
                                }
                            }
                            isDirty = false;
                            addToRecentFiles(resolvedPath);
                            renderTabs();
                            toast('Fisier gasit: ' + resolvedPath);
                            updatePreview();
                        }

                        if (data.ok && data.results && data.results.length === 1) {
                            resolveTabPath(data.results[0]);
                        } else if (data.ok && data.results && data.results.length > 1) {
                            const draggedContent = editor.getValue().replace(/\r\n/g, '\n');
                            Promise.all(
                                data.results.map(path =>
                                    fetch('?action=load&file=' + encodeURIComponent(path))
                                        .then(r => r.json())
                                        .catch(() => null)
                                )
                            ).then(loaded => {
                                // Toate copiile cu exact același conținut (originalul + eventuale backup-uri)
                                const same = [];
                                for (let i = 0; i < loaded.length; i++) {
                                    if (loaded[i] && loaded[i].ok &&
                                        (loaded[i].content || '').replace(/\r\n/g, '\n') === draggedContent) {
                                        same.push(data.results[i]);
                                    }
                                }
                                if (!same.length) return;
                                // Prioritate: fișierul din Principal/ro sau Principal/en (fără subfoldere)
                                const site = same.filter(p => /\/Principal\/(ro|en)\/[^\/]+$/i.test(String(p).replace(/\\/g, '/')));
                                if (site.length === 1 || same.length === 1) {
                                    resolveTabPath(site.length === 1 ? site[0] : same[0]);
                                    return;
                                }
                                // Mai multe copii identice și niciuna sigură → întreabă, nu ghici
                                chooseDroppedFilePath(file.name, site.length ? site : same).then(p => { if (p) resolveTabPath(p); });
                            });
                        }
                    })
                    .catch(() => { });
            };
            reader.onerror = function () { dropStatus('Eroare la citirea fisierului', '#ef4444'); };
            reader.readAsText(file, 'UTF-8');
        }

        window.addEventListener('beforeunload', function (e) {
            if (typeof flushPendingDesignSync === 'function') flushPendingDesignSync();
            saveCurrentTabState();
            var hasUnsaved = tabs.some(function (t) { return t.isDirty; }) || isDirty;
            // Force an immediate backup for this window only (bypass debounce).
            try {
                var dirtyTabs = [];
                for (var i = 0; i < tabs.length; i++) {
                    if (tabs[i].isDirty && tabs[i].type !== 'browser') {
                        dirtyTabs.push(makeTabBackup(tabs[i]));
                    }
                }
                replaceOwnedBackups(dirtyTabs);
            } catch (ex) { }
            if (hasUnsaved) {
                e.preventDefault();
                e.returnValue = '';
            }
        });

        window.addEventListener('load', () => {
            initEditor();
            refreshList('');
            renderRecentFiles();
            renderSidebarRecent();
            // Restore unsaved tabs from backup (e.g. after power loss)
            restoreBackupTabs();
            // Restore sidebar visibility from last session
            try {
                const sv = localStorage.getItem('htmlEditorSidebarVisible');
                if (sv === '0') {
                    sidebarVisible = false;
                    const sb = document.querySelector('.sidebar');
                    if (sb) sb.classList.add('collapsed');
                }
            } catch (e) { }
            document.addEventListener('dragover', e => e.preventDefault(), false);
            document.addEventListener('drop', e => e.preventDefault(), false);

            document.getElementById('pathInput').addEventListener('keydown', e => {
                if (e.key === 'Enter') { e.preventDefault(); openFromPath(); }
            });

            const dz = document.getElementById('dropZone');
            const fp = document.getElementById('filePicker');
            if (dz) {
                dz.addEventListener('click', () => { if (fp) fp.click(); });
                ['dragenter', 'dragover'].forEach(evt => dz.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); dz.classList.add('over'); }));
                dz.addEventListener('dragleave', e => { e.preventDefault(); e.stopPropagation(); dz.classList.remove('over'); });
                dz.addEventListener('drop', e => {
                    e.preventDefault();
                    e.stopPropagation();
                    dz.classList.remove('over');
                    const f = e.dataTransfer.files && e.dataTransfer.files[0];
                    handleDropFile(f);
                });
            }
            if (fp) {
                fp.addEventListener('change', () => {
                    const f = fp.files && fp.files[0];
                    if (f) handleDropFile(f);
                    fp.value = '';
                });
            }

            // Make popups draggable/resizable (especially translation panel)
            function makeDialogDraggable(el, storageKey) {
                if (!el) return;
                el.classList.add('resizable');
                const header = el.querySelector('.drag-handle') || el.querySelector('h4');
                if (!header) return;
                header.style.cursor = 'move';
                let dragging = false;
                let startX = 0, startY = 0, startLeft = 0, startTop = 0;

                // Poziția salvată (ex. fereastra Find rămâne unde ai mutat-o)
                if (storageKey) {
                    try {
                        const pos = JSON.parse(localStorage.getItem(storageKey) || 'null');
                        if (pos && isFinite(pos.left) && isFinite(pos.top)) {
                            el.style.left = Math.max(0, Math.min(pos.left, window.innerWidth - 80)) + 'px';
                            el.style.top = Math.max(40, Math.min(pos.top, window.innerHeight - 60)) + 'px';
                            el.style.right = 'auto';
                            el.style.bottom = 'auto';
                        }
                    } catch (e) { }
                }

                header.addEventListener('mousedown', function (e) {
                    if (e.button !== 0 || (e.target.closest && e.target.closest('button'))) return;
                    e.preventDefault();
                    dragging = true;
                    // Iframe-ul Design ar „înghiți” mișcarea mouse-ului în timpul tragerii
                    document.querySelectorAll('iframe').forEach(f => { f.dataset.frPe = f.style.pointerEvents || ''; f.style.pointerEvents = 'none'; });
                    const rect = el.getBoundingClientRect();
                    startX = e.clientX;
                    startY = e.clientY;
                    // convert current transform (top/left) to explicit left/top
                    el.style.left = rect.left + 'px';
                    el.style.top = rect.top + 'px';
                    el.style.right = 'auto';
                    el.style.bottom = 'auto';
                    startLeft = rect.left;
                    startTop = rect.top;
                    document.body.style.userSelect = 'none';
                });

                window.addEventListener('mousemove', function (e) {
                    if (!dragging) return;
                    const dx = e.clientX - startX;
                    const dy = e.clientY - startY;
                    let newLeft = startLeft + dx;
                    let newTop = startTop + dy;
                    const maxX = window.innerWidth - 50;
                    const maxY = window.innerHeight - 40;
                    if (newLeft < 0) newLeft = 0;
                    if (newTop < 40) newTop = 40;
                    if (newLeft > maxX) newLeft = maxX;
                    if (newTop > maxY) newTop = maxY;
                    el.style.left = newLeft + 'px';
                    el.style.top = newTop + 'px';
                });

                window.addEventListener('mouseup', function () {
                    if (dragging) {
                        dragging = false;
                        document.body.style.userSelect = '';
                        document.querySelectorAll('iframe').forEach(f => { f.style.pointerEvents = f.dataset.frPe || ''; delete f.dataset.frPe; });
                        if (storageKey) {
                            try {
                                localStorage.setItem(storageKey, JSON.stringify({
                                    left: parseFloat(el.style.left) || 0,
                                    top: parseFloat(el.style.top) || 0
                                }));
                            } catch (e) { }
                        }
                    }
                });
            }

            makeDialogDraggable(document.getElementById('findReplaceDialog'), 'htmlEditorFindDialogPos');
            makeDialogDraggable(document.getElementById('translatePopup'));
            makeDialogDraggable(document.getElementById('diacPopup'));

            // Drag-and-drop files onto tab bar area (+ button and empty spacer)
            (function() {
                var tabBar = document.getElementById('tabBar');
                var spacer = document.getElementById('tabBarSpacer');
                if (!tabBar || !spacer) return;

                var targets = [tabBar, spacer];
                var dragCounter = {};  // per-element counter to handle child enter/leave

                function hasFiles(e) {
                    if (e.dataTransfer && e.dataTransfer.types) {
                        for (var i = 0; i < e.dataTransfer.types.length; i++) {
                            if (e.dataTransfer.types[i] === 'Files') return true;
                        }
                    }
                    return false;
                }

                targets.forEach(function(el) {
                    var id = el.id;
                    dragCounter[id] = 0;

                    el.addEventListener('dragenter', function(e) {
                        if (!hasFiles(e)) return;  // ignore tab reorder drags
                        e.preventDefault();
                        e.stopPropagation();
                        dragCounter[id]++;
                        el.classList.add('file-drag-over');
                    });

                    el.addEventListener('dragover', function(e) {
                        if (!hasFiles(e)) return;
                        e.preventDefault();
                        e.stopPropagation();
                        e.dataTransfer.dropEffect = 'copy';
                    });

                    el.addEventListener('dragleave', function(e) {
                        if (!hasFiles(e)) return;
                        e.preventDefault();
                        e.stopPropagation();
                        dragCounter[id]--;
                        if (dragCounter[id] <= 0) {
                            dragCounter[id] = 0;
                            el.classList.remove('file-drag-over');
                        }
                    });

                    el.addEventListener('drop', function(e) {
                        if (!hasFiles(e)) return;
                        e.preventDefault();
                        e.stopPropagation();
                        dragCounter[id] = 0;
                        el.classList.remove('file-drag-over');
                        // Also clear sibling highlight
                        targets.forEach(function(t) { t.classList.remove('file-drag-over'); });
                        var f = e.dataTransfer.files && e.dataTransfer.files[0];
                        if (f) handleDropFile(f);
                    });
                });
            })();

            // F12: open current file as a local file:// URL in a new browser tab.
            // NOTE: Chrome may block window.open('file://...') from an http:// page.
            // If the new tab does not open, copy the path shown in the toast and
            // paste it directly into the browser's address bar.
            document.addEventListener('keydown', e => {
                if (e.key === 'F12') {
                    if (!currentFile) return;
                    // Convert Windows path (e:\...) to file:/// URL
                    const localUrl = 'file:///' + currentFile.replace(/\\/g, '/').replace(/^\/+/, '');
                    const opened = window.open(localUrl, '_blank');
                    if (!opened) {
                        // Popup blocked — show path so user can open manually
                        toast('F12: copiaza calea in browser: ' + localUrl);
                    }
                    // Note: e.preventDefault() does NOT stop Chrome DevTools from
                    // opening (it's a browser-level shortcut), but the file tab
                    // will still open alongside DevTools.
                }
            });

            document.getElementById('propFont').addEventListener('change', () => applyFontProperty('fontFamily', document.getElementById('propFont').value));
            document.getElementById('propClass').addEventListener('change', () => applyClassProperty(document.getElementById('propClass').value, { fromDropdown: true }));
            document.getElementById('propSize').addEventListener('change', () => applyFontProperty('fontSize', document.getElementById('propSize').value));
            const quickItalicTop = document.getElementById('btnQuickItalic');
            if (quickItalicTop) {
                quickItalicTop.addEventListener('mousedown', e => e.preventDefault());
                quickItalicTop.addEventListener('click', () => {
                    toggleInlineFormat('italic');
                });
            }
            const quickUnderlineTop = document.getElementById('btnQuickUnderline');
            if (quickUnderlineTop) {
                quickUnderlineTop.addEventListener('mousedown', e => e.preventDefault());
                quickUnderlineTop.addEventListener('click', () => {
                    toggleInlineFormat('underline');
                });
            }
            // N: paragraful cu cursorul devine <p class="text_obisnuit"> (fără alte taguri)
            const normalClassBtn = document.getElementById('btnClassNormal');
            if (normalClassBtn) {
                normalClassBtn.addEventListener('mousedown', e => e.preventDefault());
                normalClassBtn.addEventListener('click', applyNormalParagraphStyle);
            }
            // Shortcut în topbar: B lângă Redo → comută paragraful text_obisnuit2 / text_obisnuit
            const quickClassBtn = document.getElementById('btnClassObisnuit2');
            if (quickClassBtn) {
                quickClassBtn.addEventListener('mousedown', e => e.preventDefault());
                quickClassBtn.addEventListener('click', () => {
                    if (toggleBoldParagraphStyle()) return;
                    const targetClass = quickClassBtn.dataset.className || 'text_obisnuit2';
                    applyClassProperty(targetClass);
                    const el = getDesignSelection();
                    if (el) {
                        const hasClass = designSelectionHasCssClass(el, targetClass);
                        quickClassBtn.classList.toggle('active', hasClass);
                    }
                });
            }
            document.getElementById('propColor').addEventListener('input', () => applyFontProperty('color', document.getElementById('propColor').value));
            document.getElementById('propBg').addEventListener('input', () => applyFontProperty('backgroundColor', document.getElementById('propBg').value));
            document.getElementById('propLink').addEventListener('change', applyLinkProperty);
            document.getElementById('propLinkTarget').addEventListener('change', applyLinkProperty);
        });
    </script>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('sw.js').catch(function () { });
        }

        // ── Avertisment: editorul (acest fisier) s-a schimbat pe disc → trebuie reincarcat ──
        // Pagina isi tine minte versiunea (data modificarii fisierului) de la incarcare si
        // intreaba serverul la 20 s si la revenirea in fereastra daca a aparut una mai noua.
        (function () {
            var loadedVersion = <?php echo json_encode((string) filemtime(__FILE__)); ?>;
            var bannerShown = false;
            function showUpdateBanner() {
                if (bannerShown) return;
                bannerShown = true;
                var bar = document.createElement('div');
                bar.id = 'editorUpdateBanner';
                bar.style.cssText = 'position:fixed;top:10px;left:50%;transform:translateX(-50%);z-index:100001;' +
                    'background:#1f2937;border:2px solid #facc15;border-radius:8px;padding:10px 16px;' +
                    'display:flex;align-items:center;gap:14px;color:#eee;font-size:16px;box-shadow:0 6px 24px rgba(0,0,0,.5)';
                bar.innerHTML =
                    '<span><i class="fas fa-sync-alt" style="color:#facc15"></i> ' +
                    'Editorul a fost actualizat. Reîncarcă pagina ca să folosești versiunea nouă.</span>' +
                    '<button class="btn btn-primary" id="editorUpdateReload">Reîncarcă acum</button>' +
                    '<button class="btn btn-ghost" id="editorUpdateLater">Mai târziu</button>';
                document.body.appendChild(bar);
                document.getElementById('editorUpdateReload').onclick = function () { location.reload(); };
                document.getElementById('editorUpdateLater').onclick = function () {
                    bar.remove();
                    // reapare peste 5 minute daca tot n-a fost reincarcat
                    setTimeout(function () { bannerShown = false; checkVersion(); }, 5 * 60 * 1000);
                };
            }
            function checkVersion() {
                if (bannerShown) return;
                fetch('?action=version', { cache: 'no-store' })
                    .then(function (r) { return r.json(); })
                    .then(function (d) {
                        if (d && d.ok && String(d.v) !== String(loadedVersion)) showUpdateBanner();
                    })
                    .catch(function () { });
            }
            setInterval(checkVersion, 20000);
            window.addEventListener('focus', checkVersion);
            document.addEventListener('visibilitychange', function () {
                if (document.visibilityState === 'visible') checkVersion();
            });
        })();
    </script>
</body>

</html>
